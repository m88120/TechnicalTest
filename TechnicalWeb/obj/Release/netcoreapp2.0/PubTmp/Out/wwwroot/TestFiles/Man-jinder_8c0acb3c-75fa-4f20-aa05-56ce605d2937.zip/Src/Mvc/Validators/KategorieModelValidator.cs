﻿using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Aushub.Shared.Services;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Validators
{
    public class KategorieModelValidator : AbstractValidator<KategorieDetailModel>
    {
        public KategorieModelValidator()
        {
            RuleFor(x => x.Kategorie).NotEmpty().WithMessage("Kategorie darf nicht leer sein");
        }
    }
}