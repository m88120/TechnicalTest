﻿function setFormAction(containingJqueryElement, formAction) {
    containingJqueryElement.closest('form').attr('action', formAction);
}

function setFormActionFromButton(jqueryButton) {
    var formAction = jqueryButton.attr('formaction');

    setFormAction(jqueryButton, formAction);
}

$(document).on('click', 'form input[formaction]', function (e) {
    setFormActionFromButton($(this));

    if ($(this).attr('data-fullpostback')) {
        e.preventDefault();
        var $form = $(this).closest("form");
        $form.attr("data-ajax", "");
        $form.trigger("submit");
        $form.attr("data-ajax", "true");
    }
});

function scrollTo(jqueryElement) {
    var top = jqueryElement.offset().top;
    var offsetY = $("#aushub24 .header").outerHeight();

    $('html,body').animate({ scrollTop: top - offsetY }, 'slow');
}

$(document).ready(function () {
    rebindDatePickers();
});

function rebindDatePickers() {
    $('.datePicker').datepicker($.datepicker.regional['de']);
}

$(window).resize(function () {
    refreshFullWidthContainers();
});

$(document).ready(function () {
    refreshFullWidthContainers();
});

function refreshFullWidthContainers() {
    $('.fullWidthContainer').each(function () {
        var position = $(this).parent().offset();
        $(this).width($(window).width());
        $(this).css("left", -position.left + "px");
        $(this).css("position", "relative");
    });
}

var loadingElementId = '#throbber';

function showLoadingElement() {
    $(loadingElementId).show();
}

function hideLoadingElement() {
    $(loadingElementId).hide();
}