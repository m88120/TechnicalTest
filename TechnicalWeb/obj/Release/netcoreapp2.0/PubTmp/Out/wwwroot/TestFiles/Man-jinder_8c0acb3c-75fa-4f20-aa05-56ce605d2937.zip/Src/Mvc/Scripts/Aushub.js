﻿jQuery.extend({
    getQueryParameters: function (str) {
        return (str || document.location.search).replace(/(^\?)/, '').split('&').map(function (n) { return n = n.split('='), this[n[0]] = n[1], this }.bind({}))[0];
    }
});

function reloadGrid(selector) {
    $(selector).ajaxifyWebGrid('execute');
}

function doPostActionCall(actionUrl, prefix, formScope, scope, htmlCallback, jsonCallback) {
    var detailsSelector = '#' + prefix + 'Details';
    var messageSelector = '#' + prefix + 'Message';

    var postData = null;
    var processData = true;
    var contentType = undefined;
    if (formScope !== null) {

        // filter out nested document form elements
        var postDataElements = $(formScope).find('select, textarea, input');

        if (!$(formScope).hasClass('documentForm')) {
            postDataElements = postDataElements.filter(function (index, element) {
                return !$(element).closest('form').hasClass('documentForm');
            });
        }

        var fileUploads = $(postDataElements).filter('[type="file"]');
        if (fileUploads.length > 0) {
            // if file uploads detected, use FormData
            var scopeType = formScope.prop("tagName").toLowerCase();
            if (scopeType !== 'form') {
                formScope = $(formScope).children('form');
            }
            postData = new FormData(formScope[0]);
            processData = false;
            contentType = false;
        }
        else {
            postData = postDataElements.serialize();
        }
    }

    if (htmlCallback === null || htmlCallback === undefined) {
        htmlCallback = 'showHtml';
    }

    if (jsonCallback === null || jsonCallback === undefined) {
        jsonCallback = 'showJsonWithFade';
    }

    $.post({
        url: actionUrl,
        data: postData,
        processData: processData,
        contentType: contentType,
        cache: false,
        success: function (response, status, xhr) {
            var ct = xhr.getResponseHeader('content-type') || '';
            if (ct.indexOf('html') > -1) {
                window[htmlCallback](response, prefix);
            }
            if (ct.indexOf('json') > -1) {
                showJsonWithFade(response, prefix);
            }
        },
        error: function () {
            showJsonWithFade({ Success: false, Message: 'An error occured while performing this action' });
        }
    });
}

function showHtml(html, prefix) {
    var selector = '#' + prefix + 'Details';
    var details = $(selector);
    details.hide('fast');
    details.html(html);
    details.show('fast');
}

function showJsonWithFade(simpleJsonMessage, prefix) {
    var selector = '#' + prefix + 'Message';
    var messageBox = $(selector);
    messageBox.html(simpleJsonMessage.Message);
    messageBox.removeClass('success-message');
    messageBox.removeClass('error-message');
    messageBox.addClass(simpleJsonMessage.Success ? 'success-message' : 'error-message');
    messageBox.stop(true, true).show('fast').delay(7000).fadeOut();
}

$(document).on('click', '.actionButton', function () {
    var url = $(this).data('url');
    var type = $(this).data('type');

    scrollTop();

    if (type === 'forward') {
        buttonForward(url, this);
    }
    else {
        buttonBackward(url, this);
    }
});

function buttonForward(url, sender) {
    var data = $(sender).closest('form');
    $.post({
        url: url,
        cache: false,
        data: data.serialize(),
        success: function (response, status, xhr) {
            var ct = xhr.getResponseHeader('content-type') || '';
            if (ct.indexOf('html') > -1) {
                showHtml(response, 'wizard');
            }
            if (ct.indexOf('json') > -1) {
                showJsonWithFade(response, 'wizard');
            }
        },
        error: function (response) {
            $('#wizardDetails').html(response.responseText);
        }
    });
}

function buttonBackward(url, sender) {
    $.get({
        url: url,
        cache: false,
        success: function (response, status, xhr) {
            var ct = xhr.getResponseHeader('content-type') || '';
            if (ct.indexOf('html') > -1) {
                showHtml(response, 'wizard');
            }
            if (ct.indexOf('json') > -1) {
                showJsonWithFade(response, 'wizard');
            }
        },
        error: function (response) {
            $('#wizardDetails').html(response.responseText);
        }
    });
}

function scrollTop() {
    $('html, body').animate({ scrollTop: '0px' }, 100);
}

$(document).on('click', '.gridActionIcon', function () {
    var url = $(this).data('url');

    if (url !== '' && url !== null && url !== undefined && url.indexOf('ComingSoon') <= 0) {
        window.location.href = url;
    }
    else {
        alert("Coming soon");
    }
});


$.address.init(function (e) {

}).externalChange(function (e) {

    if (e.path.length > 1) {
        var prefix = getHashPrefix();
        var relData = getHashData();
        if (prefix === "#/wizard") {
            //request path is a wizardstep
            var action = relData.replace(/\//g, '');
            var antragId = $('#AntragId').val();
            var currentStep = $('#CurrentStep').val();
            if (currentStep !== undefined) {
                var saveUrl = '/Wizard/' + currentStep;
                var data = $('#CurrentStep').closest('form');

                $.post({
                    url: saveUrl,
                    cache: false,
                    data: data.serialize(),
                    success: function (response) {
                        var url = '/Wizard/' + action + '/' + antragId;

                        $.get({
                            url: url,
                            cache: false,
                            success: function (data) {
                                $('#wizardDetails').html(data);
                            }
                        });
                    },
                    error: function (response) {
                        $('#wizardDetails').html(response.responseText);
                    }
                });
            }
            else {
                var url = '/Wizard/' + action + '/' + antragId;

                $.get({
                    url: url,
                    cache: false,
                    success: function (data) {
                        $('#wizardDetails').html(data);
                    }
                });
            }
        }
    }

}).internalChange(function (e) {

});

function getHashPrefix() {
    var hash = window.location.hash;
    var sepIndex = hash.indexOf('-');
    return hash.substring(0, sepIndex);
}

function getHashData() {
    var hash = window.location.hash;
    var sepIndex = hash.indexOf('-') + 1;
    return hash.substring(sepIndex, hash.length);
}

function guid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
        s4() + '-' + s4() + s4() + s4();
}

function isDate(txtDate) {
    var currVal = txtDate;
    if (currVal === '')
        return false;

    var rxDatePattern = /^(\d{1,2})(\/|.)(\d{1,2})(\/|.)(\d{2,4})$/; //Declare Regex
    var dtArray = currVal.match(rxDatePattern); // is format OK?

    if (dtArray === null) {
        return false;
    }

    //Checks for mm/dd/yyyy format.
    dtDay = dtArray[1];
    dtMonth = dtArray[3];
    dtYear = dtArray[5];

    if (dtYear.length === 3) {
        return false;
    }

    if (dtMonth < 1 || dtMonth > 12)
        return false;
    else if (dtDay < 1 || dtDay > 31)
        return false;
    else if ((dtMonth === 4 || dtMonth === 6 || dtMonth === 9 || dtMonth === 11) && dtDay === 31)
        return false;
    else if (dtMonth === 2) {
        var isleap = (dtYear % 4 === 0 && (dtYear % 100 !== 0 || dtYear % 400 === 0));
        if (dtDay > 29 || (dtDay === 29 && !isleap))
            return false;
    }
    return true;
}

function getYear(txtDate) {
    var currVal = txtDate;
    if (currVal === '')
        return null;

    var rxDatePattern = /^(\d{1,2})(\/|.)(\d{1,2})(\/|.)(\d{2,4})$/; //Declare Regex
    var dtArray = currVal.match(rxDatePattern); // is format OK?

    if (dtArray === null)
        return null;

    //Checks for mm/dd/yyyy format.
    dtDay = dtArray[1];
    dtMonth = dtArray[3];
    dtYear = dtArray[5];

    return dtYear;
}

$(document).on('click', '.specialGridAction', function () {
    var url = $(this).data('url');

    $.get({
        url: url,
        cache: false,
        success: function () {
            $('.offerGrid').ajaxifyWebGrid('execute', null, { preservePaging: true });
        }
    })
});