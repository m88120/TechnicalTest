﻿using Autofac;
using Comitas.CAF.Core.Logging;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Web.MVC;
using Comitas.CAF.Web.Security;
using Aushub.Mvc.App_Start;
using Aushub.Mvc.Controllers;
using Aushub.Shared;
using Aushub.Shared.Services;
using Aushub.App;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Claims;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;

namespace Aushub.Mvc
{
    public class MvcApp : CAFMvcApp
    {
        private const string CAFAppAssembly = "Comitas.CAF.App.NPoco";
        private const string AppAssembly = "Aushub.App";

        public static CAFSecurityManager<OwinEnvironment> CAFSecurityManager { get; set; }
        public static Config Config { get; private set; }
        public static IAuthorizationManager AuthManager { get { return Bootstrapper.AuthorizationManager; } }
        public static AushubBootstrapper Bootstrapper { get; private set; }

        protected override void Application_Start(object sender, EventArgs e)
        {
            base.Application_Start(sender, e);

            Config = Resolve<Config>();
            CAFSecurityManager = new CAFSecurityManager<OwinEnvironment>(Resolve<IUserService>(), Resolve<IAuthorizationManager>(), Resolve<IMailService>());

            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            Bootstrapper = Resolve<AushubBootstrapper>();
            Bootstrapper.BootstrapApplication();

            AntiForgeryConfig.UniqueClaimTypeIdentifier = ClaimTypes.NameIdentifier;
        }

        protected override void RegisterComponentStartup(ContainerBuilder builder)
        {
            base.RegisterComponentStartup(builder);

            if (!AppDomain.CurrentDomain.GetAssemblies().Any(x => x.GetName().Name == AppAssembly))
            {
                string executingPath = HttpRuntime.AppDomainAppPath;
                Logger.Info($"Running from path {executingPath}");
                DirectoryInfo binDir = new DirectoryInfo($"{executingPath}\\bin");
                Assembly loadedAssembly = Assembly.LoadFile($"{binDir.FullName}\\{AppAssembly}.dll");
            }

            var appAssembly = GetAssemblyByName(AppAssembly);
            builder.RegisterAssemblyModules(appAssembly);
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception exception = Server.GetLastError();
            HttpException httpException = exception as HttpException;
            int httpCode = (httpException == null ? 0 : httpException.GetHttpCode());

            // Fehler loggen
            if (exception != null)
            {
                string errorMessage;

                if (httpCode == 0)
                {
                    errorMessage = exception.Message;
                }
                else
                {
                    errorMessage = $"{exception.Message} (HTTP: {httpCode})";
                }

                Logger.Error(errorMessage, exception);
            }

            // Response zuruecksetzen
            Response.Clear();

            // Fehler behandeln
            string errorAction;
            bool handled;

            if (httpCode == 404)
            {
                errorAction = nameof(ErrorController.PageNotFound);
                handled = true;
            }
            else if (httpCode == 403)
            {
                errorAction = nameof(ErrorController.NoAccess);
                handled = true;
            }
            else if (Config.CatchUnhandledErrors)
            {
                errorAction = nameof(ErrorController.Unhandled);
                handled = true;
            }
            else
            {
                errorAction = null;
                handled = false;
            }

            if (handled)
            {
                Server.ClearError();
                Response.TrySkipIisCustomErrors = true;

                // RouteValues erstellen um danach auszufuehren
                RouteData routeData = new RouteData();
                routeData.Values.Add("controller", "Error");
                routeData.Values.Add("action", errorAction);
                routeData.Values.Add("exception", exception);

                // Error-Seite aufrufen
                IController errorController = new ErrorController();
                errorController.Execute(new RequestContext(new HttpContextWrapper(Context), routeData));
            }
        }
    }
}