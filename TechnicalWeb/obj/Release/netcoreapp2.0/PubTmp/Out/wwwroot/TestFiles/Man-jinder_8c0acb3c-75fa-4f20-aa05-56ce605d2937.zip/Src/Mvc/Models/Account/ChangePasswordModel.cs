﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Aushub.Mvc.Models
{
    public class ChangePasswordModel
    {
        public string CurrentPassword { get; set; }

        [DataType(DataType.Password)]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        public string NewPasswordRepeat { get; set; }

        public bool Postback { get; set; }
        public string Message { get; set; }
    }
}