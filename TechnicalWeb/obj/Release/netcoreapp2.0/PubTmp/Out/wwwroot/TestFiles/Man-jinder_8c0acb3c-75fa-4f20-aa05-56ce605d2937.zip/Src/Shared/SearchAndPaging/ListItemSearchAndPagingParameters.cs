﻿using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.SearchAndPaging
{
    public class ListItemSearchAndPagingParameters : SearchAndPagingParameters
    {
        public string Gruppe { get; set; }
        public string Bezeichnung { get; set; }
        public List<string> Gruppen { get; set; }


        public ListItemSearchAndPagingParameters() : base()
        {
            PageSize = 10;
            Gruppen = new List<string>();
        }

    }
}
