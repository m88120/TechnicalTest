﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using Comitas.CAF.Utilities;

namespace Aushub.Code.Helpers
{
    public static class WebHelper
    {
        public static MvcHtmlString DetailLink(this HtmlHelper helper, object textObject, dynamic id, string format = null)
        {
            string action = new UrlHelper(HttpContext.Current.Request.RequestContext).Action("Detail", new { id = (string)id });

            string text = "";

            if (textObject != null)
            {
                text = format == null ? textObject.ToString() : string.Format(format, textObject);
            }

            return new MvcHtmlString(string.Format("<a href={0}>{1}</a>", action, text));
        }

        public static MvcHtmlString ModalLink(this HtmlHelper helper, object textObject, dynamic id, string toggleTarget, string format = null, object htmlAttributes = null)
        {
            string text = "";

            if (textObject != null)
            {
                text = format == null ? textObject.ToString() : string.Format(format, textObject);
            }

            string attribs = null;
            if (htmlAttributes != null)
            {
                attribs = helper.AnonymousObjectToAttributeString(htmlAttributes).ToString();
            }

            var encodedTarget = HttpUtility.UrlEncode(id as string);

            return new MvcHtmlString($"<a class=\"empty-link\" data-toggle=\"{toggleTarget}\" data-target=\"{encodedTarget}/\" {attribs} id=\"user_{encodedTarget}\">{text}</a>");
        }

        public static MvcHtmlString AnonymousObjectToAttributeString(this HtmlHelper helper, object obj)
        {
            StringBuilder outputAttributes = new StringBuilder();
            if (obj != null)
            {
                var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(obj);

                foreach (var key in attributes.Keys)
                {
                    if (attributes[key] != null)
                    {
                        outputAttributes.Append($" {key}=\"{attributes[key].ToString()}\"");
                    }
                }
            }

            return new MvcHtmlString(outputAttributes.ToString());
        }

        public static AjaxHelper GetAjaxHelper(this HtmlHelper helper)
        {
            return new AjaxHelper(helper.ViewContext, new ViewPage());
        }
    }
}
