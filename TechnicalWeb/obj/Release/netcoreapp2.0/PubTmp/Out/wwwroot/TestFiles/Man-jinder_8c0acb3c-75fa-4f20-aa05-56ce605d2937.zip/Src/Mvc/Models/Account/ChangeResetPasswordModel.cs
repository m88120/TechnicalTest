﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Aushub.Mvc.Models
{
    public class ChangeResetPasswordModel
    {
        public bool IsValid { get; set; }
        public string Token { get; set; }

        [Required(ErrorMessage = "Neues Kennwort darf nicht leer sein")]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; }

        [Required(ErrorMessage = "Bestätigungs-Kennwort darf nicht leer sein")]
        [DataType(DataType.Password)]
        [Compare("NewPassword")]
        public string NewPasswordRepeat { get; set; }

        public string Message { get; set; }
        public string Type { get; set; }
        public bool Success { get; set; }
    }
}