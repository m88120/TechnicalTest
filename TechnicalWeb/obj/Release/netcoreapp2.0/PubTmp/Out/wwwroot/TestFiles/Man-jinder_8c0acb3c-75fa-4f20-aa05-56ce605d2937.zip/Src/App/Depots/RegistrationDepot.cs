﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Collections;
using NPoco;

namespace Aushub.App.Depots
{
    public class RegistrationDepot : BaseDepot<Registration, int>, IRegistrationDepot
    {
        public RegistrationDepot(INPocoDbContext dbContext, IAuthorizationManager authorizationManager)
            : base(dbContext, authorizationManager)
        {
        }


    }
}

