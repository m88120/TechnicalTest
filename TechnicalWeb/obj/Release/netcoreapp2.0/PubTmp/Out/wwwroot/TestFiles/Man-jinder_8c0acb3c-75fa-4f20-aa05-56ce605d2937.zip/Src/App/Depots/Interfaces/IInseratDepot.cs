using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Aushub.App.Depots
{
    public interface IInseratDepot : IDepot<Inserat, int>
    {
        List<Inserat> GetAll();
        List<Inserat> GetByFirmenId(int firmenId);
        List<Inserat> GetActiveInseratsByFirmenId(int firmenId);
        List<Inserat> GetAllListItemRecords(int id);
        List<Inserat> GetByKategorieId(int kategorieId);
        List<Inserat> GetBySubkategorieId(int subkategorieId);
        PagedList<InseratView> GetInseratPaged(InseratSearchAndPagingParameters searchAndPaging);
        InseratView GetViewById(int id);
    }
}
