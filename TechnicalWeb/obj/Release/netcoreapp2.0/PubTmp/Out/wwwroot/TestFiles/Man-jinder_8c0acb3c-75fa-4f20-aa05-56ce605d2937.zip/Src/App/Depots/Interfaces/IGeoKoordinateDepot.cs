﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using Aushub.Shared.ViewModels;

namespace Aushub.App.Depots
{
    public interface IGeoKoordinateDepot : IDepot<GeoKoordinate, int>
    {
        List<GeoKoordinate> GetByPlzOrt(string Postleitzahl, string Ort);
        List<GeoKoordinate> SearchCity(string search, int maxItemsCount);
        PagedList<GeoKoordinatenView> GetGeoKoordinatenPaged(GeoKoordinatenSearchAndPagingParameters searchAndPaging);

    }
}
