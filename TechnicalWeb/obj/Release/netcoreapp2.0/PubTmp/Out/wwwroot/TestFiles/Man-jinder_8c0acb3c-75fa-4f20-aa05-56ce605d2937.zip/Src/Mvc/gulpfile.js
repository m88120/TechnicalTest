﻿/// <binding BeforeBuild='compile-sass, copy-js' ProjectOpened='watch' />
var gulp = require('gulp');
var sass = require('gulp-sass');
var rename = require('gulp-rename');
var minifyCss = require('gulp-clean-css');
var concat = require('gulp-concat');
var uglify = require('gulp-uglify');
var plumber = require('gulp-plumber');
var notify = require('gulp-notify');

var sassSourcePath = './Content/sass/';
var sassMainFile = 'styles.scss';
var jsSourcePath = './Content/js/';
var baseDistPath = './dist/';
var nodePath = './node_modules/';
var extPath = './ext_modules/';
var externalModulePath = './Content/external-modules/';
var jsMainFile = 'app.js';

var watchers = [
    {
        path: sassSourcePath + '**/*.scss',
        tasks: ['compile-sass']
    },
    {
        path: jsSourcePath + '/**/*.js',
        tasks: ['copy-js']
    }
];

var jsToInclude = [
    nodePath + 'jquery/dist/jquery.js',
    nodePath + 'jquery-ajax-unobtrusive/jquery.unobtrusive-ajax.js',
    nodePath + 'jquery-ui/ui/widgets/datepicker.js',
    nodePath + 'jquery-ui/ui/i18n/datepicker-de.js',
    nodePath + 'jquery-validation/dist/jquery.validate.js',
    // nodePath + 'jquery-validation-unobtrusive/jquery.validate.unobtrusive.js', // Hat noch Probleme mit DateTime / Zeit
    nodePath + 'dropzone/dist/dropzone.js',
    nodePath + 'formatter.js/dist/jquery.formatter.js',
    nodePath + 'jquery-address/src/jquery.address.js',
    nodePath + 'jquery.dirtyforms/jquery.dirtyforms.js',
    nodePath + 'bootstrap/dist/js/bootstrap.min.js',
    externalModulePath + 'js-autocomplete/*.js',
    jsSourcePath + '**/*.js'
];

var imagesToInclude = [
    nodePath + 'jquery-ui-dist/images/*.*'
];

var externalCss = [
    externalModulePath + 'js-autocomplete/*.css',
    nodePath + 'jquery-ui-dist/jquery-ui.min.css',
    nodePath + 'jquery-ui-dist/jquery-ui.structure.css',
    nodePath + 'jquery-ui-dist/jquery-ui.theme.css',
    nodePath + 'bootstrap/dist/css/bootstrap.min.css',
	nodePath + 'dropzone/dist/dropzone.css',
    nodePath + 'jquery-ui/themes/base/datepicker.css'
];

gulp.task('compile-sass', ['copy-images', 'external-css-to-sass'], function (cb) {
    return gulp.src(sassSourcePath + sassMainFile)
        .pipe(plumber({
            errorHandler: plumberErrorHandler
        }))
        .pipe(sass({
            errLogToConsole: true,
            outputStyle: 'expanded'
        })).on('error', sass.logError)
        .pipe(gulp.dest(baseDistPath + '/css/'))
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(minifyCss())
        .pipe(gulp.dest(baseDistPath + '/css/'));
});

gulp.task('copy-images', function (cb) {

    return gulp.src(imagesToInclude)
        .pipe(plumber({
            errorHandler: plumberErrorHandler
        }))
        .pipe(gulp.dest(baseDistPath + '/css/images/'));
});

gulp.task('external-css-to-sass', function (cb) {
    return gulp.src(externalCss)
        .pipe(rename({
            prefix: '_',
            extname: '.scss'
        }))
        .pipe(gulp.dest(sassSourcePath + 'from-external-modules-css/'));
});

gulp.task('copy-js', function (cb) {

    return gulp.src(jsToInclude)
        .pipe(plumber({
            errorHandler: plumberErrorHandler
        }))
        .pipe(concat(jsMainFile))
        .pipe(gulp.dest(baseDistPath + '/js/'))
        .pipe(rename({
            suffix: '.min'
        }))
        .pipe(uglify())
        .pipe(gulp.dest(baseDistPath + '/js/'));
});

gulp.task('watch', function () {
    watchers.forEach(function (watcher) {
        gulp.watch(watcher.path, watcher.tasks);
    });
});

function plumberErrorHandler(err) {
    console.log(err.toString());
    notify.onError({
        title: "Gulp error in " + err.plugin,
        message: err.toString()
    })(err);
    this.emit('end');
}