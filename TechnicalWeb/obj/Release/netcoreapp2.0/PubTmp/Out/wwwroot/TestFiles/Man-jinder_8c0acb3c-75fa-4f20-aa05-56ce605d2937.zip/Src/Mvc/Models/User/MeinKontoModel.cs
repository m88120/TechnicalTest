﻿using Aushub.Shared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Aushub.Mvc.Models
{
    public class MeinKontoModel
    {
        public UserModel MeinUser { get; set; }
        public Firma MeineFirma { get; set; }
        public List<User> MeineKollegen { get; set; }
        public List<Inserat> UnsereInserate { get; set; }

    }
}