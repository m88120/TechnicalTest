using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using Aushub.App.Depots;
using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Shared.Services;
using FluentValidation;
using Comitas.CAF.Core.Collections;
using Aushub.Shared.SearchAndPaging;
using System.Net.Mail;
using Comitas.CAF.Core.Data;
using Aushub.Shared;

namespace Aushub.App.Services
{
	public class UserService : NPocoBaseService<IUserDepot, User, int>, IUserService
	{
        Config config;

        public UserService(Config config, IUserDepot baseDepot, IValidatorFactory validatorFactory, IMailService mailService, IAuthorizationManager authorizationManager) 
		    : base(baseDepot, validatorFactory, mailService, authorizationManager)
        {
            this.config = config;
        }

        public List<User> GetAllByRole(string roleKey)
        {
            return Depot.GetAllByRole(roleKey); 
        }

        public User GetByEmail(string email)
        {
            return Depot.GetByEmail(email);
        }

        public User GetSystemUser()
        {
            return Depot.GetSystemUser();
        }

        public PagedList<UserView> GetUserPaged(UserSearchAndPagingParameters searchAndPaging, bool selCrit)
        {
            return Depot.GetUserPaged(searchAndPaging, selCrit);
        }

        public int? GetFirmenIdForUser(int userId)
        {
            return Depot.GetById(userId).FIId;
        }

        public List<User> GetByFirmenId(int? firmenId, bool withSystemUsers)
        {
            return Depot.GetByFirmenId(firmenId, withSystemUsers);
        }

        public void Save(User entity)
        {
            if (entity.IsTransient)
            {
                User checkEmail = GetByEmail(entity.Email);
                if (checkEmail != null)
                {
                    throw new ValidationException("Ein Benutzer mit dieser Mailadresse existiert bereits.");
                }
            }

            Depot.Save(entity);
        }

        public void Delete(User entity)
        {
            Depot.Delete(entity);
        }

        public void Delete(int id)
        {
            Depot.Delete(id);
        }

        public void DeactivateUser(int id)
        {
            User user = GetById(id);

            if (user != null)
            {
                user.DeactivatedUserId = AuthorizationManager.GetUserId();
                user.DeactivatedDate = DateTime.Now;
                user.LI_UserstatusId = (int)ListItem.UserstatusPositionEnum.Inaktiv;
                Depot.Save(user);
            }
        }

        public void ActivateUser(int id)
        {
            User user = GetById(id);

            if (user != null)
            {
                user.DeactivatedDate = null;
                user.LI_UserstatusId = (int)ListItem.UserstatusPositionEnum.Aktiv;
                Depot.Save(user);
            }
        }

        public void RefuseUser(int id)
        {
            User user = GetById(id);

            if (user != null)
            {
                user.DeactivatedUserId = AuthorizationManager.GetUserId();
                user.DeactivatedDate = DateTime.Now;
                user.LI_UserstatusId = (int)ListItem.UserstatusPositionEnum.Abgelehnt;
                Depot.Save(user);
            }
        }

        #region "ISecurityManager"

        public void ValidateAndSetUserPassword(User user, string password)
        {
            if (!String.IsNullOrWhiteSpace(password) && password.Length >= config.MinimumPasswordLength)
            {
                user.HashAndAssignPassword(password);
            }
            else
            {
                throw new ValidationException($"Das Kennwort muss zumindest {config.MinimumPasswordLength} Zeichen lang sein.");
            }
        }

        public ISecurityUser GetUser(string identifier)
        {
            return GetByEmail(identifier);
        }

        public ISecurityUser GetUserByPasswordResetToken(string token)
        {
            return Depot.GetUserByPasswordResetToken(token);
        }

        public void SendPasswordResetLink(ISecurityUser user, string resetUrlWithTokenPlaceholder)
        {
            SendPasswordMail(user, resetUrlWithTokenPlaceholder, GetResetMailText, GetResetMailSubject);
        }


        public void SendPasswordSetupLink(ISecurityUser user, string resetUrlWithTokenPlaceholder)
        {
            SendPasswordMail(user, resetUrlWithTokenPlaceholder, GetSetupMailText, GetSetupMailSubject);
        }

        private void SendPasswordMail(ISecurityUser user, string resetUrlWithTokenPlaceholder, Func<string, User, string> getMailText, Func<string> getMailSubject)
        {
            if (!resetUrlWithTokenPlaceholder.Contains("{{Token}}"))
                throw new ArgumentException("Die URL zum Zur�cksetzen des Kennworts beinhaltet keinen Token Platzhalter ({{Token}}).");

            string token = user.StartPasswordResetRequest();
            Depot.Save(user as User);

            User fullUser = user as User;

            MailMessage resetMessage = new MailMessage();
            resetMessage.To.Add(user.Email);
            resetMessage.Subject = getMailSubject();

            string link = resetUrlWithTokenPlaceholder.Replace("{{Token}}", token);
            string message = getMailText(link, fullUser);

            resetMessage.Body = "<div>" + message + "</div>";
            resetMessage.IsBodyHtml = true;

            MailService.Send(resetMessage);
        }

        private string GetSetupMailSubject()
        {
            return $"Aushub24";
        }

        private string GetResetMailSubject()
        {
            return $"Aushub24: Anforderung zum Kennwort zur�cksetzen";
        }

        private string GetSetupMailText(string link, User user)
        {
            string message = $"Sehr geehrter Benutzer,<br/><br />Wir erlauben uns, Ihnen folgende Informationen und Anleitungen, betreffend Ihren individuellen Portaleinstellungen, zukommen zu lassen .<br/><br />";
            message += "Um Ihre Zugangsberechtigungen zu erhalten, klicken Sie bitte auf folgenden Link und befolgen Sie dann die weiteren Instruktionen:<br/><br />";
            message += $"<a href=\"{link}\">Ihre Portal Kennwort Einstellungen</a>";
            message += GetSignature();
            return message;
        }

        private string GetResetMailText(string link, User user)
        {
            string message = $"Sehr geehrter Benutzer,<br/><br />Sie haben ein Zur�cksetzen Ihres Kennworts f�r das Portal angefordert.<br/><br />";
            message += "Um fortzusetzen, klicken Sie bitte auf folgenden Link:<br/><br />";
            message += $"<a href=\"{link}\">Ihre Portal Kennwort Einstellungen</a>";
            
            message += GetSignature();
            return message;
        }

        private string GetSignature()
        {
            string sig = "<br /><br />Sollten Sie noch Fragen haben, antworten Sie bitte einfach auf dieses E-Mail oder rufen Sie uns an.<br/><br />";
            sig += $"Mit freundlichen Gr�ssen,<br/><br />Ihr Portal Team";
            sig = "<br/><br/><span style=\"color:#bea25a;font-weight:bold;\">Aushub24</span>";
            sig += "<br/>Z�richstrasse 1 | 8000 Zurich | Switzerland";
            sig += "<br/>Tel + 41 45 555 15555750 | Fax + 41 46 5555 5555 | info@aushub24.ch<br/>";
            
            return sig;
        }

        public void FinishPasswordResetRequest(ISecurityUser user, string newPassword)
        {
            user.HashAndAssignPassword(newPassword);
            user.FinishPasswordResetRequest();
            Depot.Save(user as User);
        }

        private void Depot_CreateUpdateUserNotFound(object sender, CreateUpdateUserEventArgs e)
        {
            e.UserToUse = Depot.GetSystemUser().Id;
        }

        public bool SignIn(ISecurityUser user, string password, string authenticationType)
        {
            var typedUser = user as User;

            if (typedUser != null)
            {
                Depot.CreateUpdateUserNotFound += Depot_CreateUpdateUserNotFound;
                typedUser.LastLogin = DateTime.UtcNow;
                Depot.Save(typedUser);
            }

            return true;
        }

        public bool SignIn(ISecurityUser user, string password, bool isPersistant, string authenticationType)
        {
            return SignIn(user, password, authenticationType);
        }

        public bool SignIn(string identifier, string password, string authenticationType)
        {
            return SignIn(GetUser(identifier), password, authenticationType);
        }

        public void SignOut()
        {

        }

        public bool ValidateLoginData(string identifier, string password)
        {
            User user = GetUser(identifier) as User;

            if (user == null || user.DeactivatedDate.HasValue)
            {
                return false;
            }

            return user.Password == User.HashPassword(password, user.Salt);
        }

        #endregion

        public void SendMail(User user, string message, string receiver, string subject)
        {
            MailMessage publicationMessage = new MailMessage();
            publicationMessage.To.Add(receiver);
            publicationMessage.ReplyToList.Add(user.Email);
            publicationMessage.Subject = subject;

            publicationMessage.Body = "<div>" + message + "</div>";
            publicationMessage.IsBodyHtml = true;

            MailService.Send(publicationMessage);
        }

        public List<User> GetAllListItemRecords(int id)
        {
            return Depot.GetAllListItemRecords(id);
        }


    }
}

