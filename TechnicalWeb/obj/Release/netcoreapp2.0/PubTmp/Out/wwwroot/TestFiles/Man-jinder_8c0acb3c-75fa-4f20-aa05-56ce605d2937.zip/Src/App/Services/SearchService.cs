﻿using Aushub.App.Depots;
using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Shared.Services;
using Aushub.Shared.SearchAndPaging;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Collections;
using FluentValidation;


namespace Aushub.App.Services
{
    public class SearchService : NPocoBaseService<ISearchDepot, Inserat, int>, ISearchService
    {
        public SearchService(ISearchDepot baseDepot, IValidatorFactory validatorFactory, IMailService mailService, IAuthorizationManager authorizationManager)
        : base(baseDepot, validatorFactory, mailService, authorizationManager)
        {
        }

        public PagedList<InseratView> GetSearchPaged(SearchSearchAndPagingParameters searchAndPaging)
        {
            return Depot.GetSearchPaged(searchAndPaging);
        }

        public List<InseratView> GetMapsSearch(SearchSearchAndPagingParameters searchAndPaging)
        {
            return Depot.GetMapsSearch(searchAndPaging);
        }

        public InseratView GetViewById(int id)
        {
            return Depot.GetViewById(id);
        }

    }
}
