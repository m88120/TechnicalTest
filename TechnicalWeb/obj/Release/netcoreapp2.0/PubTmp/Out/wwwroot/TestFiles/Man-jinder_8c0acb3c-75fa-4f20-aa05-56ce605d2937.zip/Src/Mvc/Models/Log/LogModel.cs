﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Aushub.Mvc.Models.Base;
using System.ComponentModel.DataAnnotations;

namespace Aushub.Mvc.Models
{
    public class LogModel : BaseEntityModel
    {
        public DateTime Timestamp { get; set; }
        public int? USId { get; set; }
        public string Displayname { get; set; }
        public string Message { get; set; }
        public string Module { get; set; }
    }
}