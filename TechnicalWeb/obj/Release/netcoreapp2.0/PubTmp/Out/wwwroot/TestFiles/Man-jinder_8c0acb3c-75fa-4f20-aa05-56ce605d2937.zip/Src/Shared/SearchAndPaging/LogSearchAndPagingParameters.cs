﻿using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Aushub.Shared.SearchAndPaging
{
    public class LogSearchAndPagingParameters : SearchAndPagingParameters
    {
        public string Module { get; set; }
        public string Message { get; set; }
        public string Von { get; set; }
        public string Bis { get; set; }
        public List<string> Modules { get; set; }


        public LogSearchAndPagingParameters() : base()
        {
            PageSize = 15;
            Modules = new List<string>();
        }

    }
}
