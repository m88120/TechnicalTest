﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aushub.Shared.Entities;
using Aushub.Shared.Services;
using Aushub.Shared.Enums;
using Aushub.Mvc.Models.Base;

namespace Aushub.Mvc.Models
{
    public class AdModel : BaseEntityModel
    {
        public int? FIId { get; set; }

        [Display(Name = "Was?")]
        public int IKId { get; set; }
        public List<InseratsKategorie> Kategorien { get; internal set; }
        public IEnumerable<SelectListItem> DropdownKategorien => new SelectList(Kategorien, "Id", "Kategorie");
        public string Kategorie { get; set; }

        public int ISId { get; set; }
        public List<InseratsSubkategorie> Subkategorien { get; internal set; }
        public IEnumerable<SelectListItem> DropdownSubkategorien => new SelectList(Subkategorien, "Id", "Subkategorie");
        public string Subkategorie { get; set; }

        [Display(Name = "Was möchten Sie erstellen?")]
        public int LI_InseratstypId { get; set; }
        public int VerkaufId;
        public int AnkaufId;
        public int BieteTransportId;
        public int BenoetigeTransportId;
        public List<ListItem> InseratstypListItems { get; set; }
        public IEnumerable<SelectListItem> DropdownInseratstyp => new SelectList(InseratstypListItems, "Id", "Bezeichnung");
        public string Transporttyp { get; set; }
        public string Inseratstyp { get; set; }

        [Display(Name = "Möchten Sie Bilder hochladen?")]
        public string Bild1 { get; set; }

        public string Bild2 { get; set; }

        public string Bild3 { get; set; }

        [Display(Name = "Möchten Sie ein Dokument hochladen?")]
        public string Dokument { get; set; }

        public string Beschreibung { get; set; }

        [Display(Name = "Wo?")]
        public string Postleitzahl { get; set; }

        public string Ort { get; set; }
        public string Adresse { get; set; }
        public string PLZId { get; set; }

        public float Longitude { get; set; }

        public float Latitude { get; set; }

        [Display(Name = "Kontaktperson?")]
        public int US_KontaktId { get; set; }
        public List<User> ContactsInCompany { get; internal set; }
        public IEnumerable<SelectListItem> DropdownContactsInCompany => new SelectList(ContactsInCompany, "Id", "DisplayName");
        public string Kontakt { get; set; }

        public bool MailadresseAnzeigen { get; set; }
        public string Mailadresse { get; set; }

        public bool TelefonAnzeigen { get; set; }
        public string Telefon { get; set; }

        public bool MobilnummerAnzeigen { get; set; }
        public string Mobilnummer { get; set; }


        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd.MM.yyyy}")]
        public DateTime? VerfuegbarAb { get; set; }
        public Verfuegbarkeit IstVerfuegbarAb { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd.MM.yyyy}")]
        public DateTime? VerfuegbarBis { get; set; }
        public Verfuegbarkeit IstVerfuegbarBis { get; set; }

        public int VerfuegbareMenge { get; set; }
        public int LI_MengeneinheitId { get; set; }
        public List<ListItem> MengeneinheitListItems { get; set; }
        public IEnumerable<SelectListItem> DropdownMengeneinheit => new SelectList(MengeneinheitListItems, "Id", "Bezeichnung");
        public string Mengeneinheit { get; set; }

        public Zahlungsart Zahlungsbedingung { get; set; }
        public Decimal? IchZahleDemAbnehmerDenPreis { get; set; }
        public Decimal? DerAbnehmerZahltDenPreis { get; set; }

        public int LI_InseratstatusId { get; set; }
        public List<ListItem> InseratstatusListItems { get; set; }
        public IEnumerable<SelectListItem> DropdownInseratstatus => new SelectList(InseratstatusListItems, "Id", "Bezeichnung");

        public int LI_InseratTeilenAufId { get; set; }
        public List<ListItem> InseratTeilenAufListItems { get; set; }
        public IEnumerable<SelectListItem> DropdownInseratTeilenAuf => new SelectList(InseratTeilenAufListItems, "Id", "Bezeichnung");

        public DateTime CreateDate { get; set; }
        [Display(Name = "Angebot erstellt durch:")]
        public int CreateUserId { get; set; }
        public string CreateUserDisplayName { get; set; }

        public DateTime? UpdateDate { get; set; }
        public int? UpdateUserId { get; set; }
        public string UpdateUserDisplayName { get; set; }

        public DateTime LastEditDate => UpdateDate.HasValue ? (DateTime)UpdateDate : CreateDate;

        public string Transport_PLZ_Von { get; set; }
        public string Transport_Ort_Von { get; set; }
        public string AdresseVon { get; set; }
        public string PLZIdVon { get; set; }

        public string Transport_PLZ_Bis { get; set; }
        public string Transport_Ort_Bis { get; set; }
        public string AdresseBis { get; set; }
        public string PLZIdBis { get; set; }
    }

}