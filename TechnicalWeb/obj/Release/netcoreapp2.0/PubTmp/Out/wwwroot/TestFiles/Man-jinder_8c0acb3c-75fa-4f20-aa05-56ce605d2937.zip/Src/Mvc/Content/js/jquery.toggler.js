﻿var togglerClass = 'toggler';
var togglerOpenClass = 'toggler-open';
var togglerClosedClass = 'toggler-closed';
var dataToggleContainerKey = 'data-toggleContainer';

function registerTogglers() {
    $('.' + togglerClass + ', .' + togglerOpenClass + ', .' + togglerClosedClass).toggler();
}

(function ($) {
    $.fn.toggler = function (action) {

        return this.each(function () {
            var element = $(this);

            if (typeof (action) === 'undefined') {
                init(element);

            } else if (action === 'init') {
                init(element);

            } else if (action === 'toggle') {
                toggle(element);

            } else if (action === 'open') {
                toggle(element, true);

            } else if (action === 'close') {
                toggle(element, false);

            } else {
                alert('action ist nicht definiert: ' + action);
            }
        });

        //
        // Private Functions
        //

        function init(element) {
            // event registrieren (und sicherstellen, dass der Event nicht mehrfach definiert ist)
            element.off('click');
            element.on('click', function (e) {
                e.preventDefault();
                toggle($(this));
            });

            // Initial auf / zuklappen
            toggle(element, $(element).hasClass(togglerOpenClass));
        }

        function toggle(element, open) {
            // falls kein open Parameter angegeben wurde, wird der neue Status anhand der Class ermittelt
            if (typeof (open) !== 'boolean') {
                open = !element.hasClass(togglerOpenClass);
            }

            // ToggleContainer anhand von Data-Attribut ermitteln
            var toggleContainerSelector = element.attr(dataToggleContainerKey);

            if (typeof (toggleContainerSelector) === 'undefined' || toggleContainerSelector === null) {
                alert('Es ist kein "data-toggleContainer" definiert.');
            } else {
                // Container einblenden
                if (open) {
                    $(toggleContainerSelector).show();
                } else {
                    $(toggleContainerSelector).hide();
                }

                // alle toggler Classes entfernens
                element.removeClass(togglerOpenClass);
                element.removeClass(togglerClosedClass);

                // die neue toggler Class hinzufuefen
                element.addClass(open ? togglerOpenClass : togglerClosedClass);
            }
        }
    };

}(jQuery));