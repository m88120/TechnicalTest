﻿
namespace Aushub.Mvc.Models.Base
{
    public abstract class BaseEntityModel
    {
        public int Id { get; set; }

        public bool IsTransient
        {
            get
            {
                return Id == 0;
            }
        }
    }
}