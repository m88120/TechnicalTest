using Aushub.App.Depots;
using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Shared.Services;
using Aushub.Shared.SearchAndPaging;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Collections;
using FluentValidation;


namespace Aushub.App.Services
{
    public class InseratService : NPocoBaseService<IInseratDepot, Inserat, int>, IInseratService
    {
        public InseratService(IInseratDepot baseDepot, IValidatorFactory validatorFactory, IMailService mailService, IAuthorizationManager authorizationManager)
        : base(baseDepot, validatorFactory, mailService, authorizationManager)
        {
        }

        public void Save(Inserat entity)
        {
            Depot.Save(entity);
        }

        public List<Inserat> GetByFirmenId(int firmenId)

        {
            return Depot.GetByFirmenId(firmenId);
        }

        public List<Inserat> GetByKategorieId(int kategorieId)

        {
            return Depot.GetByKategorieId(kategorieId);
        }

        public List<Inserat> GetBySubkategorieId(int subkategorieId)

        {
            return Depot.GetBySubkategorieId(subkategorieId);
        }

        public List<Inserat> GetAllListItemRecords(int id)
        {
            return Depot.GetAllListItemRecords(id);
        }

        public PagedList<InseratView> GetInseratPaged(InseratSearchAndPagingParameters searchAndPaging)
        {
            return Depot.GetInseratPaged(searchAndPaging);
        }

        public InseratView GetViewById(int id)
        {
            return Depot.GetViewById(id);
        }

        public void Delete(int id)
        {
            // Zuvor Images und Dokument l�schen falls vorhanden

            // Depot.Delete(id);
        }

    }
}

