using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Collections;
using NPoco;

namespace Aushub.App.Depots
{
    public class InseratDepot : PagingDepot<Inserat, InseratView, int>, IInseratDepot
    {
        public InseratDepot(INPocoDbContext dbContext, IAuthorizationManager authorizationManager)
            : base(dbContext, authorizationManager)
        {
        }
        public List<Inserat> GetAll()
        {
            Sql select = GetBaseSelectSql();
            return Database.Query<Inserat>(select).ToList();
        }

        public List<Inserat> GetByKategorieId(int kategorieId)
        {
            return Database.Query<Inserat>(GetBaseSelectSql()).Where(x => x.IKId == kategorieId).ToList();
        }

        public List<Inserat> GetBySubkategorieId(int subkategorieId)
        {
            return Database.Query<Inserat>(GetBaseSelectSql()).Where(x => x.ISId == subkategorieId).ToList();
        }

        public List<Inserat> GetByFirmenId(int firmenId)
        {
            return Database.Query<Inserat>(GetBaseSelectSql()).Where(x => x.FIId == firmenId).ToList();
        }

        public List<Inserat> GetActiveInseratsByFirmenId(int firmenId)
        {
            return Database.Query<Inserat>(GetBaseSelectSql()).Where(x => x.FIId == firmenId && x.LI_InseratstatusId == (int)ListItem.InseratstatusEnum.Aktiv).ToList();
        }

        public List<Inserat> GetAllListItemRecords(int id)
        {
            Sql select = Sql.Builder.Select("*").From("Inserate");

            select = select.Where("IN_LI_Inseratstyp_Id = @Id OR IN_LI_Mengeneinheit_Id = @Id OR IN_LI_Inseratstatus_Id = @Id OR IN_LI_InseratTeilenAuf_Id = @Id", new { Id = id });

            return Database.Fetch<Inserat>(select).ToList();
        }

        public PagedList<InseratView> GetInseratPaged(InseratSearchAndPagingParameters searchAndPaging)
        {
            Sql select = GetViewBaseSelectSql();

            if (searchAndPaging.FIId.HasValue)
                select = select.Where("IN_FI_Id = @Id", new { Id = searchAndPaging.FIId });

            if (searchAndPaging.UserId.HasValue)
                select = select.Where("IN_CreateUser_Id = @UId OR IN_UpdateUser_Id = @UId OR IN_US_Kontakt_Id = @UId", new { UId = searchAndPaging.UserId });

            return GetPagedAuto(searchAndPaging, select, "ISNULL(IN_UpdateDate, IN_CreateDate) DESC");
        }

        public InseratView GetViewById(int id)
        {
            Sql select = GetViewBaseSelectSql();
            return Database.Query<InseratView>(select).Where(x => x.Id == id).SingleOrDefault();
        }

        private Sql GetViewBaseSelectSql()
        {
            string s = string.Empty;
            Sql select;

            s = "'<p><strong>' + IK.IK_Kategorie + ' - ' + ISU.IS_Subkategorie + '</strong></p>";
            s += "<p><strong>Typ:</strong>&nbsp;' + LI1.LI_Bezeichnung + '</p>";
            s += "<p><strong>Ort:</strong>&nbsp;' + RTRIM(LTRIM(ISNULL(INS.IN_Postleitzahl, '') + ' ' + ISNULL(INS.IN_Ort, ''))) + '</p>";
            s += "<p><strong>Kontakt:</strong>&nbsp;' + LTRIM(RTRIM(ISNULL(USK.US_Firstname, '') + ' ' + ISNULL(USK.US_Lastname, ''))) + '</p>";
            s += "<p><strong>Tel/Mobile:</strong>&nbsp;' + CASE WHEN ISNULL(IN_MobilnummerAnzeigen, 0) <> 0 THEN ISNULL(USK.US_MobilNumber, '') ELSE ISNULL(USK.US_Telefon, '') END + '</p>' AS IN_Content";

            string[] columns = new string[]
            {
                "INS.*",
                "IK.IK_Kategorie AS IN_Kategorie",
                "ISU.IS_Subkategorie AS IN_Subkategorie",
                "ISNULL(IK.IK_Kategorie, '') + ' / ' + ISNULL(ISU.IS_Subkategorie, '') AS IN_Title",
                "10 AS IN_ZIndex",
                s,
                "CASE WHEN INS.IN_Bild1 IS NOT NULL THEN INS.IN_Bild1 ELSE ISU.IS_Standardbild END AS IN_Bild",
                "RTRIM(LTRIM(ISNULL(US.US_Firstname, '') + ' ' + ISNULL(US.US_Lastname, ''))) AS IN_Ersteller",
                "RTRIM(LTRIM(ISNULL(INS.IN_Postleitzahl, '') + ' ' + ISNULL(INS.IN_Ort, ''))) AS IN_PlzOrt",
                "FI.FI_Firmenname AS IN_Firmenname",
                "LI1.LI_Bezeichnung AS IN_Inseratstyp",
                "CASE WHEN INS.IN_Zahlungsbedingung = 1 THEN 'Verhandelbar' ELSE CASE WHEN INS.IN_Zahlungsbedingung = 4 THEN 'Kostenlos' ELSE LTRIM(RTRIM(CAST((ISNULL(INS.IN_IchZahleDemAbnehmerDenPreis, 0) - ISNULL(INS.IN_DerAbnehmerZahltDenPreis, 0)) AS varchar(20)))) END END AS IN_Preis",
                "INS.IN_VerfuegbareMenge AS IN_Menge"
            };

            select = Sql.Builder.Select(columns).From("Inserate AS INS")
                                                .LeftJoin("InseratsKategorien AS IK").On("INS.IN_IK_Id = IK.IK_ID")
                                                .LeftJoin("InseratsSubkategorien AS ISU").On("INS.IN_IK_Id = ISU.IS_IK_ID And INS.IN_IS_Id = ISU.IS_ID")
                                                .LeftJoin("Users AS US").On("INS.IN_CreateUser_Id = US.US_Id")
                                                .LeftJoin("Users AS USK").On("INS.IN_US_Kontakt_Id = USK.US_Id")
                                                .LeftJoin("Firmen AS FI").On("INS.IN_FI_Id = FI.FI_Id")
                                                .LeftJoin("ListItems AS LI1").On("INS.IN_LI_Inseratstyp_Id = LI1.LI_Id");

            return select;
        }

    }
}

