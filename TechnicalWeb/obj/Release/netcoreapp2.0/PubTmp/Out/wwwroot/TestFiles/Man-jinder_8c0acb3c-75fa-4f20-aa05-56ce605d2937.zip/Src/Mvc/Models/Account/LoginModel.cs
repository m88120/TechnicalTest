﻿using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Models
{
    public class LoginModel
    {
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Display(Name = "E-Mail")]
        public string Email { get; set; }

        public bool StayLoggedIn { get; set; }
        public string ReturnUrl { get; set; }
    }
}