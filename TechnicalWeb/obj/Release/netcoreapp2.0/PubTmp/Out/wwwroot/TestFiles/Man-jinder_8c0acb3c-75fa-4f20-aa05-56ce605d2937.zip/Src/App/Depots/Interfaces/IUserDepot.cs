using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Aushub.App.Depots
{
    public interface IUserDepot : IDepot<User, int>
    {
        User GetByEmail(string email);
        User GetUserByPasswordResetToken(string token);
        PagedList<UserView> GetUserPaged(UserSearchAndPagingParameters searchAndPaging, bool selCrit);
        User GetSystemUser();
        List<User> GetAllByRole(string roleKey);
        List<User> GetByFirmenId(int? firmenId, bool withSystemUsers);
        List<User> GetAllListItemRecords(int id);

    }
}
