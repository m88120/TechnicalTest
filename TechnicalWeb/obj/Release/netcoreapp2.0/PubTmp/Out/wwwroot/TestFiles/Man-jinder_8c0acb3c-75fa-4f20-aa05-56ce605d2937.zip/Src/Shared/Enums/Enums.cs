﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.Enums
{
    class Enums
    {
    }

    public enum Verfuegbarkeit
    {
        Sofort = 1,
        AbDatum = 2,
        BisDatum = 3,
        Offen = 4
    }

    public enum Zahlungsart
    {
        Verhandelbar = 1,
        IchZahleDemAbnehmer = 2,
        DerAbnehmerZahlt = 3,
        Kostenlos = 4
    }

    public enum Inseratstyp
    {
        Ankauf = 1,
        Verkauf = 2,
        BenoetigeTransport = 3,
        BieteTransport = 4
    }
}
