﻿using Comitas.CAF.Core.Collections;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using Aushub.Shared;
using Aushub.Shared.Services;
using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.SearchAndPaging;
using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Comitas.CAF.Core.Logging;
using System.Data;
using System.Globalization;

namespace Aushub.Mvc.Controllers
{
    [Authorize]
    public class SearchController : BaseController
    {
        IInseratService inserateService;
        IInseratsKategorieService inseratskategorienService;
        IInseratsSubkategorieService inseratssubkategorienService;
        ISearchService searchService;
        IUserService userService;
        IFirmaService firmenService;
        IListItemService listitemService;
        IMapper mapper;

        public SearchController(IInseratService inserateservice, IInseratsKategorieService inseratskategorienservice,
                                IInseratsSubkategorieService inseratssubkategorienservice, ISearchService searchservice,
                                IUserService userservice, IFirmaService firmenservice, IListItemService listitemservice, IMapper mapper)
        {
            this.inserateService = inserateservice;
            this.inseratskategorienService = inseratskategorienservice;
            this.inseratssubkategorienService = inseratssubkategorienservice;
            this.searchService = searchservice;
            this.userService = userservice;
            this.firmenService = firmenservice;
            this.listitemService = listitemservice;
            this.mapper = mapper;
        }

        public virtual ActionResult IndexInit(int? id, [Bind(Prefix = "s")] SearchSearchAndPagingParameters parameters)
        {
            BaseIndexModel<SearchModel, SearchDetailModel, SearchSearchAndPagingParameters> model = new BaseIndexModel<SearchModel, SearchDetailModel, SearchSearchAndPagingParameters>();

            if (parameters == null)
                parameters = new SearchSearchAndPagingParameters();

            InitializeSearchListboxes(parameters);

            model.MapListSerialized = string.Empty;
            model.Search = parameters;
            ViewBag.InitSearch = true;

            return View("Index", model);
        }

        public virtual ActionResult Index(int? id, [Bind(Prefix = "s")] SearchSearchAndPagingParameters parameters)
        {
            ViewBag.InitSearch = false;
            return View("Index", GetIndexViewModel(id, null, parameters));
        }

        protected BaseIndexModel<SearchModel, SearchDetailModel, SearchSearchAndPagingParameters> GetIndexViewModel(int? id, SearchDetailModel entityModel, SearchSearchAndPagingParameters parameters)
        {

            if (parameters == null)
                parameters = new SearchSearchAndPagingParameters();

            InitializeSearchListboxes(parameters);

            SearchDetailModel detailModel = GetDetailModel(id);

            // Query String mit GridView Parametern eigentlich nicht mehr notwendig!
            return new BaseIndexModel<SearchModel, SearchDetailModel, SearchSearchAndPagingParameters>()
            {
                PagedList = GetPagedEntites(parameters),
                MapListSerialized = new JavaScriptSerializer().Serialize(GetAllEntities(parameters)),
                Search = parameters,
                CurrentEntity = detailModel
            };
        }

        public PartialViewResult Load(int id, string distanz)
        {
            ModelState.Clear(); // Damit ggf. neue Id übernommen wird

            SearchDetailModel model = GetDetailModel(id);
            model.Distanz = distanz;

            return PartialView("SearchDetailPartial", model);
        }

        private SearchDetailModel GetDetailModel(int? id)
        {
            if (!id.HasValue)
                return null;

            InseratView view = searchService.GetViewById(id.Value);

            var model = view == null ? new SearchDetailModel() : mapper.Map<SearchDetailModel>(view);
            User aktKontakt = userService.GetById(model.US_KontaktId);
            model.Inseratstyp = listitemService.GetById(model.LI_InseratstypId).Bezeichnung;
            model.Kontakt = aktKontakt.DisplayName;
            model.Telefon = model.TelefonAnzeigen ? aktKontakt.Telefon : string.Empty;
            model.Mobil = model.MobilnummerAnzeigen ? aktKontakt.MobilNumber : string.Empty;
            model.EMail = model.MailadresseAnzeigen ? aktKontakt.Email : string.Empty;
            return model;
        }

        private void InitializeSearchListboxes(SearchSearchAndPagingParameters parameters)
        {
            parameters.Kategorien = inseratskategorienService.GetAll(false);
            parameters.Kategorien.Insert(0, new InseratsKategorie() { Id = 0, Kategorie = "Alle Kategorien" });
            parameters.Subkategorien = new List<InseratsSubkategorie>();
            parameters.Subkategorien.Clear();
            parameters.Subkategorien.Insert(0, new InseratsSubkategorie() { IKId = 0, Subkategorie = "Alle Subkategorien" });
            parameters.InseratstypListItems = listitemService.GetByListGroup(ListItem.Inseratstyp);
            parameters.InseratstypListItems.Insert(0, new ListItem() { Id = 0, Bezeichnung = "Alle Typen" });

            parameters.Firmen = firmenService.GetAll(false);
            parameters.Firmen.Insert(0, new Firma() { Id = 0, Firmenname = "Wählen Sie eine Firma ...", IsSystem = false, AufHomeAnzeigen = false });
            parameters.UmkreisVonList = new List<Umkreise>() {new Umkreise() { Id = 0, Umkreis = "Überall" },
                                                              new Umkreise() { Id = 10, Umkreis = "bis 10 km" },
                                                              new Umkreise() { Id = 20, Umkreis = "bis 20 km" },
                                                              new Umkreise() { Id = 30, Umkreis = "bis 30 km" },
                                                              new Umkreise() { Id = 40, Umkreis = "bis 40 km" },
                                                              new Umkreise() { Id = 50, Umkreis = "bis 50 km" },
                                                              new Umkreise() { Id = 60, Umkreis = "bis 60 km" },
                                                              new Umkreise() { Id = 70, Umkreis = "bis 70 km" },
                                                              new Umkreise() { Id = 80, Umkreis = "bis 80 km" },
                                                              new Umkreise() { Id = 90, Umkreis = "bis 90 km" },
                                                              new Umkreise() { Id = 100, Umkreis = "bis 100 km" }
                                                             };
        }

        public ActionResult GetGrid(SearchSearchAndPagingParameters searchAndPaging)
        {
            return PartialView("Grid", GetPagedEntites(searchAndPaging));
        }

        private PagedList<SearchModel> GetPagedEntites(SearchSearchAndPagingParameters searchAndPaging)
        {
            var pagedEntities = searchService.GetSearchPaged(searchAndPaging);

            return new PagedList<SearchModel>(mapper.Map<IEnumerable<InseratView>, IEnumerable<SearchModel>>(pagedEntities),
                                                         pagedEntities.PageIndex,
                                                         pagedEntities.PageSize,
                                                         pagedEntities.TotalCount);
        }

        private List<SearchMapsModel> GetAllEntities(SearchSearchAndPagingParameters searchAndPaging)
        {
            var entities = searchService.GetMapsSearch(searchAndPaging);
            return new List<SearchMapsModel>(mapper.Map<IEnumerable<InseratView>, IEnumerable<SearchMapsModel>>(entities));
        }

        public JsonResult GetSubkategorien(int IKId)
        {
            var subkategorienList = inseratssubkategorienService.GetByKategorieId(IKId);
            subkategorienList.Insert(0, new InseratsSubkategorie() { IKId = 0, Id = 0, Subkategorie = "Subkategorie ..." });
            return Json(subkategorienList, JsonRequestBehavior.AllowGet);
        }
        public ActionResult InseratMelden(int id)
        {

            SetSuccessMessage("Die Meldung wurde versendet.");

            return RedirectToAction("IndexInit");
        }

    }
}