﻿using Aushub.Shared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.ViewModels
{
    public class UserView : User
    {
        public string Firmenname { get; set; }
    }
}
