﻿using Aushub.Shared.Entities;
using Aushub.Mvc.Models.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Aushub.Mvc.Models
{
    public class UserModel : BaseEntityModel
    {
        public int? FIId { get; set; }
        public string Firmenname { get; set; }

        [Display(Name = "Anrede")]
        public int LI_SalutationId { get; set; }

        public string Firstname { get; set; }

        public string Lastname { get; set; }

        public string DisplayName => $"{Firstname} {Lastname}".Trim();
        public string Email { get; set; }

        [Display(Name = "Rolle")]
        public string RoleKey { get; set; }

        public DateTime? LastLogin { get; set; }
        public DateTime? DeactivatedDate { get; set; }
        public int? DeactivatedUserId { get; set; }
        public DateTime? PasswordResetRequestDate { get; set; }
        public bool IsSystemUser { get; set; }

        public bool IsActive => (DeactivatedDate == null);

        public string Telefon { get; set; }
        public string MobilNumber { get; set; }

        public bool HasAcceptedAGBs { get; set; }

        [Display(Name = "Benutzerstatus")]
        public int LI_UserstatusId { get; set; }
        public string Userstatus { get; set; }
        public bool WillSammelmailErhalten { get; set; }

        public UserModel()
        {
            IsSystemUser = false;
            WillSammelmailErhalten = true;
            RoleKey = Role.User;
            HasAcceptedAGBs = false;
            LI_UserstatusId = (int)ListItem.UserstatusPositionEnum.Registriert;
        }

    }
}

