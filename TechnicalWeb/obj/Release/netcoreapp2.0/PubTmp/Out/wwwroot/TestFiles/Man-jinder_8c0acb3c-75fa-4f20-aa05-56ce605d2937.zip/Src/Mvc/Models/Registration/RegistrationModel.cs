﻿using Aushub.Shared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Aushub.Mvc.Models
{
    public class RegistrationModel
    {
        public int UserId { get; set; }
        public int? FIId { get; set; }

        [Display(Name = "Persönliche Angaben")]
        public int LI_SalutationId { get; set; }
        public List<ListItem> SalutationListItems { get; set; }
        public IEnumerable<SelectListItem> DropdownSalutation => new SelectList(SalutationListItems, "Id", "Bezeichnung");

        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Email { get; set; }
        public string EmailRepeat { get; set; }
        public string Telefon { get; set; }
        public string MobilNumber { get; set; }
        public int FirmenId { get; set; }
        public string Firmenname { get; set; }

        [Display(Name = "Angaben zur Firma")]
        public string UID { get; set; }
        public string Adresse { get; set; }
        public string Strasse { get; set; }
        public string PLZId { get; set; }
        public string Postleitzahl { get; set; }
        public string Ort { get; set; }

        public bool HasAcceptedAGBs { get; set; }
        public string AGBs { get; set; }

    }
}