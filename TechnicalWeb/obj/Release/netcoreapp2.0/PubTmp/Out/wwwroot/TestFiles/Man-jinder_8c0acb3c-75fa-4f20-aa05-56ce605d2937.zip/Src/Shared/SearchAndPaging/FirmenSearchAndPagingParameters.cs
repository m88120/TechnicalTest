﻿using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.SearchAndPaging
{
    public class FirmenSearchAndPagingParameters : SearchAndPagingParameters
    {
        public string Firmenname { get; set; }
        public string Postleitzahl { get; set; }
        public string Ort { get; set; }
        public string UID { get; set; }
        public bool AufHomeAngezeigt { get; set; }
        public bool NichtAufHomeAngezeigt { get; set; }


        public FirmenSearchAndPagingParameters() : base()
        {
            PageSize = 15;
        }

    }
}
