﻿using Comitas.CAF.Core.Entities;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Utilities;
using Aushub.Shared.Templating;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.Entities
{
    [AutoGen]
    public class ListItem : BaseEntity<int>
    {
        public const string Inseratbezahlung = "Inseratbezahlung";
        public const string Inseratstatus = "Inseratstatus";
        public const string Inseratstyp = "Inseratstyp";
        public const string InseratTeilenAuf = "InseratTeilenAuf";
        public const string Userstatus = "Userstatus";
        public const string Salutation = "Salutation";
        public const string Mengeneinheit = "Mengeneinheit";

        public enum InseratstatusEnum
        {
            Aktiv = 20,
            Inaktiv = 21,
            Gelöscht = 22
        }

        public enum UserstatusPositionEnum
        {
            Registriert = 3,
            Aktiv = 4,
            Inaktiv = 5,
            Abgelehnt = 31
        }

        public string Gruppe { get; set; }
        public int Reihenfolge { get; set; }
        public string Bezeichnung { get; set; }
    }
}
