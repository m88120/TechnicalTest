using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.Core.Security;

namespace Aushub.Shared.Services
{
    public interface IUserService : IEntityIdService<User, int>, ISecurityManager
    {
        User GetByEmail(string email);
        PagedList<UserView> GetUserPaged(UserSearchAndPagingParameters searchAndPaging, bool selCrit);
        User GetSystemUser();
        List<User> GetAllByRole(string roleKey);
        int? GetFirmenIdForUser(int userId);
        List<User> GetByFirmenId(int? firmenId, bool withSystemUsers);

        void Save(User item);
        void Delete(int id);
        void Delete(User item);
        void DeactivateUser(int id);
        void ActivateUser(int id);
        void RefuseUser(int id);
        void SendPasswordSetupLink(ISecurityUser user, string resetUrlWithTokenPlaceholder);
        void ValidateAndSetUserPassword(User user, string password);

        void SendMail(User user, string message, string receiver, string subject);
        List<User> GetAllListItemRecords(int id);
    }
}
