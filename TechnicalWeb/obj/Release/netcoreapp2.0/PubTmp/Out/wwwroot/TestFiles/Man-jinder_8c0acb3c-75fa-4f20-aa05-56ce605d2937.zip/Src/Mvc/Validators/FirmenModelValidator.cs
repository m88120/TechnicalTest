﻿using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Aushub.Shared.Services;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Validators
{
    public class FirmenModelValidator : AbstractValidator<FirmenDetailModel>
    {
        IFirmaService firmenService;

        public FirmenModelValidator(IFirmaService firmenservice)
        {
            this.firmenService = firmenservice;

            RuleFor(x => x.Firmenname).NotEmpty().WithMessage("Firmenname darf nicht leer sein");
            RuleFor(x => x.UID).NotEmpty().WithMessage("UID darf nicht leer sein")
                               .Must(HaveAValidVAT).WithMessage("UID muss eine gültige ID sein")
                               .Must(NotBeADuplicateUID).WithMessage("UID ist bereits vorhanden");
            RuleFor(x => x.Postleitzahl).NotEmpty().WithMessage("Postleitzahl darf nicht leer sein");
            RuleFor(x => x.Ort).NotEmpty().WithMessage("Ort darf nicht leer sein");
            RuleFor(x => x.Strasse).NotEmpty().WithMessage("Strasse darf nicht leer sein");
        }

        private bool NotBeADuplicateUID(FirmenDetailModel model, string newValue)
        {
            var firma = firmenService.GetByUID(model.UID);

            return (firma == null || (firma != null && firma.UID == model.UID && firma.Id == model.Id));
        }

        private bool HaveAValidVAT(FirmenDetailModel model, string newValue)
        {
            if (string.IsNullOrWhiteSpace(model.UID))
                return true;

            PublicServices vatService = new PublicServices(); //Public Service of Government of Switzerland
            bool isValid = false;

            try
            {
                isValid = vatService.ValidateUID(model.UID);
            }
            catch (Exception err)
            {
                System.Diagnostics.Trace.TraceError(err.ToString());
            }

            return isValid;
        }
    }
}