﻿using Aushub.Mvc.Models;
using Aushub.Shared.Services;
using Aushub.Shared.Enums;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Validators
{
    public class AdModelValidator : AbstractValidator<AdModel>
    {
        IInseratService inseratService;

        public AdModelValidator(IInseratService inseratservice)
        {
            this.inseratService = inseratservice;

            RuleFor(x => x.IKId).NotEmpty().WithMessage("Kategorie darf nicht leer sein");
            RuleFor(x => x.ISId).NotEmpty().WithMessage("Subkategorie darf nicht leer sein");
            RuleFor(x => x.Postleitzahl).NotEmpty().WithMessage("Postleitzahl darf nicht leer sein");
            RuleFor(x => x.Ort).NotEmpty().WithMessage("Ort darf nicht leer sein");
            RuleFor(x => x.US_KontaktId).NotEmpty().WithMessage("Kontakt darf nicht leer sein");
            RuleFor(x => x.TelefonAnzeigen).Must(OneOfThePhonesMustExist).WithMessage("Entweder Telefon oder Mobilnummer muss ausgewählt sein");
            RuleFor(x => x.VerfuegbarAb).Must(DateMustExistIfAbButtonIsChecked).WithMessage("Wenn 'Verfügbar ab' ausgewählt wurde, muss auch ein Datum angegeben werden.");
            RuleFor(x => x.VerfuegbarBis).Must(DateMustExistIfBisButtonIsChecked).WithMessage("Wenn 'Verfügbar bis' ausgewählt wurde, muss auch ein Datum angegeben werden.");
            RuleFor(x => x.VerfuegbareMenge).NotEmpty().WithMessage("Es muss eine Menge angegeben werden");
            RuleFor(x => x.IchZahleDemAbnehmerDenPreis).Must(PriceMustExistIfIchButtonIsChecked).WithMessage("Wenn 'Ich zahle dem Abnehmer' ausgewählt wurde, muss auch ein Betrag angegeben werden.");
            RuleFor(x => x.DerAbnehmerZahltDenPreis).Must(PriceMustExistIfAbnehmerButtonIsChecked).WithMessage("Wenn 'Der Abnehmer zahlt' ausgewählt wurde, muss auch ein Betrag angegeben werden.");
            RuleFor(x => x.Transport_PLZ_Von).Must(PlzVonMustExistIfTypeIsTransport).WithMessage("Die Postleitzahl des Transportbeginns muss angegeben werden.");
            RuleFor(x => x.Transport_Ort_Von).Must(OrtVonMustExistIfTypeIsTransport).WithMessage("Der Ort des Transportbeginns muss angegeben werden.");
            RuleFor(x => x.Transport_PLZ_Bis).Must(PlzBisMustExistIfTypeIsTransport).WithMessage("Die Postleitzahl des Transportendes muss angegeben werden.");
            RuleFor(x => x.Transport_Ort_Bis).Must(OrtBisMustExistIfTypeIsTransport).WithMessage("Der Ort des Transportendes muss angegeben werden.");
        }

        private bool OneOfThePhonesMustExist(AdModel model, bool newValue)
        {
            return (model.TelefonAnzeigen || model.MobilnummerAnzeigen);
        }

        private bool DateMustExistIfAbButtonIsChecked(AdModel model, DateTime? newValue)
        {
            if (model.IstVerfuegbarAb == Verfuegbarkeit.AbDatum)
                return (!string.IsNullOrWhiteSpace(model.VerfuegbarAb.ToString()));
            else
                return true;
        }

        private bool DateMustExistIfBisButtonIsChecked(AdModel model, DateTime? newValue)
        {
            if (model.IstVerfuegbarBis == Verfuegbarkeit.BisDatum)
                return (!string.IsNullOrWhiteSpace(model.VerfuegbarBis.ToString()));
            else
                return true;
        }

        private bool PriceMustExistIfIchButtonIsChecked(AdModel model, Decimal? newValue)
        {
            if (model.LI_InseratstypId == (int)Inseratstyp.Ankauf || model.LI_InseratstypId == (int)Inseratstyp.Verkauf)
            {
                if (model.Zahlungsbedingung == Zahlungsart.IchZahleDemAbnehmer)
                    return (model.IchZahleDemAbnehmerDenPreis.HasValue && model.IchZahleDemAbnehmerDenPreis > 0);
            }

            return true;
        }

        private bool PriceMustExistIfAbnehmerButtonIsChecked(AdModel model, Decimal? newValue)
        {
            if (model.LI_InseratstypId == (int)Inseratstyp.Ankauf || model.LI_InseratstypId == (int)Inseratstyp.Verkauf)
            {
                if (model.Zahlungsbedingung == Zahlungsart.DerAbnehmerZahlt)
                    return (model.DerAbnehmerZahltDenPreis.HasValue && model.DerAbnehmerZahltDenPreis > 0);
            }

            return true;
        }

        private bool PlzVonMustExistIfTypeIsTransport(AdModel model, string newValue)
        {
            if (model.LI_InseratstypId == (int)Inseratstyp.BenoetigeTransport || model.LI_InseratstypId == (int)Inseratstyp.BieteTransport)
            {
                return (!string.IsNullOrWhiteSpace(model.Transport_PLZ_Von));
            }

            return true;
        }

        private bool OrtVonMustExistIfTypeIsTransport(AdModel model, string newValue)
        {
            if (model.LI_InseratstypId == (int)Inseratstyp.BenoetigeTransport || model.LI_InseratstypId == (int)Inseratstyp.BieteTransport)
            {
                return (!string.IsNullOrWhiteSpace(model.Transport_Ort_Von));
            }

            return true;
        }

        private bool PlzBisMustExistIfTypeIsTransport(AdModel model, string newValue)
        {
            if (model.LI_InseratstypId == (int)Inseratstyp.BenoetigeTransport || model.LI_InseratstypId == (int)Inseratstyp.BieteTransport)
            {
                return (!string.IsNullOrWhiteSpace(model.Transport_PLZ_Bis));
            }

            return true;
        }

        private bool OrtBisMustExistIfTypeIsTransport(AdModel model, string newValue)
        {
            if (model.LI_InseratstypId == (int)Inseratstyp.BenoetigeTransport || model.LI_InseratstypId == (int)Inseratstyp.BieteTransport)
            {
                return (!string.IsNullOrWhiteSpace(model.Transport_Ort_Bis));
            }

            return true;
        }

    }
}