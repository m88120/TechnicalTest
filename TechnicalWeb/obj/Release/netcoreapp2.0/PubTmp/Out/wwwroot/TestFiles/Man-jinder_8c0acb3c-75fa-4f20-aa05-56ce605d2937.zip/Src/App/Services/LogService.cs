﻿using Aushub.App.Depots;
using Aushub.Shared.Entities;
using Aushub.Shared.Services;
using Aushub.Shared.ViewModels;
using Aushub.Shared.SearchAndPaging;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Collections;
using FluentValidation;

namespace Aushub.App.Services
{
    public class LogService : NPocoBaseService<ILogDepot, Log, int>, ILogService
    {
        public LogService(ILogDepot baseDepot, IValidatorFactory validatorFactory, IMailService mailService, IAuthorizationManager authorizationManager)
        : base(baseDepot, validatorFactory, mailService, authorizationManager)
        {
        }

        public List<Log> GetAllLogs()
        {
            return Depot.GetAllLogs();
        }

        public void Save(string message, string module, int? actUser)
        {
            Depot.Save(message, module, actUser);
        }

        public PagedList<LogView> GetLogsPaged(LogSearchAndPagingParameters searchAndPaging)
        {
            return Depot.GetLogsPaged(searchAndPaging);
        }
        public List<string> GetAllModules()
        {
            return Depot.GetAllModules();
        }

    }
}

