﻿using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Data;
using System.Collections.Generic;

namespace Aushub.Mvc.Models.Base
{
    public class BaseMyAccountModel<TUserModel, TFirmenModel, TAdsModel, TSearchModel>
           where TSearchModel : ISearchAndPagingParameters, new()
    {
        public TUserModel MeinUser { get; set; }
        public TFirmenModel MeineFirma { get; set; }
        public PagedList<TUserModel> MeineKollegen { get; set; }
        public TUserModel MeineKollegenCurrentEntry { get; set; }
        public PagedList<TAdsModel> UnsereInserate { get; set; }
        public TAdsModel UnsereInserateCurrentEntry { get; set; }
        public TSearchModel Search { get; set; } = new TSearchModel();

        public BaseMyAccountModel()
        {

        }
    }
}