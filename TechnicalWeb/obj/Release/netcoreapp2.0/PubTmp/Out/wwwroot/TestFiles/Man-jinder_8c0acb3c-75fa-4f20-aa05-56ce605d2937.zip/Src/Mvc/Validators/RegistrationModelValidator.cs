﻿using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Aushub.Shared.Services;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Validators
{
    public class RegistrationModelValidator : AbstractValidator<RegistrationModel>
    {
        IUserService userService;

        public RegistrationModelValidator(IUserService userService)
        {
            this.userService = userService;

            RuleFor(x => x.Firstname).NotEmpty().WithMessage("Vorname darf nicht leer sein");
            RuleFor(x => x.Lastname).NotEmpty().WithMessage("Nachname darf nicht leer sein");
            RuleFor(x => x.Email).NotEmpty().WithMessage("Email darf nicht leer sein")
                                 .EmailAddress().WithMessage("Email ist keine gültige Email-Adresse")
                                 .Must(NotBeADuplicate).WithMessage("Email ist bereits vorhanden");
            RuleFor(x => x.EmailRepeat).NotEmpty().WithMessage("EMail-Wiederholung darf nicht leer sein");
            RuleFor(x => x.Email).Equal(y => y.EmailRepeat).WithMessage("EMail und EMail-Wiederholung müssen ident sein");
            RuleFor(x => x.Telefon).Must(OneOfThePhonesMustExist).WithMessage("Entweder Telefon oder Mobilnummer muss angegeben werden");
            RuleFor(x => x.MobilNumber).Must(OneOfThePhonesMustExist).WithMessage("Entweder Telefon oder Mobilnummer muss angegeben werden");
            RuleFor(x => x.UID).Must(HaveAValidVAT).WithMessage("UID muss eine gültige ID sein");
            RuleFor(x => x.Firmenname).NotEmpty().WithMessage("Firmenname darf nicht leer sein");
            RuleFor(x => x.Postleitzahl).NotEmpty().WithMessage("Postleitzahl darf nicht leer sein");
            RuleFor(x => x.Ort).NotEmpty().WithMessage("Ort darf nicht leer sein");
            RuleFor(x => x.Strasse).NotEmpty().WithMessage("Strasse darf nicht leer sein");
            RuleFor(x => x.HasAcceptedAGBs).Equal(true).WithMessage("AGB's müssen angenommen werden");
        }

        private bool NotBeADuplicate(RegistrationModel model, string newValue)
        {
            var user = userService.GetByEmail(model.Email);

            return (user == null);
        }
        private bool OneOfThePhonesMustExist(RegistrationModel model, string newValue)
        {
            return (!string.IsNullOrWhiteSpace(model.Telefon) || !string.IsNullOrWhiteSpace(model.MobilNumber));
        }

        private bool HaveAValidVAT(RegistrationModel model, string newValue)
        {
            if (string.IsNullOrWhiteSpace(model.UID))
                return true;

            PublicServices vatService = new PublicServices();
            bool isValid = false;

            try
            {
                isValid = vatService.ValidateUID(model.UID);
            }
            catch (Exception err)
            {
                System.Diagnostics.Trace.TraceError(err.ToString());
            }

            return isValid;
        }
    }
}