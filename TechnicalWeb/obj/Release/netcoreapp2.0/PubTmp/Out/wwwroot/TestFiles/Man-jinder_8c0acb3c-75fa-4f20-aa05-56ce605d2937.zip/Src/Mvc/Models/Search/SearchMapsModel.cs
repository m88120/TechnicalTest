﻿using System;
using System.Collections.Generic;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.Entities;

namespace Aushub.Mvc.Models
{
    public class SearchMapsModel
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
        public string Postleitzahl { get; set; }
        public string Ort { get; set; }
        public string Firmenname { get; set; }
    }
}