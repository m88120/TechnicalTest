﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aushub.Shared;
using Aushub.Shared.Services;
using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Comitas.CAF.Core.Logging;
using System.Data;
using System.Globalization;

namespace Aushub.Mvc.Controllers
{
    [AuthorizeRoles(Role.Sysadmin)]
    public class AllgemeineTexteController : BaseController
    {
        IAllgemeineTexteService allgemeineTexteService;
        IUserService userService;
        IMapper mapper;
        ILogService logService;

        public AllgemeineTexteController(IAllgemeineTexteService allgemeinetexteservice, IUserService userservice, ILogService logservice, IMapper mapper)
        {
            this.allgemeineTexteService = allgemeinetexteservice;
            this.userService = userservice;
            this.mapper = mapper;
            this.logService = logservice;
        }

        // GET: AllgemeineTexte
        [AuthorizeRoles(Role.Sysadmin)]
        public ActionResult Index()
        {
            AllgemeineTexte at = allgemeineTexteService.GetById(1);
            AllgemeineTexteModel model = new AllgemeineTexteModel();
            mapper.Map(at, model);
            return View(model);
        }

        [AuthorizeRoles(Role.Sysadmin)]
        [HttpPost]
        [ValidateInput(false)]
        [MultibleButton(Name = "action", Argument = "Save")]
        public ActionResult Save(AllgemeineTexteModel model)
        {
            AllgemeineTexte alte = model.Id != 0 ? allgemeineTexteService.GetById(model.Id) : null;

            if (alte == null)
            {
                ViewBag.ErrorMessage = $"<p class=\"alert alert-warning\">Keine Verbindung zum Datensatz in der Datenbank. Rufen Sie den Menüpunkt erneut auf.</p>";
                return View("Index", model);
            }

            if (ModelState.IsValid)
            {
                try
                {
                    mapper.Map(model, alte);
                    allgemeineTexteService.Save(alte);
                    mapper.Map(alte, model);
                    ViewBag.ErrorMessage = $"<p class=\"alert alert-success\">Allgemeine Texte erfolgreich gespeichert.</p>";
                    logService.Save($"Allgemeine Texte wurden verändert.", "Allgemeine Texte", UserId);
                }
                catch (Exception ex)
                {
                    Logger.Error(ex);
                    return View("Index", model);
                }
            }
            else
            {
                return View("Index", model);
            }

            return View("Index", model);
        }

        [AuthorizeRoles(Role.Sysadmin)]
        [HttpPost]
        [MultibleButton(Name = "action", Argument = "Cancel")]
        public ActionResult Cancel()
        {
            return RedirectToAction("Index", "Home");
        }

    }
}