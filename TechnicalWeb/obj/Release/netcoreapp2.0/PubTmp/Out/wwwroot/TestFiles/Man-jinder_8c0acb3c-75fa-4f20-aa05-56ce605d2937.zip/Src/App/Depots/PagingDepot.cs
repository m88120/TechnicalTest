﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Entities;
using Comitas.CAF.Core.Security;
using NPoco;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Data;

namespace Aushub.App.Depots
{
    public abstract class PagingDepot<TEntity, TSearchEntity, TKeyType> : BaseDepot<TEntity, TKeyType> where TEntity : BaseEntity<TKeyType>
    {
        protected static Dictionary<string, string> EntityToColumnMap { get; set; }

        public PagingDepot(INPocoDbContext dbContext, IAuthorizationManager authorizationManager, Dictionary<string, string> additionalEntityToColumnMap = null)
            : base(dbContext, authorizationManager)
        {
            if (EntityToColumnMap == null)
            {
                EntityToColumnMap = PocoDataFactory.
                    ForType(typeof(TSearchEntity)).
                    AllColumns.
                    ToDictionary(x => x.MemberInfoKey, x => x.ColumnName);

                if (additionalEntityToColumnMap != null)
                {
                    foreach (var item in additionalEntityToColumnMap)
                        EntityToColumnMap.Add(item.Key, item.Value);
                }
            }
        }

        protected PagedList<TSearchEntity> GetPagedAuto(SearchAndPagingParameters searchAndPaging, Sql sql, string defaultOrderBy)
        {
            string orderBy;
            string sortColumnName;

            if (!string.IsNullOrEmpty(searchAndPaging.Sort) && EntityToColumnMap.TryGetValue(searchAndPaging.Sort, out sortColumnName))
            {
                orderBy = sortColumnName + " " + searchAndPaging.SortDir;
            }
            else
            {
                orderBy = defaultOrderBy;
            }

            if (!string.IsNullOrEmpty(orderBy))
            {
                sql.OrderBy(orderBy);
            }

            return GetPaged<TSearchEntity>(searchAndPaging.Page, searchAndPaging.PageSize, sql);
        }
    }
}
