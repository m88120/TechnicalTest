﻿using Comitas.CAF.Core.Entities;
using Comitas.CAF.Core.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.Entities
{
    public class Role : BaseEntity<string>, ISecurityRole
    {
        public const string Admin = "Admin";
        public const string Sysadmin = "Sysadmin";
        public const string User = "User";

        public string Description { get; set; }

        public string Key => Id;
    }
}
