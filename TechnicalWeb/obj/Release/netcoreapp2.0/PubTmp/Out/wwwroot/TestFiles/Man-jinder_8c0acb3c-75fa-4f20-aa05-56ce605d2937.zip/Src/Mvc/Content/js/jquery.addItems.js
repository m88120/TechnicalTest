﻿(function ($) {
    'use strict';

    $.fn.addItems = function (items) {
        var output = [];

        $.each(items, function (k, item) {
            output.push('<option value="' + item.Key + '">' + item.Value + '</option>');
        });

        $(this).html(output.join(''));
    };
}(jQuery));