﻿using Aushub.Shared.Entities;
using Aushub.Shared.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.ViewModels
{
    public class InseratView : Inserat
    {
        public string Title { get; set; }
        public string Bild { get; set; }
        public string Content { get; set; }
        public string Kategorie { get; set; }
        public string Subkategorie { get; set; }
        public string Ersteller { get; set; }
        public string Firmenname { get; set; }
        public string Distanz { get; set; }
        public string Menge { get; set; }
        public string Mengeneinheit { get; set; }
        public string Preis { get; set; }
        public string Inseratstyp { get; set; }
        public string VerfuegbarAbDisplay => IstVerfuegbarAb == Verfuegbarkeit.Sofort ? "sofort" : VerfuegbarAb.HasValue ? ((DateTime)VerfuegbarAb).ToString("dd.MM.yyyy") : "sofort";
        public string VerfuegbarBisDisplay => IstVerfuegbarBis == Verfuegbarkeit.Offen ? "offen" : VerfuegbarBis.HasValue ? ((DateTime)VerfuegbarBis).ToString("dd.MM.yyyy") : "offen";

        public string DokumentVorhanden
        {
            get
            {
                if (!string.IsNullOrEmpty(Dokument))
                    return $"Vorhanden";
                else
                    return string.Empty;
            }
        }

    }
}
