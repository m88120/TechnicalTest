﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using Aushub.Shared.ViewModels;

namespace Aushub.Shared.Services
{
    public interface IFirmaService : IEntityIdService<Firma, int>
    {
        List<Firma> GetAll(bool bwithSystem);
        void Save(Firma entity);
        PagedList<FirmenView> GetFirmenPaged(FirmenSearchAndPagingParameters searchAndPaging, bool selCrit);
        string GetListOfCompaniesForHome();
        Firma GetByUID(string uid);
        bool Delete(int id);
    }
}
