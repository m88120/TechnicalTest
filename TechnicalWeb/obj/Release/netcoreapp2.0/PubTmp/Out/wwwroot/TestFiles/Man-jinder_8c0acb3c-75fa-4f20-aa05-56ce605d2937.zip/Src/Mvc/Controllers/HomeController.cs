﻿using Aushub.Mvc.Code;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aushub.Shared.Services;
using Aushub.Shared.Entities;

namespace Aushub.Mvc.Controllers
{
    public class HomeController : BaseController
    {
        IAllgemeineTexteService AllgTexte;
        IFirmaService firmenService;

        public HomeController(IAllgemeineTexteService allgemeineTexte, IFirmaService firmenservice)
        {
            this.AllgTexte = allgemeineTexte;
            this.firmenService = firmenservice;
        }

        // GET: Home
        public ActionResult Index()
        {
            AllgemeineTexte allgemeineTexte = AllgTexte.GetAll().FirstOrDefault();
            ViewBag.Was = allgemeineTexte.TextWas;
            ViewBag.Wer = allgemeineTexte.TextWer;
            ViewBag.Wie = allgemeineTexte.TextWie;
            ViewBag.Mitglieder = firmenService.GetListOfCompaniesForHome();
            return View();
        }

        public ActionResult Success()
        {
            ViewBag.Message = "<p class=\"alert alert-success\">Registrierung erfolgreich beendet.</p>";
            return View();
        }

    }
}