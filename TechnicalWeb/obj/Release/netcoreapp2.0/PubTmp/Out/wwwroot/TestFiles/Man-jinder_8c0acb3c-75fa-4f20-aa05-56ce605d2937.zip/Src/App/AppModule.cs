﻿using Autofac;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Validation;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Utilities;
using Comitas.CAF.Core.Entities;
using Comitas.CAF.Data.NPoco.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aushub.Shared;
using Aushub.App.Mappings;

namespace Aushub.App
{
    public class AppModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            // CoreModule aus CAF registrieren
            CoreModule coreModule = new CoreModule();
            coreModule.ValidatorAssembly = ThisAssembly;
            builder.RegisterModule(coreModule);

            // alle Depots registrieren und fuer Parameter 'validatorFactory' eine bestimmte Instanz uebergeben
            builder.RegisterAssemblyTypes(ThisAssembly)
                   .Where(t => TypeHelper.IsSubclassOfRawGeneric(typeof(BaseDepot<,>), t))
                   .WithParameter("validatorFactory", typeof(AutofacValidatorFactory))
                   .AsImplementedInterfaces();

            builder.RegisterAssemblyTypes(ThisAssembly)
                   .Where(t => TypeHelper.IsSubclassOfRawGeneric(typeof(CompositeBaseDepot<>), t))
                   .WithParameter("validatorFactory", typeof(AutofacValidatorFactory))
                   .AsImplementedInterfaces();

            // alle Services registrieren
            builder.RegisterAssemblyTypes(ThisAssembly)
                   .Where(t => TypeHelper.IsSubclassOfRawGeneric(typeof(NPocoBaseService<,,>), t))
                   .AsImplementedInterfaces();

            // MailService als Singleton definieren
            builder.RegisterType<MailService>()
                   .SingleInstance()
                   .AsImplementedInterfaces();

            builder.RegisterType<Config>()
                   .SingleInstance()
                   .AsSelf();

            var includeTypes = new Type[] { typeof(BaseEntity<>), typeof(BaseCompositeEntity) };
            builder.Register(x => new DatabaseProvider("Aushub", new DefaultAutoMappingScanner(System.Reflection.Assembly.Load("Aushub.Shared"), includeTypes, new AushubMappings())))
                   .SingleInstance()
                   .AsSelf();

            builder.Register(x => new AuthorizationManager())
                   .SingleInstance()
                   .As<IAuthorizationManager>();

            builder.Register(x => new AushubBootstrapper(x.Resolve<IAuthorizationManager>())).SingleInstance().AsSelf();

            builder.Register(x => x.Resolve<DatabaseProvider>().GetNewContext())
                    .As<INPocoDbContext>()
                    .InstancePerLifetimeScope()
                    .OnRelease(x =>
                    {
                        x.Dispose();
                    });
        }
    }
}
