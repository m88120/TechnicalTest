﻿using Comitas.CAF.Core.Entities;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Utilities;
using Aushub.Shared.Templating;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.Entities
{
    public class Registration : BaseEntity<int>
    {
        public int USId { get; set; }
        public string Firmenname { get; set; }
        public string UID { get; set; }
        public string Strasse { get; set; }
        public string Postleitzahl { get; set; }
        public string Ort { get; set; }

    }
}
