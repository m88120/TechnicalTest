﻿using System;
using System.Collections.Generic;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.Entities;

namespace Aushub.Mvc.Models
{
    public class GeoKoordinatenDetailModel : GeoKoordinatenModel, IDetailModel
    {
        public string Adresse { get; set; }
        public string PLZId { get; set; }
    }
}