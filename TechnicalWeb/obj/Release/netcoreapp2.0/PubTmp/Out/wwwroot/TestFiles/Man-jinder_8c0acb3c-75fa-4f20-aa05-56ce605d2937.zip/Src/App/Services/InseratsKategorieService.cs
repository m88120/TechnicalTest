using Aushub.App.Depots;
using Aushub.Shared.Entities;
using Aushub.Shared.Services;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Collections;
using FluentValidation;

namespace Aushub.App.Services
{
    public class InseratsKategorieService : NPocoBaseService<IInseratsKategorieDepot, InseratsKategorie, int>, IInseratsKategorieService
    {
        private IInseratService inseratService;
        private IInseratsSubkategorieService subkategorienService;

        public InseratsKategorieService(IInseratsKategorieDepot baseDepot, IValidatorFactory validatorFactory, IMailService mailService,
                                        IInseratService inseratservice, IAuthorizationManager authorizationManager, 
                                        IInseratsSubkategorieService subkategorienservice)
        : base(baseDepot, validatorFactory, mailService, authorizationManager)
        {
            this.inseratService = inseratservice;
            this.subkategorienService = subkategorienservice;
        }
        public List<InseratsKategorie> GetAll(bool bWithTransport)
        {
            return Depot.GetAll(bWithTransport);
        }

        public void Save(InseratsKategorie entity)
        {
            Depot.Save(entity);
        }

        public PagedList<InseratsKategorieView> GetKategorienPaged(KategorieSearchAndPagingParameters searchAndPaging)
        {
            PagedList<InseratsKategorieView> plist = Depot.GetKategorienPaged(searchAndPaging);

            foreach(InseratsKategorieView ikv in plist)
            {
                ikv.Subkategorien = subkategorienService.GetByKategorieId(ikv.Id);
            }

            return plist;
        }

        public bool Delete(int id)
        {
            bool status = false;

            if (inseratService.GetByKategorieId(id).Count() == 0)
            {
                Depot.Delete(id);
                status = true;
            }

            return status;
        }

    }
}

