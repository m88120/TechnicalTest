﻿using Comitas.CAF.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared
{
    public class Config : ConfigByReflection
    {
        public bool CatchUnhandledErrors { get; set; }
        public bool ShowUnhandledErrorDetails { get; set; }
        public int AuthenticationCookieExpireHours { get; set; }
        public int MinimumPasswordLength { get; set; }
        public string UploadDirectory { get; set; }
        public string GoogleKey { get; set; }
    }
}
