﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.Interfaces
{
    public interface IAddress
    {
        string City { get; set; }
        string Zip { get; set; }
        string CountryCode { get; set; }
    }
}
