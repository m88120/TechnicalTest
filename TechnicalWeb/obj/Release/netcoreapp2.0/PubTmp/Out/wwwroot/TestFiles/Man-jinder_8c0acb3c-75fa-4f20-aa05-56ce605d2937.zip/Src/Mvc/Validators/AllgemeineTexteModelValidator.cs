﻿using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Aushub.Shared.Services;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Validators
{
    public class AllgemeineTexteModelValidator : AbstractValidator<AllgemeineTexteModel>
    {
        public AllgemeineTexteModelValidator()
        {
            RuleFor(x => x.TextWas).NotEmpty().WithMessage("Text für 'Was' darf nicht leer sein");
            RuleFor(x => x.TextWer).NotEmpty().WithMessage("Text für 'Wer'  darf nicht leer sein");
            RuleFor(x => x.TextWie).NotEmpty().WithMessage("Text für 'Wie'  darf nicht leer sein");
            RuleFor(x => x.TextFAQ).NotEmpty().WithMessage("Text für 'FAQ'  darf nicht leer sein");
            RuleFor(x => x.TextAGBs).NotEmpty().WithMessage("Text für 'AGBs'  darf nicht leer sein");
            RuleFor(x => x.TextImpressum).NotEmpty().WithMessage("Text für 'Impressum'  darf nicht leer sein");
            RuleFor(x => x.TextKontakt).NotEmpty().WithMessage("Text für 'Kontakt'  darf nicht leer sein");
        }
    }
}