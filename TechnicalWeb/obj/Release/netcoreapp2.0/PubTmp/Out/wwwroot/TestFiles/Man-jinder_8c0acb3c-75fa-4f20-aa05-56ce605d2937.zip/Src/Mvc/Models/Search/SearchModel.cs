﻿using System;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.Enums;

namespace Aushub.Mvc.Models
{
    public class SearchModel : BaseEntityModel
    {
        public string Dokument { get; set; }
        public string Bild { get; set; }
        public string Bild1 { get; set; }
        public string Bild2 { get; set; }
        public string Bild3 { get; set; }
        public string Kategorie { get; set; }
        public string Subkategorie { get; set; }
        public string Ersteller { get; set; }
        public string Firmenname { get; set; }
        public string Distanz { get; set; }
        public string Menge { get; set; }
        public string Preis { get; set; }
        public int LI_InseratstypId { get; set; }
        public string Inseratstyp { get; set; }
        public Verfuegbarkeit IstVerfuegbarAb { get; set; }
        public DateTime? VerfuegbarAb { get; set; }
        public Verfuegbarkeit IstVerfuegbarBis { get; set; }
        public DateTime? VerfuegbarBis { get; set; }
        public string VerfuegbarAbDisplay => IstVerfuegbarAb == Verfuegbarkeit.Sofort ? "sofort" : VerfuegbarAb.HasValue ? ((DateTime)VerfuegbarAb).ToString("dd.MM.yyyy") : "sofort";
        public string VerfuegbarBisDisplay => IstVerfuegbarBis == Verfuegbarkeit.Offen ? "offen" : VerfuegbarBis.HasValue ? ((DateTime)VerfuegbarBis).ToString("dd.MM.yyyy") : "offen";

        public string DokumentVorhanden
        {
            get
            {
                if (!string.IsNullOrEmpty(Dokument))
                    return $"Vorhanden";
                else
                    return string.Empty;
            }
        }

    }
}