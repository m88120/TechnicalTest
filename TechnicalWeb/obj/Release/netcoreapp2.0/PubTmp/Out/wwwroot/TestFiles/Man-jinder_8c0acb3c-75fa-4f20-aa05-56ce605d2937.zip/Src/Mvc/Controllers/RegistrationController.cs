﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aushub.Shared;
using Aushub.Shared.Services;
using Aushub.Shared.Entities;
using Aushub.Shared.Enums;
using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Comitas.CAF.Core.Logging;
using System.Data;
using System.Globalization;
using Comitas.CAF.Core.Security;

namespace Aushub.Mvc.Controllers
{
    [AllowAnonymous]
    public class RegistrationController : BaseController
    {
        IFirmaService firmenService;
        IListItemService listitemService;
        IUserService userService;
        ILogService logService;
        IMapper mapper;
        IRegistrationService registrationsService;
        IAllgemeineTexteService allgemeineTexteService;

        public RegistrationController(IFirmaService firmenservice, IListItemService listitemservice, IUserService userservice, ILogService logservice,
                                      IMapper mapper, IRegistrationService registrationsservice, IAllgemeineTexteService allgemeinetexteservice)
        {
            this.firmenService = firmenservice;
            this.listitemService = listitemservice;
            this.userService = userservice;
            this.logService = logservice;
            this.mapper = mapper;
            this.registrationsService = registrationsservice;
            this.allgemeineTexteService = allgemeinetexteservice;
        }

        // GET: Registration
        public ActionResult Index()
        {
            RegistrationModel model = new RegistrationModel();
            InitializeModel(model);

            return View(model);
        }

        private void InitializeModel(RegistrationModel model)
        {
            //Initialize special fields
            model.UserId = 0;
            model.HasAcceptedAGBs = false;
            model.FIId = 0;
            model.AGBs = allgemeineTexteService.GetAll().FirstOrDefault().TextAGBs ?? string.Empty;

            //Initialize all comboboxes
            PrepareListFields(model);
        }

        private void PrepareListFields(RegistrationModel model)
        {
            model.SalutationListItems = listitemService.GetByListGroup(ListItem.Salutation);
        }


        [HttpPost]
        [MultibleButton(Name = "action", Argument = "Senden")]
        public ActionResult Senden(RegistrationModel model)
        {
            Registration userReg = new Registration();
            Shared.Entities.User newUser = new Shared.Entities.User();
            Firma fi;


            if (ModelState.IsValid)
            {
                try
                {

                    mapper.Map(model, newUser);
                    newUser.FIId = null;
                    if (model.FIId != null && model.FIId > 0)
                    {
                        //Die UID wurde über die GUI bereits in den Firmen gefunden und zugeordnet
                        if ((fi = firmenService.GetById((int)model.FIId)) != null)
                            newUser.FIId = fi.Id;
                    }
                    else if (!string.IsNullOrWhiteSpace(model.UID) && firmenService.GetByUID(model.UID) == null)
                    {
                        //Neue Firma anlegen, da UID auf Gültigkeit bereits in der GUI getestet wurde
                        fi = new Firma();
                        fi.AufHomeAnzeigen = false;
                        fi.Firmenname = model.Firmenname;
                        fi.IsSystem = false;
                        fi.Ort = model.Ort;
                        fi.Postleitzahl = model.Postleitzahl;
                        fi.Strasse = model.Strasse;
                        fi.UID = model.UID;
                        firmenService.Save(fi);
                        //Und Id dem User zuordnen
                        newUser.FIId = fi.Id;
                    }

                    newUser.IsSystemUser = false;
                    newUser.LI_UserstatusId = (int)ListItem.UserstatusPositionEnum.Registriert;
                    newUser.RoleKey = "User";
                    newUser.Salt = 9999999;
                    newUser.WillSammelmailErhalten = true;
                    userService.Save(newUser);

                    mapper.Map(model, userReg);
                    userReg.USId = newUser.Id;

                    logService.Save($"Benutzer {newUser.Id} - {model.Firstname} {model.Lastname}, {model.Firmenname} hat sich neu registriert.", "Registrierung", userService.GetByEmail(model.Email).Id);

                    string link = string.Format("{0}://{1}{2}", Request.Url.Scheme, Request.Url.Authority, Url.Content("~"));
                    registrationsService.SendMailToRegistrationAdmins(newUser, userReg, link);
                    registrationsService.SendMailToRegistrant(newUser, userReg, link);
                    return RedirectToAction("Success", "Home");
                }
                catch (Exception ex)
                {
                    Logger.Error(ex);
                    PrepareListFields(model);
                    ViewBag.ErrorMessage = $"<p class=\"alert alert-warning\">Es ist ein Fehler beim Versenden der Nachricht aufgetreten: {ex.Message}</p>";
                    return View("Index", model);
                }
            }
            else
            {
                PrepareListFields(model);
                return View("Index", model);
            }

        }

        [HttpPost]
        [MultibleButton(Name = "action", Argument = "Cancel")]
        public ActionResult Cancel()
        {
            return RedirectToAction("Index", "Home");
        }

        public JsonResult CheckUID(string uid)
        {
            var firma = !string.IsNullOrWhiteSpace(uid) ? firmenService.GetByUID(uid) : null;
            if (firma != null)
                return Json(firma, JsonRequestBehavior.AllowGet);
            else
                return null;
        }

    }
}