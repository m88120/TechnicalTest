using Aushub.App.Depots;
using Aushub.Shared.Entities;
using Aushub.Shared.Services;
using Aushub.Shared.SearchAndPaging;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using FluentValidation;

namespace Aushub.App.Services
{
	public class AllgemeineTexteService : NPocoBaseService<IAllgemeineTexteDepot, AllgemeineTexte, int>, IAllgemeineTexteService
	{
		public AllgemeineTexteService(IAllgemeineTexteDepot baseDepot, IValidatorFactory validatorFactory, IMailService mailService, IAuthorizationManager authorizationManager) 
		: base(baseDepot, validatorFactory, mailService, authorizationManager)
        {
        }
        public List<AllgemeineTexte> GetAll()
        {
            return Depot.GetAll();
        }

        public void Save(AllgemeineTexte entity)
        {
            Depot.Save(entity);
        }

    }
}

