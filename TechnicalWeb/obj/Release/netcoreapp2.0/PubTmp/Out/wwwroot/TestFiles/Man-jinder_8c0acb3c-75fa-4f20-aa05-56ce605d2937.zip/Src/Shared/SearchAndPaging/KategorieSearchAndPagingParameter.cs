﻿using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.SearchAndPaging
{
    public class KategorieSearchAndPagingParameters : SearchAndPagingParameters
    {
        public string Kategorie { get; set; }
        public string Subkategorie { get; set; }

        public KategorieSearchAndPagingParameters() : base()
        {
            PageSize = 5;
        }

    }
}