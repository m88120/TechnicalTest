﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Linq;
using System.Security.Policy;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.Routing;
using Aushub.Mvc.Controllers;
using Aushub.Mvc.Models;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Web.MVC.Extensions;
using System.Reflection;
using Comitas.CAF.Core.Data;
using Comitas.CAF.Utilities;
using Aushub.Shared.Entities;

namespace Aushub.Mvc.Code
{
    public static class HtmlHelperExtensions
    {

        /// <summary>
        /// Gibt die Parameterliste
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static MvcHtmlString GetDataToIncludeForGrid(this HtmlHelper htmlHelper, Type type, string prefix)
        {
            var propertyNames = type
                .GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly)
                .Select(x => $"{x.Name}: '#{prefix}{x.Name}'");

            return new MvcHtmlString(string.Join($", ", propertyNames));
        }

        public static MvcHtmlString DisplayMessage(this HtmlHelper helper, string message, object htmlAttributes = null)
        {
            if (string.IsNullOrEmpty(message))
            {
                return new MvcHtmlString("");
            }

            var div = new TagBuilder("div");
            div.MergeAttributes(new RouteValueDictionary(htmlAttributes), true);
            div.AddCssClass("message-box");
            div.InnerHtml = message;

            return new MvcHtmlString(div.ToString());
        }

        public static MvcHtmlString DisplayMessageFromTempData(this HtmlHelper helper, object htmlAttributes = null)
        {
            var page = (WebViewPage)helper.ViewDataContainer;

            return DisplayMessage(helper, page.TempData[MasterController.DefaultTempMessageKey]?.ToString(), htmlAttributes);
        }

        public static MvcHtmlString DisplayMessageFromTempData(this HtmlHelper helper, string messageKey, object htmlAttributes = null)
        {
            var page = (WebViewPage)helper.ViewDataContainer;

            return DisplayMessage(helper, page.TempData[messageKey]?.ToString(), htmlAttributes);
        }

        public static MvcHtmlString DisplaySuccessMessageFromTempData(this HtmlHelper helper, string messageKey = BaseController.DefaultTempMessageKey)
        {
            object htmlAttributes = new
            {
                @class = "message-box success-box"
            };

            return DisplayMessageFromTempData(helper, messageKey, htmlAttributes);
        }

        public static MvcHtmlString DatePickerTextBoxFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, bool readOnly = false, DateTime? defaultValue = null)
        {
            if (defaultValue != null)
            {
                var property = ExpressionExtensions.GetPropertyFromExpression(expression);
                var value = property.GetValue(htmlHelper.ViewData.Model);

                if (value is DateTime && (DateTime)value == DateTime.MinValue)
                {
                    property.SetValue(htmlHelper.ViewData.Model, defaultValue.Value);
                }
            }

            object htmlAttributes = null;

            if (!readOnly)
            {
                htmlAttributes = new { @class = "datePicker" };
            }

            return htmlHelper.TextBoxFor(expression, readOnly, "{0:d}", htmlAttributes);
        }

        public static MvcHtmlString DatePickerTextBox(this HtmlHelper htmlHelper, string name, DateTime? value, object htmlAttributes)
        {
            IDictionary<string, object> attributes = new RouteValueDictionary(htmlAttributes);

            attributes.Add("class", "datePicker");

            return htmlHelper.TextBox(name, value, "{0:d}", attributes);
        }

        public static MvcHtmlString EnumDropDownListFor<TModel, TEnum>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TEnum>> expression, string optionLabel, object htmlAttributes, bool readOnly)
        {
            IDictionary<string, object> attributes = new RouteValueDictionary(htmlAttributes);

            if (readOnly)
            {
                attributes.Add("disabled", "disabled");
            }

            return htmlHelper.EnumDropDownListFor(expression, optionLabel, attributes);
        }

    }
}