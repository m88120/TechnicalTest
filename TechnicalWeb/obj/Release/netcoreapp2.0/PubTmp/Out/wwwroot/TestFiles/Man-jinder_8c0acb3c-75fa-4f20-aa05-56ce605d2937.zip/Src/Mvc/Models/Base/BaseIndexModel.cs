﻿using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Data;
using System.Collections.Generic;

namespace Aushub.Mvc.Models.Base
{
    public class BaseIndexModel<TModel, TDetailModel, TSearchModel>// : BaseModel
        where TDetailModel : IDetailModel // BaseEntityModel, 
        where TSearchModel : ISearchAndPagingParameters, new()
    {
        public PagedList<TModel> PagedList { get; set; }
        public TDetailModel CurrentEntity { get; set; }
        public TSearchModel Search { get; set; } = new TSearchModel();
        public string MapListSerialized { get; set; }

        public BaseIndexModel()
        {

        }
    }
}