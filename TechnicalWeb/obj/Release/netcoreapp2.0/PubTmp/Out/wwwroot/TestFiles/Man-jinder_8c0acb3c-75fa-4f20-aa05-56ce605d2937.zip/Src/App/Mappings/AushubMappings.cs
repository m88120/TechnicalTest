﻿using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Comitas.CAF.Data.NPoco.Mapping;

namespace Aushub.App.Mappings
{
    public class AushubMappings : CAFMappings
    {
        public AushubMappings()
        {
            MapTables();
            MapViews();
        }

        private void MapTables()
        {
            For<AllgemeineTexte>("AT", "AllgemeineTexte");
            For<Firma>("FI", "Firmen");
            For<GeoKoordinate>("GE", "Geokoordinaten");
            For<Inserat>("IN", "Inserate");
            For<InseratsKategorie>("IK", "InseratsKategorien");
            For<InseratsSubkategorie>("IS", "InseratsSubkategorien");
            For<ListItem>("LI", "ListItems");
            For<Log>("LO", "Logs");
            For<Role>("RL", "Roles");
            For<User>("US", "Users");
        }

        private void MapViews()
        {
            For<FirmenView>("FI");
            For<GeoKoordinatenView>("GE");
            For<InseratsKategorieView>("IK");
            For<InseratView>("IN");
            For<ListItemView>("LI");
            For<LogView>("LO");
            For<RoleView>("RL");
            For<UserView>("US");
        }
    }
}
