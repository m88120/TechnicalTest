﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Models
{
    public class ResetPasswordModel
    {
        public bool Postback { get; set; }
        public string Email { get; set; }
        public string Message { get; set; }
    }
}