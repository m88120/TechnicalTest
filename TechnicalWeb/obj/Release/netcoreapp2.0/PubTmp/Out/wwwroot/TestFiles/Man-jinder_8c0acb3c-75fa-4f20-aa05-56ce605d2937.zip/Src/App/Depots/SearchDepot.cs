﻿using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Shared.Enums;
using Aushub.Shared.SearchAndPaging;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Data;
using NPoco;
using System.Text.RegularExpressions;

namespace Aushub.App.Depots
{
    public class SearchDepot : PagingDepot<Inserat, InseratView, int>, ISearchDepot
    {
        public SearchDepot(INPocoDbContext dbContext, IAuthorizationManager authorizationManager)
           : base(dbContext, authorizationManager)
        {
        }

        public PagedList<InseratView> GetSearchPaged(SearchSearchAndPagingParameters parameters)
        {
            return GetPagedAuto(parameters, CreateSQLselect(parameters), "IN_CreateDate DESC");
        }

        public List<InseratView> GetMapsSearch(SearchSearchAndPagingParameters searchAndPaging)
        {
            return Database.Fetch<InseratView>(CreateSQLselect(searchAndPaging)).ToList();
        }

        public InseratView GetViewById(int id)
        {
            Sql select = GetViewBaseSelectSql(string.Empty);
            return Database.Query<InseratView>(select).Where(x => x.Id == id).SingleOrDefault();
        }

        private Sql CreateSQLselect(SearchSearchAndPagingParameters parameters)
        {
            int iumkreis = parameters.UmkreisVon;
            int iPLZ;

            if (parameters.PlzOrt != null && parameters.PlzOrt != string.Empty)
            {
                bool b = Int32.TryParse(Regex.Match(parameters.PlzOrt, @"\d+").Value, out iPLZ);
                if (!b)
                    iPLZ = -1;
            }
            else
                iPLZ = -1;

            Sql select = GetViewBaseSelectSql(iPLZ.ToString());

            if (parameters.IKId > 0 && parameters.LI_InseratstypId != (int)Inseratstyp.BieteTransport && parameters.LI_InseratstypId != (int)Inseratstyp.BenoetigeTransport)
            {
                select = select.Where("IN_IK_Id = @IKId", new { IKId = parameters.IKId });
            }

            if (parameters.ISId > 0 && parameters.LI_InseratstypId != (int)Inseratstyp.BieteTransport && parameters.LI_InseratstypId != (int)Inseratstyp.BenoetigeTransport)
            {
                select = select.Where("IN_IS_Id = @ISId", new { ISId = parameters.ISId });
            }

            if (!string.IsNullOrEmpty(parameters.PlzOrt) && iumkreis == 0)
            {
                select = select.Where("(RTRIM(LTRIM(ISNULL(IN_Postleitzahl, '') + ' ' + ISNULL(IN_Ort, '')))) LIKE @PlzOrt", new { PlzOrt = $"%{parameters.PlzOrt}%" });
            }

            if (iumkreis != 0)
            {
                select = select.Where("IN_Postleitzahl IN (select GE_Postleitzahl FROM GetZipsAroundZip(@PLZ, @Umkreis))", new { PLZ = iPLZ.ToString(), Umkreis = iumkreis });
            }

            if (parameters.LI_InseratstypId > 0)
            {
                select = select.Where("IN_LI_Inseratstyp_Id = @InseratstypId", new { InseratstypId = parameters.LI_InseratstypId });
            }

            if (parameters.FIId > 0)
            {
                select = select.Where("IN_FI_Id = @FIId", new { FIId = parameters.FIId });
            }

            if (parameters.VerfuegbarVon.HasValue)
            {
                select = select.Where("(IN_IstVerfuegbarAb = @Sofort) OR (IN_IstVerfuegbarAb = @VerfuegbarAb AND IN_VerfuegbarAb <= @VerfuegbarAbDatum)", new { Sofort = Verfuegbarkeit.Sofort, VerfuegbarAb = Verfuegbarkeit.AbDatum, VerfuegbarAbDatum = parameters.VerfuegbarVon });
            }

            if (parameters.VerfuegbarBis.HasValue)
            {
                select = select.Where("(IN_IstVerfuegbarBis = @Offen) OR (IN_IstVerfuegbarBis = @VerfuegbarBis AND IN_VerfuegbarBis >= @VerfuegbarBisDatum)", new { Offen = Verfuegbarkeit.Offen, VerfuegbarBis = Verfuegbarkeit.BisDatum, VerfuegbarBisDatum = parameters.VerfuegbarBis });
            }

            if (parameters.PreisVon.HasValue)
            {
                select = select.Where("IN_Zahlungsbedingung = @IchZahleVon AND ISNULL(IN_IchZahleDemAbnehmerDenPreis, 0) >= @PreisVon", new { IchZahleVon = Zahlungsart.IchZahleDemAbnehmer, PreisVonVerfuegbarAbDatum = parameters.PreisVon });
            }

            if (parameters.PreisBis.HasValue)
            {
                select = select.Where("IN_Zahlungsbedingung = @IchZahleBis AND ISNULL(IN_IchZahleDemAbnehmerDenPreis, 0) <= @PreisBis", new { IchZahleBis = Zahlungsart.IchZahleDemAbnehmer, PreisVonVerfuegbarAbDatum = parameters.PreisBis });
            }

            //ToDo: Menge von/bis


            // ----------------------


            List<string> selectList = new List<string>();
            if (parameters.Sort == "Kategorie")
            {
                selectList.Add("IN_Kategorie");
                selectList.Add("IN_Subkategorie");
            }
            else if (!string.IsNullOrEmpty(parameters.Sort))
            {
                selectList.Add($"IN_{parameters.Sort}");
            }
            else
            {
                selectList.Add("IN_CreateDate");
                parameters.SortDir = SortDirection.Desc;
            }

            select = select.OrderBy($"{string.Join(" " + parameters.SortDir.ToString() + ",", selectList)} {parameters.SortDir.ToString()}");

            return select;
        }

        private Sql GetViewBaseSelectSql(string plz)
        {
            string s = string.Empty;
            Sql select;

            s = "'<p><strong>' + IK.IK_Kategorie + ' - ' + ISU.IS_Subkategorie + '</strong></p>";
            s += "<p><strong>Typ:</strong>&nbsp;' + LI1.LI_Bezeichnung + '</p>";
            s += "<p><strong>Ort:</strong>&nbsp;' + RTRIM(LTRIM(ISNULL(INS.IN_Postleitzahl, '') + ' ' + ISNULL(INS.IN_Ort, ''))) + '</p>";
            s += "<p><strong>Kontakt:</strong>&nbsp;' + LTRIM(RTRIM(ISNULL(USK.US_Firstname, '') + ' ' + ISNULL(USK.US_Lastname, ''))) + '</p>";
            s += "<p><strong>Tel/Mobile:</strong>&nbsp;' + CASE WHEN ISNULL(IN_MobilnummerAnzeigen, 0) <> 0 THEN ISNULL(USK.US_MobilNumber, '') ELSE ISNULL(USK.US_Telefon, '') END + '</p>' AS IN_Content";

            string[] columns = new string[]
            {
                "INS.*",
                "IK.IK_Kategorie AS IN_Kategorie",
                "ISU.IS_Subkategorie AS IN_Subkategorie",
                "ISNULL(IK.IK_Kategorie, '') + ' / ' + ISNULL(ISU.IS_Subkategorie, '') AS IN_Title",
                "10 AS IN_ZIndex",
                s,
                "CASE WHEN INS.IN_Bild1 IS NOT NULL THEN INS.IN_Bild1 ELSE ISU.IS_Standardbild END AS IN_Bild",
                "RTRIM(LTRIM(ISNULL(US.US_Firstname, '') + ' ' + ISNULL(US.US_Lastname, ''))) AS IN_Ersteller",
                "RTRIM(LTRIM(ISNULL(INS.IN_Postleitzahl, '') + ' ' + ISNULL(INS.IN_Ort, ''))) AS IN_PlzOrt",
                "FI.FI_Firmenname AS IN_Firmenname",
                "LI1.LI_Bezeichnung AS IN_Inseratstyp",
                "CASE WHEN INS.IN_Zahlungsbedingung = 1 THEN 'Verhandelbar' ELSE CASE WHEN INS.IN_Zahlungsbedingung = 4 THEN 'Kostenlos' ELSE LTRIM(RTRIM(CAST((ISNULL(INS.IN_IchZahleDemAbnehmerDenPreis, 0) - ISNULL(INS.IN_DerAbnehmerZahltDenPreis, 0)) AS varchar(20)))) END END AS IN_Preis",
                "INS.IN_VerfuegbareMenge AS IN_Menge"
            };

            if (plz != null && plz != string.Empty && plz != "-1")
            {
                Array.Resize(ref columns, columns.Length + 1);
                columns[columns.Length - 1] = $"LTRIM(RTRIM(CAST(ROUND(dbo.GetDistanceBetweenZips('{plz}', INS.IN_Postleitzahl), 1) As varchar(10)))) + ' km' AS IN_Distanz";
            }

            select = Sql.Builder.Select(columns).From("Inserate AS INS")
                                                .LeftJoin("InseratsKategorien AS IK").On("INS.IN_IK_Id = IK.IK_ID")
                                                .LeftJoin("InseratsSubkategorien AS ISU").On("INS.IN_IK_Id = ISU.IS_IK_ID And INS.IN_IS_Id = ISU.IS_ID")
                                                .LeftJoin("Users AS US").On("INS.IN_CreateUser_Id = US.US_Id")
                                                .LeftJoin("Users AS USK").On("INS.IN_US_Kontakt_Id = USK.US_Id")
                                                .LeftJoin("Firmen AS FI").On("INS.IN_FI_Id = FI.FI_Id")
                                                .LeftJoin("ListItems AS LI1").On("INS.IN_LI_Inseratstyp_Id = LI1.LI_Id");

            return select;
        }

    }
}
