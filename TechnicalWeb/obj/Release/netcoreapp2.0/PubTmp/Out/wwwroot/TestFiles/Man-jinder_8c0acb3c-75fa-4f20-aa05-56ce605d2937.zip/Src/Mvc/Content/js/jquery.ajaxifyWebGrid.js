﻿/**
 * Mit dieser jQuery-Extension wird ein WebGrid zu einem tollen dynamischen Grid gemacht.
 * Das Grid funktioniert so, dass beim Initialisieren alle Hyperlinks im Pager und im Header
 * durch Javascript-Methoden ersetzt werden. Anstelle eines synchronen Aufrufes wird dann
 * per Javascript eine angegebene URL aufgerufen und das gesamte Grid mit dem Resultat ersetzt.
 *
 * Die Initialisierung funktioniert wie folgt:
 * $('<GridSelector>').ajaxifyWebGrid('init', {  // sollte genau 1 div sein (der 'Init' Parameter ist optional, aber empfohlen)
 *      baseUrl: '/Controller/Action',           // die URL zur Action, welche eine PartialView mit dem Grid zurueck gibt
 *      dataToInclude: {                         // das sind jQuery-Selektoren zu Felden welche dem Request mitgegeben werden
 *          Suchfeld1: '#Suchfeld1',
 *          Suchfeld2: '#Suchfeld2',
 *      },
 *      callback: function () { ... }            // eine Methode, welche nach dem Neuladen des Grid aufgerufen wird
 * });
 *
 * Alle Parameter bis auf 'baseUrl' sind optional.
 *
 * Wenn ein Grid neu geladen werden soll, kann dies wie folgt gemacht werden:
 * $('<GridSelector>').ajaxifyWebGrid('execute');
 */

var settingsPerGrid = [];

(function ($) {
    $.fn.ajaxifyWebGrid = function (action, arg1) {

        // Default-Settings
        var defaults = {
            baseUrl: '',
            dataToInclude: null,
            callback: null
        };

        // Auswahl der Funktion
        var tempGridElement = this;

        if (tempGridElement.length === 0) {
            return this;
        }
        else if (action === 'querystring')
        {
            return getQueryString(tempGridElement);
        }
        else {
            return this.each(function () {
                if (typeof (action) === 'object') {
                    init(tempGridElement, action);

                } else if (action === 'init') {
                    init(tempGridElement, arg1);

                } else if (action === 'execute') {
                    executeDirect(tempGridElement, arg1);
                }
                else {
                    alert('action ist nicht definiert: ' + action);
                }
            });
        }

        //
        // Private Functions
        //

        /**
         * Initialisiert das Grid.
         * @param {jqueryElement} gridElement - Das Element das zum Grid gemacht wird.
         * @param {object} options - Die Optionen.
         */
        function init(gridElement, options) {
            // Settings aus Default-Optionen und Options-Parameter zusammenbasteln
            var settings = $.extend({}, defaults, options);

            // Settings speichern pro Grid
            var newSettingsPerGrid = [];

            for (var i = 0; i < settingsPerGrid.length; i++) {
                if (settingsPerGrid[i].Element[0] !== gridElement[0]) {
                    newSettingsPerGrid[newSettingsPerGrid.length] = { Element: settingsPerGrid[i].Element, Settings: settingsPerGrid[i].Settings, State: settingsPerGrid[i].State };
                }
            }

            newSettingsPerGrid[newSettingsPerGrid.length] = { Element: gridElement, Settings: settings, State: { Page: 1, Sort: null, SortDir: null } };

            settingsPerGrid = newSettingsPerGrid;

            // Page-Links konfigurieren, damit das Paging funktioniert
            var selector = (settings.gridSelector === undefined || settings.gridSelector === null ? '' : ' ' + settings.gridSelector);
            var allLinksSelector = 'th[scope=col] a, .grid-pager li a';
            var allLinks = gridElement.find(allLinksSelector);
            var firstSearchExecuter = allLinks.first().attr('href');

            if (settings.baseUrl === '' && firstSearchExecuter.indexOf('?') > -1) {
                settings.baseUrl = firstSearchExecuter.substring(0, firstSearchExecuter.indexOf('?'));
            } else {
                allLinks.each(function () {
                    var link = $(this);
                    var href = link.attr('href');

                    href = settings.baseUrl + href.substring(href.indexOf('?'));
                    link.attr('href', href);

                    link.on('click', function (e) {
                        linkClick(gridElement, settings, link, e);
                    });
                });
            }
        }

        /**
         * Diese Funktion wird beim Klick auf einen Link im Header oder im Pager ausgefuehrt.
         * @param {jqueryElement} gridElement - Das Element das zum Grid gemacht wird.
         * @param {object} settings - Die gesamten Settings zum Grid.
         * @param {jqueryElement} link - Der Link als jqueryElement, welcher geklickt wurde.
         * @param {object} eventArgs - Die Event Argumente
         */
        function linkClick(gridElement, settings, link, eventArgs) {
            eventArgs.preventDefault();

            // Parameter aus Link holen
            var queryParameters = getQueryParameters(link.attr('href'));

            // Grid laden
            execute(gridElement, settings, queryParameters.page, queryParameters.sort, queryParameters.sortdir);
        }

        /**
         * Holt die Query-Parameter aus dem Grid und holt diese aus der URL.
         * @param {string} link - Eine beliebige URL.
         * @return {object} Gibt ein Object mit den Parametern zurueck.
         */
        function getQueryParameters(link) {
            var questionMarkIndex = link.indexOf('?');

            if (questionMarkIndex > -1) {
                link = link.substring(questionMarkIndex);
            }

            return $.getQueryParameters(link);
        }

        /**
         * Gibt den Wert eines Elements in anbetrachten des Typs zurück
         * @param {element} element - Betroffenes Element, dessen Wert geholt werden soll
         */
        function getElementValue(element) {
            if ($(element).is('input[type="checkbox"]')) {
                return $(element).prop('checked'); // Notwendig wegen MVC-Checkbox-State
            }

            return $(element).val();
        }

        /**
         * Fuehrt einen Request aus um das Grid zu aktualisieren.
         * @param {jqueryElement} gridElement - Das Element das zum Grid gemacht wird.
         * @param {object} settings - Die gesamten Settings zum Grid.
         * @param {number} page - Die Page, welche gelesen werden soll (falls nicht vorhanden wird 1 verwendet).
         * @param {string} sort - Die Spalte, nach der sortiert werden soll.
         * @param {string} sortDir - Die Richtung der Sortierung (falls nicht vorhanden wird 'ASC' verwendet).
         * @param {string[]} abc - Die Argumente, welche dem Request mitgegeben werden sollen
         */
        function execute(gridElement, settings, page, sort, sortDir, abc) {
            var args = buildQueryString(settings, page, sort, sortDir, abc);

            // Status aktualisieren
            for (i = 0; i < settingsPerGrid.length; i++) {
                if (settingsPerGrid[i].Element[0] === gridElement[0]) {
                    var state = settingsPerGrid[i].State;

                    state.Page = (page || 1);
                    state.Sort = (sort || '');
                    state.SortDir = (sortDir || 'ASC');
                }
            }

            // Grid laden
            gridElement.load(settings.baseUrl, args, function () { executeCallback(gridElement, settings); });
        }

        /**
         * Baut die Suchparameter zu einem QueryString zusammen.
         * @param {object} settings - Die gesamten Settings zum Grid.
         * @param {number} page - Die Page, welche gelesen werden soll (falls nicht vorhanden wird 1 verwendet).
         * @param {string} sort - Die Spalte, nach der sortiert werden soll.
         * @param {string} sortDir - Die Richtung der Sortierung (falls nicht vorhanden wird 'ASC' verwendet).
         * @param {string[]} abc - Die Argumente, welche dem Request mitgegeben werden sollen
         */
        function buildQueryString(settings, page, sort, sortDir, abc) {
            var finalArgs = [];

            // Argumente sammeln
            if (typeof (formAction) !== 'undefined' && abc !== null) {

                // Argumente von Parameter uebernehmen
                finalArgs = abc;

            } else if (settings.dataToInclude !== null) {

                // Daten aus Suchmaske sammeln
                for (var key in settings.dataToInclude) {
                    var selector = settings.dataToInclude[key];
                    var element = $(selector);

                    if (element !== null) {
                        finalArgs[finalArgs.length] = { Name: key, Value: getElementValue(element) };
                    }
                }
            }

            // Parameter basteln
            var i;
            var args = 'page=' + (page || '1') +
                '&sort=' + (sort || '') +
                '&sortdir=' + (sortDir || 'ASC');

            for (i = 0; i < finalArgs.length; i++) {
                args += '&' + finalArgs[i].Name + '=' + finalArgs[i].Value;
            }

            args += '&ts=' + (new Date().getTime());

            return args;
        }

        /**
         * Wird nach dem Aktualisieren des Grids aufgerufen und initialisiert das Grid neu.
         * @param {jqueryElement} gridElement - Das Element das zum Grid gemacht wird.
         * @param {object} settings - Die gesamten Settings zum Grid.
         */
        function executeCallback(gridElement, settings) {
            gridElement.ajaxifyWebGrid('init', settings);

            if (settings.callback !== null) {
                settings.callback();
            }
        }

        /**
         * Fuehrt einen Request aus um das Grid neu zu laden. Diese Funktion wird aufgerufen, wenn die 'execute' Funktionalitaet aufgerufen wird.
         * @param {jqueryElement} gridElement - Das Element das zum Grid gemacht wird.
         * @param {number} page - Die Page, welche gelesen werden soll (falls nicht vorhanden wird 1 verwendet).
         */
        function executeDirect(gridElement, page) {
            var gridSettings = getSettingsPerGrid(gridElement);

            if (gridSettings !== null) {
                execute(gridElement, gridSettings.Settings, gridSettings.State.Page, gridSettings.State.Sort, gridSettings.State.SortDir);
            }
        }

        /**
         * Fuehrt einen Request aus um das Grid neu zu laden. Diese Funktion wird aufgerufen, wenn die 'execute' Funktionalitaet aufgerufen wird.
         * @param {jqueryElement} gridElement - Das Element das zum Grid gemacht wird.
         * @param {number} page - Die Page, welche gelesen werden soll (falls nicht vorhanden wird 1 verwendet).
         */
        function getQueryString(gridElement) {
            var gridSettings = getSettingsPerGrid(gridElement);

            if (gridSettings !== null) {
                return buildQueryString(gridSettings.Settings, gridSettings.State.Page, gridSettings.State.Sort, gridSettings.State.SortDir);
            }
        }

        /**
         * Gibt ein Tupel mit Settings und State des aktuellen Grids zurück.
         * @param {jqueryElement} gridElement - Das Element das zum Grid gemacht wird.
         * @param {number} page - Die Page, welche gelesen werden soll (falls nicht vorhanden wird 1 verwendet).
         */
        function getSettingsPerGrid(gridElement) {
            var settings = null;
            var state = null;

            for (var i = 0; i < settingsPerGrid.length; i++) {
                if (settingsPerGrid[i].Element[0] === gridElement[0]) {
                    settings = settingsPerGrid[i].Settings;
                    state = settingsPerGrid[i].State;
                }
            }

            if (settings === null) {
                alert('Keine Settings gefunden.');
            }
            else if (state === null) {
                alert('Keinen State gefunden.');
            }
            else {
                return {
                    Settings: settings,
                    State: state
                };
            }
            
            return null;
        }
    };
}(jQuery));
