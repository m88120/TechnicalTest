﻿using Comitas.CAF.Core.Entities;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Utilities;
using Aushub.Shared.Templating;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.Entities
{
    [AutoGen]
    public class InseratsKategorie : BaseEntity<int>
    {
        public string Kategorie { get; set; }
    }
}
