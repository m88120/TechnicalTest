﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using Aushub.Shared.ViewModels;

namespace Aushub.Shared.Services
{
    public interface ILogService : IEntityIdService<Log, int>
    {
        List<Log> GetAllLogs();
        void Save(string message, string module, int? actUser);
        PagedList<LogView> GetLogsPaged(LogSearchAndPagingParameters searchAndPaging);
        List<string> GetAllModules();
    }
}
