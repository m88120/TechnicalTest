using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Security;
using NPoco;

namespace Aushub.App.Depots
{
	public class AllgemeineTexteDepot : BaseDepot<AllgemeineTexte, int>, IAllgemeineTexteDepot
	{
		public AllgemeineTexteDepot(INPocoDbContext dbContext, IAuthorizationManager authorizationManager) 
            : base(dbContext, authorizationManager)
        {
        }

        public List<AllgemeineTexte> GetAll()
        {
            Sql select = GetBaseSelectSql();
            return Database.Query<AllgemeineTexte>(select).ToList();
        }

    }
}

