using Aushub.App.Depots;
using Aushub.Shared.Entities;
using Aushub.Shared.Services;
using Aushub.Shared.SearchAndPaging;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using FluentValidation;

namespace Aushub.App.Services
{
    public class InseratsSubkategorieService : NPocoBaseService<IInseratsSubkategorieDepot, InseratsSubkategorie, int>, IInseratsSubkategorieService
    {
        private IInseratService inseratService;

        public InseratsSubkategorieService(IInseratsSubkategorieDepot baseDepot, IValidatorFactory validatorFactory, IMailService mailService,
                                           IInseratService inseratservice, IAuthorizationManager authorizationManager)
        : base(baseDepot, validatorFactory, mailService, authorizationManager)
        {
            this.inseratService = inseratservice;
        }
        public List<InseratsSubkategorie> GetAll()
        {
            return Depot.GetAll();
        }

        public List<InseratsSubkategorie> GetByKategorieId(int kategorieId)
        {
            return Depot.GetByKategorieId(kategorieId);
        }

        public void Save(InseratsSubkategorie entity)
        {
            Depot.Save(entity);
        }

        public bool Delete(int id)
        {
            bool status = false;

            if (inseratService.GetBySubkategorieId(id).Count() == 0)
            {
                Depot.Delete(id);
                status = true;
            }

            return status;
        }

    }
}

