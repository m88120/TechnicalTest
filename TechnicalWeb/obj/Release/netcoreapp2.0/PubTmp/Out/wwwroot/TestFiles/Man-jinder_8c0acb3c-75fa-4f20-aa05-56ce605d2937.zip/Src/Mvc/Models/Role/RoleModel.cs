﻿using Aushub.Mvc.Models.Base;

namespace Aushub.Mvc.Models
{
    public class RoleModel
    {
        public string Id { get; set; }
        public string Description { get; set; }

        public bool IsTransient
        {
            get
            {
                return Id == null;
            }
        }
    }
}