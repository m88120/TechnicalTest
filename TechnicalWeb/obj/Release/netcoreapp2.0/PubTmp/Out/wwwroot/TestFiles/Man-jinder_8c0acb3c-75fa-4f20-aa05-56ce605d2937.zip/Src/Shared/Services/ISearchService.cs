﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using Aushub.Shared.ViewModels;

namespace Aushub.Shared.Services
{
    public interface ISearchService : IEntityIdService<Inserat, int>
    {
        PagedList<InseratView> GetSearchPaged(SearchSearchAndPagingParameters searchAndPaging);
        List<InseratView> GetMapsSearch(SearchSearchAndPagingParameters searchAndPaging);
        InseratView GetViewById(int id);
    }
}
