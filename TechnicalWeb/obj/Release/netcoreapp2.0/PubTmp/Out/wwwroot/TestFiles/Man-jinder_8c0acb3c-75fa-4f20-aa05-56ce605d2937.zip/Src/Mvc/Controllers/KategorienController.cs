﻿using Comitas.CAF.Core.Collections;
using AutoMapper;
using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aushub.Shared;
using Aushub.Shared.Services;
using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.SearchAndPaging;
using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Comitas.CAF.Core.Logging;
using System.Data;
using System.Globalization;
using System.ComponentModel.DataAnnotations;

namespace Aushub.Mvc.Controllers
{
    [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
    public class KategorienController : BaseController
    {
        IInseratsKategorieService kategorieService;
        IInseratsSubkategorieService subkategorieService;
        IUserService userService;
        ILogService logService;
        IMapper mapper;
        Config config;

        public KategorienController(IInseratsKategorieService kategorieservice, IInseratsSubkategorieService subkategorieservice, 
                                    IUserService userservice, ILogService logservice, IMapper mapper, Config config)
        {
            this.kategorieService = kategorieservice;
            this.subkategorieService = subkategorieservice;
            this.userService = userservice;
            this.logService = logservice;
            this.mapper = mapper;
            this.config = config;
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public virtual ActionResult Index(int? id, [Bind(Prefix = "s")] KategorieSearchAndPagingParameters parameters)
        {
            return View("Index", GetIndexViewModel(id, null, parameters));
        }

        protected BaseIndexModel<KategorieModel, KategorieDetailModel, KategorieSearchAndPagingParameters> GetIndexViewModel(int? id, KategorieDetailModel entityModel, KategorieSearchAndPagingParameters parameters)
        {

            if (parameters == null)
                parameters = new KategorieSearchAndPagingParameters();

            KategorieDetailModel detailModel = GetDetailModel(id);

            // Query String mit GridView Parametern eigentlich nicht mehr notwendig!
            return new BaseIndexModel<KategorieModel, KategorieDetailModel, KategorieSearchAndPagingParameters>()
            {
                PagedList = GetPagedEntites(parameters),
                Search = parameters,
                CurrentEntity = detailModel
            };
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult Load(int id)
        {
            ModelState.Clear(); // Damit ggf. neue Id übernommen wird

            KategorieDetailModel model = GetDetailModel(id);

            return PartialView("KategorieDetailPartial", model);
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult LoadSubkategorie(int? id, int katid)
        {
            ModelState.Clear(); // Damit ggf. neue Id übernommen wird
            ViewBag.StandardbildNameNeu = "";

            SubkategorieDetailModel model = GetSubkategorieDetailModel(id);
            if (!id.HasValue || id == 0)
                model.IKId = katid;

            return PartialView("SubkategorieDetailPartial", model);
        }

        private KategorieDetailModel GetDetailModel(int? id)
        {
            if (!id.HasValue)
                return null;

            InseratsKategorie view = kategorieService.GetById(id.Value);

            var model = view == null ? new KategorieDetailModel() : mapper.Map<KategorieDetailModel>(view);
            mapper.Map(subkategorieService.GetByKategorieId(model.Id), model.Subkategorien);

            return model;
        }

        private SubkategorieDetailModel GetSubkategorieDetailModel(int? id)
        {
            if (!id.HasValue)
                return null;

            InseratsSubkategorie view = subkategorieService.GetById(id.Value);

            var model = view == null ? new SubkategorieDetailModel() : mapper.Map<SubkategorieDetailModel>(view);
            return model;
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public ActionResult GetGrid(KategorieSearchAndPagingParameters searchAndPaging)
        {
            return PartialView("Grid", GetPagedEntites(searchAndPaging));
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public ActionResult GetSubkategorienGrid(int Id)
        {
            return PartialView("GridSubkategorien", GetSubkategorienEntites(Id));
        }

        private PagedList<KategorieModel> GetPagedEntites(KategorieSearchAndPagingParameters searchAndPaging)
        {
            var pagedEntities = kategorieService.GetKategorienPaged(searchAndPaging);

            return new PagedList<KategorieModel>(mapper.Map<IEnumerable<InseratsKategorieView>, IEnumerable<KategorieModel>>(pagedEntities),
                                                         pagedEntities.PageIndex,
                                                         pagedEntities.PageSize,
                                                         pagedEntities.TotalCount);
        }

        private List<SubkategorieModel> GetSubkategorienEntites(int Id)
        {
            var listEntities = subkategorieService.GetByKategorieId(Id);

            return new List<SubkategorieModel>(mapper.Map<IEnumerable<InseratsSubkategorie>, IEnumerable<SubkategorieModel>>(listEntities));
        }

        [HttpPost]
        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult Save(KategorieDetailModel model)
        {

            var saveResult = TrySave(model);

            if (saveResult.Status)
            {
                SetSuccessMessage("Ihre Daten wurden erfolgreich gespeichert.");
                logService.Save($"Kategorie {model.Kategorie} wurde gespeichert", "Kategorieverwaltung", UserId);
                return Load(saveResult.Id);
            }

            return PartialView("KategorieDetailPartial", model);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult SaveNew(KategorieDetailModel model)
        {
            return SaveNew<KategorieDetailModel>(Save(model));
        }

        private (bool Status, int Id) TrySave(KategorieDetailModel model)
        {
            if (!ModelState.IsValid)
            {
                return (false, 0);
            }

            InseratsKategorie kategorie = new InseratsKategorie();

            if (model.Id > 0)
                kategorie = kategorieService.GetById(model.Id);

            mapper.Map(model, kategorie);

            return (ExecuteActionWithValidationErrorHandling(() => kategorieService.Save(kategorie)), kategorie.Id);
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public JsonResult Delete(int id)
        {
            bool status = false;
            string kg = kategorieService.GetById(id).Kategorie;

            try
            {
                if (kategorieService.Delete(id))
                {
                    status = true;
                    logService.Save($"Kategorie {kg} wurde gelöscht", "Kategorieverwaltung", UserId);
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }

            var result = new
            {
                Status = status
            };

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult SaveSubkategorie(SubkategorieDetailModel model)
        {
            string uploadfilepath = config.UploadDirectory;

            if (string.IsNullOrWhiteSpace(model.Standardbild))
                model.Standardbild = model.StandardbildNeu;
            else if (!string.IsNullOrWhiteSpace(model.StandardbildNeu))
            {
                if (System.IO.File.Exists(Server.MapPath($"{uploadfilepath}Images/{model.Standardbild}")))
                    System.IO.File.Delete(Server.MapPath($"{uploadfilepath}Images/{model.Standardbild}"));

                model.Standardbild = model.StandardbildNeu;
                model.StandardbildNeu = string.Empty;
            }

            var saveResult = TrySaveSubkategorie(model);

            if (saveResult.Status)
            {
                SetSuccessMessage("Ihre Daten wurden erfolgreich gespeichert");
                logService.Save($"Subkategorie {model.Subkategorie} wurde gespeichert", "Kategorieverwaltung", UserId);
                return LoadSubkategorie(saveResult.Id, model.IKId);
            }

            return PartialView("SubkategorieDetailPartial", model);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult SaveNewSubkategorie(SubkategorieDetailModel model)
        {
            PartialViewResult pvr = SaveSubkategorie(model);
            int ikid = model.IKId;
            model = new SubkategorieDetailModel();
            model.IKId = ikid;
            return PartialView("SubkategorieDetailPartial", model);
        }

        private (bool Status, int Id) TrySaveSubkategorie(SubkategorieDetailModel model)
        {
            if (!ModelState.IsValid)
            {
                return (false, 0);
            }

            InseratsSubkategorie subkategorie = new InseratsSubkategorie();

            if (model.Id > 0)
                subkategorie = subkategorieService.GetById(model.Id);

            mapper.Map(model, subkategorie);

            return (ExecuteActionWithValidationErrorHandling(() => subkategorieService.Save(subkategorie)), subkategorie.Id);
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public JsonResult DeleteSubkategorie(int id)
        {
            bool status = false;
            string skg = subkategorieService.GetById(id).Subkategorie;

            try
            {
                if (subkategorieService.Delete(id))
                {
                    status = true;
                    logService.Save($"Subkategorie {skg} wurde gelöscht", "Kategorieverwaltung", UserId);
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }

            var result = new
            {
                Status = status
            };

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult UploadSubkategorieImage(HttpPostedFileBase file)
        {
            bool status = false;

            List<string> errors = new List<string>();
            string filename = string.Empty;
            string uploadfilepath = config.UploadDirectory;

            try
            {
                if (file != null && file.ContentLength != 0)
                {
                    filename = $"{UserName}_{DateTime.Now.Ticks.ToString("x").ToUpper()}{Path.GetExtension(file.FileName)}";
                    file.SaveAs(Server.MapPath($"{uploadfilepath}Images/{filename}"));
                    status = true;
                }
            }
            catch (ValidationException ex)
            {
                errors.Add(ex.Message);
            }
            catch (Exception ex)
            {
                errors.Add("Unbekannter Fehler.");
                Logger.Error(ex);
            }

            return Json(new
            {
                Status = status,
                FileNameNeu = filename,
                Message = errors.Count > 0 ? string.Join("\n", errors) : ""
            });
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public JsonResult DeleteSubkategorieFile(string filename)
        {
            bool status = false;
            string uploadfilepath = config.UploadDirectory;

            try
            {
                if (System.IO.File.Exists(Server.MapPath($"{uploadfilepath}Images/{filename}")))
                {
                    System.IO.File.Delete(Server.MapPath($"{uploadfilepath}Images/{filename}"));
                    status = true;
                }
            }
            catch (Exception)
            {
            }
 
            var result = new
            {
                Status = status
            };

            return Json(result, JsonRequestBehavior.AllowGet);
        }

    }
}