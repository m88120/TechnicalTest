﻿using Comitas.CAF.Core.Entities;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Utilities;
using Aushub.Shared.Templating;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.Entities
{
    [AutoGen]
    public class AllgemeineTexte : BaseEntity<int>
    {
        public string TextWas { get; set; }
        public string TextWer { get; set; }
        public string TextWie { get; set; }
        public string TextFAQ { get; set; }
        public string TextImpressum { get; set; }
        public string TextAGBs { get; set; }
        public string TextKontakt { get; set; }
    }
}
