﻿using Comitas.CAF.Data.NPoco.Mapping;
using Aushub.Shared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared
{
    public class DbMaps : CAFMappings
    {
        public DbMaps()
        {
            MapTables();
            MapViews();
        }

        private void MapViews()
        {
            
        }

        private void MapTables()
        {
            For<Role>("RL", "[dbo].[Roles]");
            For<User>("US", "[dbo].[Users]").Columns(c =>
            {
                c.Column(x => x.Identifier).Ignore();
                c.Column(x => x.DisplayName).Ignore();
                c.Column(x => x.UniqueId).Ignore();
            });
            For<AllgemeineTexte>("AT", "[dbo].[AllgemeineTexte]");
            For<Firma>("FI", "[dbo].[Firmen]");
            For<Inserat>("IN", "[dbo].[Inserate]");
            For<InseratsKategorie>("IK", "[dbo].[InseratsKategorien]");
            For<InseratsSubkategorie>("IS", "[dbo].[InseratsSubkategorien]");
            For<ListItem>("LI", "[dbo].[ListItems]");
        }
    }
}
