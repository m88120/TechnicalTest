﻿(function ($) {

    $.fn.ajaxAutoComplete = function(options) {

        var settings = {};
        var idField = $(this).attr('data-id-field');

        if (typeof options === 'string') {
            var ajaxPath = options;
            options = {};
            options.ajaxPath = ajaxPath;
        }

        settings = $.extend({
            minChars: 0, // TODO: Fuer Testzwecke hier 0 anstatt 2 eingetragen. So koennen schneller Daten erfasst werden.
            dataCollector: null,
            dataToSend: {}
        }, options);

        settings.source = function (term, response) {

            var dataToSend = settings.dataToSend;

            if (settings.dataCollector !== null) {
                dataToSend = $.extend(settings.dataCollector.call(this), settings.dataToSend);
            }

            dataToSend.search = term;
            $.getJSON(settings.ajaxPath, dataToSend, function (data) {
                response(data);
                if (settings.response !== null && settings.response !== undefined) {
                    settings.response.call(this, data);
                }

            });
        };

        settings.renderItem = function (item, search) {
            search = search.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
            var re = new RegExp('(' + search.split(' ').join('|') + ")", "gi");

            var attributes = '';

            if (item.Data !== null) {
                for (var key in item.Data) {
                    if (item.Data.hasOwnProperty(key)) {
                        attributes += ' data-' + key + '="' + item.Data[key] + '"';
                    }
                }
            }

            return '<div class="autocomplete-suggestion" data-id="' + item.Value + '" data-val="' + item.Text + '"' + attributes + '">' + item.Text.replace(re, '<b>$1</b>') + '</div>';
        };

        settings.onSelect = function(e, term, item) {

            if (idField !== null && idField !== undefined) {
                $(idField).val(item.attr('data-id'));
            }

            if (settings.callback !== null && settings.callback !== undefined) {
                settings.callback.call(this, $(item).data());
            }
        };

        $(this).autoComplete(settings);
    };

}(jQuery));