﻿using Comitas.CAF.Core.Collections;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Web.Mvc;
using Aushub.Shared.Services;
using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.SearchAndPaging;
using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Comitas.CAF.Core.Logging;


namespace Aushub.Mvc.Controllers
{
    [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
    public class FirmenController : BaseController
    {
        IFirmaService firmenService;
        IUserService userService;
        ILogService logService;
        IMapper mapper;

        public FirmenController(IFirmaService firmenservice, IUserService userservice, ILogService logservice, IMapper mapper)
        {
            this.firmenService = firmenservice;
            this.userService = userservice;
            this.logService = logservice;
            this.mapper = mapper;
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public virtual ActionResult Index(int? id, [Bind(Prefix = "s")] FirmenSearchAndPagingParameters parameters)
        {
            return View("Index", GetIndexViewModel(id, null, parameters));
        }

        protected BaseIndexModel<FirmenModel, FirmenDetailModel, FirmenSearchAndPagingParameters> GetIndexViewModel(int? id, FirmenDetailModel entityModel, FirmenSearchAndPagingParameters parameters)
        {

            if (parameters == null)
                parameters = new FirmenSearchAndPagingParameters();

            FirmenDetailModel detailModel = GetDetailModel(id);

            // Query String mit GridView Parametern eigentlich nicht mehr notwendig!
            return new BaseIndexModel<FirmenModel, FirmenDetailModel, FirmenSearchAndPagingParameters>()
            {
                PagedList = GetPagedEntites(parameters),
                Search = parameters,
                CurrentEntity = detailModel
            };
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult Load(int id)
        {
            ModelState.Clear(); // Damit ggf. neue Id übernommen wird

            FirmenDetailModel model = GetDetailModel(id);

            return PartialView("FirmenDetailPartial", model);
        }

        private FirmenDetailModel GetDetailModel(int? id)
        {
            if (!id.HasValue)
                return null;

            Firma view = firmenService.GetById(id.Value);

            var model = view == null ? new FirmenDetailModel() : mapper.Map<FirmenDetailModel>(view);
            return model;
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public ActionResult GetGrid(FirmenSearchAndPagingParameters searchAndPaging)
        {
            return PartialView("Grid", GetPagedEntites(searchAndPaging));
        }

        private PagedList<FirmenModel> GetPagedEntites(FirmenSearchAndPagingParameters searchAndPaging)
        {
            bool selCrit = User.IsInRole(Role.Sysadmin);

            var pagedEntities = firmenService.GetFirmenPaged(searchAndPaging, selCrit);

            return new PagedList<FirmenModel>(mapper.Map<IEnumerable<FirmenView>, IEnumerable<FirmenModel>>(pagedEntities),
                                                         pagedEntities.PageIndex,
                                                         pagedEntities.PageSize,
                                                         pagedEntities.TotalCount);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult Save(FirmenDetailModel model)
        {

            var saveResult = TrySave(model);

            if (saveResult.Status)
            {
                SetSuccessMessage("Ihre Daten wurden erfolgreich gespeichert.");
                logService.Save($"Firma {model.Firmenname} wurde gespeichert", "Firmenverwaltung", UserId);
                return Load(saveResult.Id);
            }

            return PartialView("FirmenDetailPartial", model);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult SaveNew(FirmenDetailModel model)
        {
            return SaveNew<FirmenDetailModel>(Save(model));
        }

        private (bool Status, int Id) TrySave(FirmenDetailModel model)
        {
            if (!ModelState.IsValid)
            {
                return (false, 0);
            }

            Firma firma = new Firma();

            if (model.Id > 0)
                firma = firmenService.GetById(model.Id);

            mapper.Map(model, firma);

            return (ExecuteActionWithValidationErrorHandling(() => firmenService.Save(firma)), firma.Id);
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public JsonResult Delete(int id)
        {
            bool status = false;
            string firma = $"{firmenService.GetById(id).Firmenname} (Id: {id})";

            try
            {
                if (firmenService.Delete(id))
                {
                    status = true;
                    logService.Save($"Firma {firma} wurde gelöscht", "Firmenverwaltung", UserId);
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }

            var result = new
            {
                Status = status
            };

            return Json(result, JsonRequestBehavior.AllowGet);
        }

    }
}