using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using Aushub.Shared.ViewModels;

namespace Aushub.App.Depots
{
    public interface IFirmaDepot : IDepot<Firma, int>
    {
        List<Firma> GetAll(bool bwithSystem);
        PagedList<FirmenView> GetFirmenPaged(FirmenSearchAndPagingParameters searchAndPaging, bool selCrit);
        string GetListOfCompaniesForHome();
        Firma GetByUID(string uid);

    }
}
