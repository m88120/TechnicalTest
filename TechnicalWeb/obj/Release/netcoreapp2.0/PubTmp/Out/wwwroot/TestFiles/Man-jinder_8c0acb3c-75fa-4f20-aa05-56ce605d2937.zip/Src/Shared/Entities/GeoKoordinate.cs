﻿using Comitas.CAF.Core.Entities;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Utilities;
using Aushub.Shared.Templating;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aushub.Shared.Interfaces;
using System.Data.SqlClient;
using System.Data;

namespace Aushub.Shared.Entities
{
    [AutoGen]
    public class GeoKoordinate : BaseEntity<int>
    {
        public string Postleitzahl { get; set; }
        public string Ort { get; set; }
        public float Longitude { get; set; }
        public float Latitude { get; set; }


        public const string CountryCode = "CH";

        public const string RegexFormat = "^.+,.+,.+$";

        public static string GetAddress(string zip, string city, string countryCode)
        {
            if (zip == null || city == null || countryCode == null)
                return null;

            return $"{zip}, {city}, {countryCode}";
        }

        public static string GetAddress(IAddress entity)
        {
            return GetAddress(entity.Zip, entity.City, entity.CountryCode);
        }

        public override string ToString()
        {
            return GetAddress(Postleitzahl, Ort, CountryCode);
        }
    }
}
