﻿using Comitas.CAF.Core.Entities;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Utilities;
using Aushub.Shared.Templating;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.Entities
{
    [AutoGen]
    public class InseratsSubkategorie : BaseEntity<int>
    {
        public int IKId { get; set; }
        public string Subkategorie { get; set; }
        public string Standardbild { get; set; }
    }
}
