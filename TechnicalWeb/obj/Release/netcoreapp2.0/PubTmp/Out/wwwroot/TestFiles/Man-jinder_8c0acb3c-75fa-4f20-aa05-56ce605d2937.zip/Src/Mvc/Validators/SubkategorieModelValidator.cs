﻿using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Aushub.Shared.Services;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Validators
{
    public class SubkategorieModelValidator : AbstractValidator<SubkategorieDetailModel>
    {
        public SubkategorieModelValidator()
        {
            RuleFor(x => x.Subkategorie).NotEmpty().WithMessage("Subkategorie darf nicht leer sein");
        }
    }
}