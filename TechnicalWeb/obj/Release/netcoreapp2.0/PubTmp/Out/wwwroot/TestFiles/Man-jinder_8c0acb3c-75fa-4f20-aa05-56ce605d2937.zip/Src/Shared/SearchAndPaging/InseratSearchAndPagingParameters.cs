﻿using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.SearchAndPaging
{
    public class InseratSearchAndPagingParameters : SearchAndPagingParameters
    {
        public int? IKId { get; set; }
        public int? ISId { get; set; }
        public string PlzOrt { get; set; }
        public string UmkreisVon { get; set; }
        public int? LI_InseratstypId { get; set; }
        public int? FIId { get; set; }
        public decimal? PreisVon { get; set; }
        public decimal? PreisBis { get; set; }
        public DateTime? VerfuegbarVon { get; set; }
        public DateTime? VerfuegbarBis { get; set; }
        public int? MengeVon { get; set; }
        public int? MengeBis { get; set; }
        public int? UserId { get; set; }

    }
}
