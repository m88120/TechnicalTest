﻿using Comitas.CAF.Core.Collections;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aushub.Shared;
using Aushub.Shared.Services;
using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.SearchAndPaging;
using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Comitas.CAF.Core.Logging;
using System.Data;
using System.Globalization;
using System.Web.UI;

namespace Aushub.Mvc.Controllers
{
    [AuthorizeRoles(Role.Sysadmin)]
    public class GeokoordinatenController : BaseController
    {
        IGeoKoordinateService geoService;
        ILogService logService;
        IMapper mapper;

        public GeokoordinatenController(IGeoKoordinateService geoservice, ILogService logservice, IMapper mapper)
        {
            this.geoService = geoservice;
            this.logService = logservice;
            this.mapper = mapper;
        }

        [AuthorizeRoles(Role.Sysadmin)]
        public virtual ActionResult Index(int? id, [Bind(Prefix = "s")] GeoKoordinatenSearchAndPagingParameters parameters)
        {
            return View("Index", GetIndexViewModel(id, null, parameters));
        }

       protected BaseIndexModel<GeoKoordinatenModel, GeoKoordinatenDetailModel, GeoKoordinatenSearchAndPagingParameters> GetIndexViewModel(int? id, GeoKoordinatenDetailModel entityModel, GeoKoordinatenSearchAndPagingParameters parameters)
        {

            if (parameters == null)
                parameters = new GeoKoordinatenSearchAndPagingParameters();

            GeoKoordinatenDetailModel detailModel = GetDetailModel(id);

            // Query String mit GridView Parametern eigentlich nicht mehr notwendig!
            return new BaseIndexModel<GeoKoordinatenModel, GeoKoordinatenDetailModel, GeoKoordinatenSearchAndPagingParameters>()
            {
                PagedList = GetPagedEntites(parameters),
                Search = parameters,
                CurrentEntity = detailModel
            };
        }

        [AuthorizeRoles(Role.Sysadmin)]
        public PartialViewResult Load(int id)
        {
            ModelState.Clear(); // Damit ggf. neue Id übernommen wird

            GeoKoordinatenDetailModel model = GetDetailModel(id);

            return PartialView("GeoKoordinatenDetailPartial", model);
        }

        private GeoKoordinatenDetailModel GetDetailModel(int? id)
        {
            if (!id.HasValue)
                return null;

            GeoKoordinate view = geoService.GetById(id.Value);

            var model = view == null ? new GeoKoordinatenDetailModel() : mapper.Map<GeoKoordinatenDetailModel>(view);
            return model;
        }

        [AuthorizeRoles(Role.Sysadmin)]
        public ActionResult GetGrid(GeoKoordinatenSearchAndPagingParameters searchAndPaging)
        {
            return PartialView("Grid", GetPagedEntites(searchAndPaging));
        }

        private PagedList<GeoKoordinatenModel> GetPagedEntites(GeoKoordinatenSearchAndPagingParameters searchAndPaging)
        {
            var pagedEntities = geoService.GetGeoKoordinatenPaged(searchAndPaging);

            return new PagedList<GeoKoordinatenModel>(mapper.Map<IEnumerable<GeoKoordinatenView>, IEnumerable<GeoKoordinatenModel>>(pagedEntities),
                                                         pagedEntities.PageIndex,
                                                         pagedEntities.PageSize,
                                                         pagedEntities.TotalCount);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Sysadmin)]
        public PartialViewResult Save(GeoKoordinatenDetailModel model)
        {

            var saveResult = TrySave(model);

            if (saveResult.Status)
            {
                SetSuccessMessage("Die Geokoordinaten wurden gespeichert.");
                logService.Save($"Geokoordinaten von {model.Postleitzahl} {model.Ort} wurden gespeichert", "Geokoordinatenverwaltung", UserId);
                return Load(saveResult.Id);
            }

            return PartialView("GeoKoordinatenDetailPartial", model);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Sysadmin)]
        public PartialViewResult SaveNew(GeoKoordinatenDetailModel model)
        {
            return SaveNew<GeoKoordinatenDetailModel>(Save(model));
        }

        private (bool Status, int Id) TrySave(GeoKoordinatenDetailModel model)
        {
            if (!ModelState.IsValid)
            {
                return (false, 0);
            }

            GeoKoordinate geo = new GeoKoordinate();

            if (model.Id > 0)
                geo = geoService.GetById(model.Id);

            mapper.Map(model, geo);

            return (ExecuteActionWithValidationErrorHandling(() => geoService.Save(geo)), geo.Id);
        }

        [AllowAnonymous]
        public JsonResult SearchCities(string search)
        {
            var cities = geoService.SearchCity(search)
                                   .Select(x => new TextValueItem(x.ToString(), x.Id))
                                   .ToList();

            return Json(cities, JsonRequestBehavior.AllowGet);
        }

        [AuthorizeRoles(Role.Sysadmin)]
        public JsonResult Delete(int id)
        {
            bool status = false;
            GeoKoordinate gk = geoService.GetById(id);

            try
            {
                geoService.Delete(id);
                status = true;
                logService.Save($"Geokoordinaten von {gk.Postleitzahl} {gk.Ort} wurden gelöscht", "Geokoordinatenverwaltung", UserId);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }

            var result = new
            {
                Status = status
            };

            return Json(result, JsonRequestBehavior.AllowGet);
        }

    }
}