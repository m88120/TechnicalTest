﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using Aushub.Shared.ViewModels;

namespace Aushub.Shared.Services
{
    public interface IInseratsKategorieService : IEntityIdService<InseratsKategorie, int>
    {
        List<InseratsKategorie> GetAll(bool bWithTransport);
        void Save(InseratsKategorie entity);
        PagedList<InseratsKategorieView> GetKategorienPaged(KategorieSearchAndPagingParameters searchAndPaging);
        bool Delete(int id);
    }
}
