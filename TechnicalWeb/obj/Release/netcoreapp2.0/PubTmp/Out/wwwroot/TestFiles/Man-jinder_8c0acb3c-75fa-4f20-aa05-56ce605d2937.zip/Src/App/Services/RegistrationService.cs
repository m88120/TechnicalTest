﻿using Aushub.App.Depots;
using Aushub.Shared.Entities;
using Aushub.Shared.Services;
using Aushub.Shared.SearchAndPaging;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Collections;
using FluentValidation;
using System.Net.Mail;

namespace Aushub.App.Services
{
    public class RegistrationService : NPocoBaseService<IRegistrationDepot, Registration, int>, IRegistrationService
    {
        IUserService userService;

        public RegistrationService(IRegistrationDepot baseDepot, IValidatorFactory validatorFactory, IMailService mailService, IAuthorizationManager authorizationManager, IUserService userservice)
        : base(baseDepot, validatorFactory, mailService, authorizationManager)
        {
            this.userService = userservice;
        }

        public void SendMailToRegistrationAdmins(User user, Registration registration, string link)
        {
            List<User> admins = userService.GetAllByRole("Admin");
            string mailAddress = string.Join(",", admins.Select(x => x.Email).ToArray());

            SendRegistrationMail(mailAddress, user, registration, link, GetRegistrationMailText, GetRegistrationMailSubject);
        }

        public void SendMailToRegistrant(User user, Registration registration, string link)
        {
            string mailAddress = user.Email;
            SendRegistrationMail(mailAddress, user, registration, link, GetRegistrantMailText, GetRegistrationMailSubject);
        }

        private void SendRegistrationMail(string mailAddress, User user, Registration registration, string link, Func<User, Registration, string, string> getMailText, Func<string> getMailSubject)
        {
            MailMessage regMessage = new MailMessage();
            regMessage.To.Add(mailAddress);
            regMessage.Subject = getMailSubject();

            string message = getMailText(user, registration, link);

            regMessage.Body = "<div>" + message + "</div>";
            regMessage.IsBodyHtml = true;

            MailService.Send(regMessage);
        }

        private string GetRegistrationMailSubject()
        {
            return $"Aushub24: Benutzer Registrierung";
        }

        private string GetRegistrationMailText(User user, Registration registration, string link)
        {
            link += "Account/Index";
            string message = $"Hallo Administratoren,<br/><br />Ein neuer Benutzer hat sich auf Aushub24 angemeldet. Die Daten:<br /><br />";
            message += $"<strong>Name</strong>: {user.Firstname} {user.Lastname}<br /><strong>Firma</strong>: {registration.Firmenname}, {registration.Ort}<br/><br />";
            message += $"Bitte kontrollieren Sie in der <a href=\"{link}\">Benutzerverwaltung</a>, ob der Benutzer aktiviert werden kann.";
            message += GetSignature();
            return message;
        }

        private string GetRegistrantMailText(User user, Registration registration, string link)
        {
            string message = $"Sehr geehrte Benutzerin, sehr geehrter Benutzer,<br /><br />Sie haben sich soeben auf Aushub24 mit folgenden Daten angemeldet: <br /><br />";
            message += $"<table><tr><td><strong>Name</strong>:</td><td>{user.Firstname} {user.Lastname}</td></tr>";
            message += $"<tr><td><strong>Firma</strong>:</td><td>{registration.Firmenname}, {registration.Postleitzahl} {registration.Ort}, {registration.Strasse}</td></tr></table><br /><br />";
            message += $"Ihre Daten werden durch unseren Administrator überprüft, damit Sie so schnell als möglich freigeschaltet werden können. Sobald dies erfolgt, werden Sie wiederum durch ein eMail verständigt,";
            message += $"und können dann auf <a href=\"{link}\">Aushub24</a> mit Ihren Wünschen loslegen.<br /><br />";
            message += $"Sollten Sie noch Fragen haben, antworten Sie bitte einfach auf dieses E-Mail oder rufen Sie uns an."; 
            message += GetSignature();
            return message;
        }

        private string GetSignature()
        {
            string sig = "<br /><br />Mit freundlichen Grüssen,<br/><br />Ihr Portal Team";
            sig = "<br/><br/><span style=\"color:#bea25a;font-weight:bold;\">Aushub24</span>";
            sig += "<br/>Zürichstrasse 1 | 8000 Zurich | Switzerland";
            sig += "<br/>Tel + 41 45 555 15555750 | Fax + 41 46 5555 5555 | info@aushub24.ch<br/>";

            return sig;
        }

    }
}

