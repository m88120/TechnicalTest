﻿using Aushub.Mvc.Models;
using Aushub.Shared.Services;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Validators
{
    public class ChangePasswordValidator : AbstractValidator<ChangePasswordModel>
    {
        IUserService userService;

        public ChangePasswordValidator(IUserService userService)
        {
            this.userService = userService;

            RuleFor(x => x.CurrentPassword).EmailAddress().WithMessage("Aktuelles Kennwort muss eine gültige Mailadresse sein");
            RuleFor(x => x.NewPassword).EmailAddress().WithMessage("Neues Kennwort muss eine gültige Mailadresse sein");
            RuleFor(x => x.NewPasswordRepeat).NotEmpty().WithMessage("Bestätigungskennwort darf nicht leer sein");
            RuleFor(x => x.NewPassword).Equal(y => y.NewPasswordRepeat).WithMessage("Kennwort und Bestätigungskennwort müssen ident sein");
        }
    }
}