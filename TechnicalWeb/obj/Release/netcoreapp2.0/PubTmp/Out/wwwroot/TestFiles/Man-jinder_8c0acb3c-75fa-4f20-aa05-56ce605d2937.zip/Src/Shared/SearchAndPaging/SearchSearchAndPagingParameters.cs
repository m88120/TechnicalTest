﻿using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Aushub.Shared.Entities;

namespace Aushub.Shared.SearchAndPaging
{
    public class SearchSearchAndPagingParameters : SearchAndPagingParameters
    {
        [Display(Name = "Was?")]
        public int IKId { get; set; }
        public List<InseratsKategorie> Kategorien { get; set; }

        public int ISId { get; set; }
        public List<InseratsSubkategorie> Subkategorien { get; set; }

        [Display(Name = "Wo?")]
        public string PlzOrt { get; set; }
        public string PLZId { get; set; }
        public int UmkreisVon { get; set; }
        public List<Umkreise> UmkreisVonList { get; set; }

        [Display(Name = "Typ?")]
        public int LI_InseratstypId { get; set; }
        public List<ListItem> InseratstypListItems { get; set; }

        public bool Detailsuche { get; set; }

        [Display(Name = "Firma")]
        public int FIId { get; set; }
        public List<Firma> Firmen { get; set; }

        [Display(Name = "Preis")]
        public decimal? PreisVon { get; set; }
        public decimal? PreisBis { get; set; }
        [Display(Name = "Verfügbar")]
        public DateTime? VerfuegbarVon { get; set; }
        public DateTime? VerfuegbarBis { get; set; }
        [Display(Name = "Menge")]
        public int? MengeVon { get; set; }
        public int? MengeBis { get; set; }

        public int Ansicht { get; set; }


        public SearchSearchAndPagingParameters() : base()
        {
            PageSize = 10;
        }

    }
}
