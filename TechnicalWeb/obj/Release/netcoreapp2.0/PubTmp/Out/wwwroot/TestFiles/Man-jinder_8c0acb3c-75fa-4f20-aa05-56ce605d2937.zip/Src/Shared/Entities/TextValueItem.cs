﻿
namespace Aushub.Shared.Entities
{
    public class TextValueItem
    {
        public string Text { get; set; }
        public int Value { get; set; }
        public object Data { get; set; }

        public TextValueItem() { }
        public TextValueItem(string text, int value)
        {
            Text = text;
            Value = value;
        }

        public TextValueItem(string text, int value, object data)
        {
            Text = text;
            Value = value;
            Data = data;
        }
    }
}