﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using Aushub.Shared.ViewModels;

namespace Aushub.Shared.Services
{
    public interface IListItemService : IEntityIdService<ListItem, int>
    {
        List<ListItem> GetByListGroup(string group);
        ListItem GetByListGroupAndPosition(string group, int position);
        List<ListItem> GetAll();
        PagedList<ListItemView> GetListItemPaged(ListItemSearchAndPagingParameters searchAndPaging);
        void Save(ListItem entity);
        bool Delete(int id);
        List<string> GetAllGroups();
    }
}
