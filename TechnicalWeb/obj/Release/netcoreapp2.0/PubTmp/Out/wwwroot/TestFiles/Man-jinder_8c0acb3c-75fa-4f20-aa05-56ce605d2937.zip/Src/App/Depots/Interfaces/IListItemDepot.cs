using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Aushub.App.Depots
{
    public interface IListItemDepot : IDepot<ListItem, int>
    {
        List<ListItem> GetByListGroup(string group);
        ListItem GetByListGroupAndPosition(string group, int position);
        List<ListItem> GetAll();
        PagedList<ListItemView> GetListItemPaged(ListItemSearchAndPagingParameters searchAndPaging);
        List<string> GetAllGroups();
    }
}
