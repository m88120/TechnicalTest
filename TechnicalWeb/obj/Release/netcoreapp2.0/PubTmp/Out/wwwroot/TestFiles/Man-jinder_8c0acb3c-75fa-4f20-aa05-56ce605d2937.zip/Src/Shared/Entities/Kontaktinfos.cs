﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.Entities
{
    public class Kontaktinfos
    {
        public int Id { get; set; }
        public string Telefon { get; set; }
        public string Mobilnummer { get; set; }
        public string Mailadresse { get; set; }

    }
}
