﻿using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.SearchAndPaging
{
    public class RoleSearchAndPagingParameters : SearchAndPagingParameters
    {
        public string Like { get; set; }

        public RoleSearchAndPagingParameters() : base()
        {
            PageSize = 5;
        }

    }
}
