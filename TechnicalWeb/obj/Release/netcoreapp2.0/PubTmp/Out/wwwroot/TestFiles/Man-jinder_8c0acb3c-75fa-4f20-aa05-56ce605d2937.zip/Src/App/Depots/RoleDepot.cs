﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Collections;
using NPoco;


namespace Aushub.App.Depots
{
    public class RoleDepot : PagingDepot<Role, RoleView, string>, IRoleDepot
    {
        public RoleDepot(INPocoDbContext dbContext, IAuthorizationManager authorizationManager) : base(dbContext, authorizationManager)
        {
        }

        public List<Role> GetAllRoles(bool withSysadmin)
        {
            if (withSysadmin)
                return Database.Query<Role>(GetBaseSelectSql()).ToList();
            else
                return Database.Query<Role>(GetBaseSelectSql()).Where(x => x.Id != Role.Sysadmin).ToList();
        }

        public Role GetRoleById(string id)
        {
            return Database.Query<Role>(GetBaseSelectSql()).Where(x => x.Id == id).FirstOrDefault();
        }

        public List<Role> GetRolesForUser(int userId)
        {
            var sql = GetBaseSelectSql()
                          .InnerJoin("UserRoles").On("USR_RoleId = RO_ID")
                          .Where("USR_UserId = @Id", new { Id = userId });

            return Database.Fetch<Role>(sql);
        }

        public PagedList<RoleView> GetRolePaged(RoleSearchAndPagingParameters searchAndPaging)
        {
            Sql select = GetViewBaseSelectSql();

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Like))
            {
                select = select.Where("RL_Id LIKE @Like OR RL_Description LIKE @Like", new { Like = $"%{searchAndPaging.Like}%" });
            }

            return GetPagedAuto(searchAndPaging, select, "RL_Id ASC");
        }

        private Sql GetViewBaseSelectSql()
        {
            string[] columns = new string[]
            {
                "*"
            };

            Sql select = Sql.Builder.Select(columns).From("Roles");

            return select;
        }

    }
}
