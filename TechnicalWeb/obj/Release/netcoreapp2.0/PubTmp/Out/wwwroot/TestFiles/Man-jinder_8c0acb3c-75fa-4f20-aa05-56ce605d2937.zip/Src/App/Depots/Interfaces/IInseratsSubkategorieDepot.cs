using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Aushub.App.Depots
{
    public interface IInseratsSubkategorieDepot : IDepot<InseratsSubkategorie, int>
    {
        List<InseratsSubkategorie> GetAll();
        List<InseratsSubkategorie> GetByKategorieId(int kategorieId);
    }
}
