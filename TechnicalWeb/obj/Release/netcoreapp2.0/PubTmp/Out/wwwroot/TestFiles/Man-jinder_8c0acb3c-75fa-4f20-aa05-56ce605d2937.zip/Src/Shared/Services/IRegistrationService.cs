﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Aushub.Shared.Services
{
    public interface IRegistrationService : IEntityIdService<Registration, int>
    {
        void SendMailToRegistrationAdmins(User user, Registration registration, string link);
        void SendMailToRegistrant(User user, Registration registration, string link);
    }
}
