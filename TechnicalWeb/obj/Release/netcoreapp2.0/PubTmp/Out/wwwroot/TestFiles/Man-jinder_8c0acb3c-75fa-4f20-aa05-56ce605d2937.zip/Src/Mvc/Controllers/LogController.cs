﻿using Comitas.CAF.Core.Collections;
using AutoMapper;
using Aushub.Mvc.Code;
using Aushub.Mvc.Models;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Shared.Services;
using Aushub.Shared.SearchAndPaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Aushub.Mvc.Controllers
{
    [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
    public class LogController : BaseController
    {
        IUserService userService;
        ILogService logService;
        IMapper mapper;

        public LogController(IUserService userService, ILogService logservice, IMapper mapper)
        {
            this.userService = userService;
            this.logService = logservice;
            this.mapper = mapper;
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public virtual ActionResult Index(int? id, [Bind(Prefix = "s")] LogSearchAndPagingParameters parameters)
        {
            return View("Index", GetIndexViewModel(id, null, parameters));
        }

        protected BaseIndexModel<LogModel, LogDetailModel, LogSearchAndPagingParameters> GetIndexViewModel(int? id, LogDetailModel entityModel, LogSearchAndPagingParameters parameters)
        {

            if (parameters == null)
                parameters = new LogSearchAndPagingParameters();

            InitializeSearchListboxes(parameters);

            LogDetailModel detailModel = GetDetailModel(id);

            // Query String mit GridView Parametern eigentlich nicht mehr notwendig!
            return new BaseIndexModel<LogModel, LogDetailModel, LogSearchAndPagingParameters>()
            {
                PagedList = GetPagedEntites(parameters),
                Search = parameters,
                CurrentEntity = detailModel
            };
        }

        private void InitializeSearchListboxes(LogSearchAndPagingParameters parameters)
        {
            List<string> modulelist = logService.GetAllModules();
            modulelist.Insert(0, "");
            parameters.Modules = modulelist;
        }


        private LogDetailModel GetDetailModel(int? id)
        {
            if (!id.HasValue)
                return null;

            Log view = logService.GetById(id.Value);

            var model = view == null ? new LogDetailModel() : mapper.Map<LogDetailModel>(view);
            return model;
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public ActionResult GetGrid(LogSearchAndPagingParameters searchAndPaging)
        {
            return PartialView("Grid", GetPagedEntites(searchAndPaging));
        }

        private PagedList<LogModel> GetPagedEntites(LogSearchAndPagingParameters searchAndPaging)
        {
            PagedList<LogView> pagedEntities = logService.GetLogsPaged(searchAndPaging);

            return new PagedList<LogModel>(mapper.Map<IEnumerable<LogView>, IEnumerable<LogModel>>(pagedEntities),
                                                         pagedEntities.PageIndex,
                                                         pagedEntities.PageSize,
                                                         pagedEntities.TotalCount);
        }

    }
}