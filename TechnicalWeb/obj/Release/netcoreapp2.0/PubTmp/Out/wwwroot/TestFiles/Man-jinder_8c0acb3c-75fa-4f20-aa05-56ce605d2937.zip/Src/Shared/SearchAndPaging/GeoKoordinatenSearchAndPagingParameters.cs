﻿using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.SearchAndPaging
{
    public class GeoKoordinatenSearchAndPagingParameters : SearchAndPagingParameters
    {
        public string Postleitzahl { get; set; }
        public string Ort { get; set; }


        public GeoKoordinatenSearchAndPagingParameters() : base()
        {
            PageSize = 5;
        }

    }
}
