﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aushub.Mvc.Code;

namespace Aushub.Mvc.Controllers
{
    public class ImpressumController : BaseController
    {
        // GET: Impressum
        public ActionResult Index()
        {
            return View();
        }
    }
}