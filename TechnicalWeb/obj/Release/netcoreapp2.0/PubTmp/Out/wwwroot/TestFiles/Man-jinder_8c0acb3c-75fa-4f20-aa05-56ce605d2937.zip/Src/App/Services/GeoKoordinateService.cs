﻿using Aushub.App.Depots;
using Aushub.Shared.Entities;
using Aushub.Shared.Services;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Collections;
using FluentValidation;

namespace Aushub.App.Services
{
    public class GeoKoordinateService : NPocoBaseService<IGeoKoordinateDepot, GeoKoordinate, int>, IGeoKoordinateService
    {
        public GeoKoordinateService(IGeoKoordinateDepot baseDepot, IValidatorFactory validatorFactory, IMailService mailService, IAuthorizationManager authorizationManager)
        : base(baseDepot, validatorFactory, mailService, authorizationManager)
        {
        }
        public List<GeoKoordinate> GetByPlzOrt(string Postleitzahl, string Ort)
        {
            return Depot.GetByPlzOrt(Postleitzahl, Ort);
        }

        public List<GeoKoordinate> SearchCity(string search)
        {
            return Depot.SearchCity(search, 15);
        }

        public PagedList<GeoKoordinatenView> GetGeoKoordinatenPaged(GeoKoordinatenSearchAndPagingParameters searchAndPaging)
        {
            return Depot.GetGeoKoordinatenPaged(searchAndPaging);
        }

        public void Save(GeoKoordinate entity)
        {
            Depot.Save(entity);
        }

        public void Delete(int id)
        {
            Depot.Delete(id);
        }
    }
}
