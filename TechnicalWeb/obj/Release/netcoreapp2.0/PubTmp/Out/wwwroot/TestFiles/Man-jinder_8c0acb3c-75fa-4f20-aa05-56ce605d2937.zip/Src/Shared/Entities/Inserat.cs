﻿using Comitas.CAF.Core.Entities;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Utilities;
using Aushub.Shared.Templating;
using Aushub.Shared.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.Entities
{
    [AutoGen]
    public class Inserat : CreateUpdateDateWithUserBaseEntity<int>
    {
        public int FIId { get; set; }
        public int IKId { get; set; }
        public int ISId { get; set; }
        public int LI_InseratstypId { get; set; }
        public string Bild1 { get; set; }
        public string Bild2 { get; set; }
        public string Bild3 { get; set; }
        public string Dokument { get; set; }
        public string Beschreibung { get; set; }
        public string Postleitzahl { get; set; }
        public string Ort { get; set; }
        public float Longitude { get; set; }
        public float Latitude { get; set; }
        public int US_KontaktId { get; set; }
        public bool MailadresseAnzeigen { get; set; }
        public bool TelefonAnzeigen { get; set; }
        public bool MobilnummerAnzeigen { get; set; }
        public Verfuegbarkeit IstVerfuegbarAb { get; set; }
        public DateTime? VerfuegbarAb { get; set; }
        public Verfuegbarkeit IstVerfuegbarBis { get; set; }
        public DateTime? VerfuegbarBis { get; set; }
        public int VerfuegbareMenge { get; set; }
        public int LI_MengeneinheitId { get; set; }
        public Zahlungsart Zahlungsbedingung { get; set; }
        public Decimal? IchZahleDemAbnehmerDenPreis { get; set; }
        public Decimal? DerAbnehmerZahltDenPreis { get; set; }
        public int LI_InseratstatusId { get; set; }
        public int LI_InseratTeilenAufId { get; set; }
        public string Transport_PLZ_Von { get; set; }
        public string Transport_Ort_Von { get; set; }
        public string Transport_PLZ_Bis { get; set; }
        public string Transport_Ort_Bis { get; set; }
    }
}
