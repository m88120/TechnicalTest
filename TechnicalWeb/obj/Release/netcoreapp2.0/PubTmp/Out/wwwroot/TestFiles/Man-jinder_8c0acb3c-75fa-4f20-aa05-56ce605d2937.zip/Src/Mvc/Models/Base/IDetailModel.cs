﻿
namespace Aushub.Mvc.Models.Base
{
    public interface IDetailModel
    {

    }
}
