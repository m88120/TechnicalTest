﻿using System;
using System.Collections.Generic;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.Entities;

namespace Aushub.Mvc.Models
{
    public class UserDetailModel : UserModel, IDetailModel
    {
        public List<ListItem> SalutationListItems { get; set; }
        public List<Role> Rollen { get; set; }
        public List<Firma> Firmen { get; set; }
        public string DeactivatedUserDisplayName { get; set; }
        public string CreateUserDisplayName { get; set; }
        public string UpdateUserDisplayName { get; set; }

        public UserDetailModel()
        {
            IsSystemUser = false;
            WillSammelmailErhalten = true;
            RoleKey = Role.User;
            HasAcceptedAGBs = false;
            LI_UserstatusId = (int)ListItem.UserstatusPositionEnum.Registriert;
            Userstatus = "registriert";
        }

    }
}