﻿using Aushub.Mvc.Models;
using Aushub.Shared.Services;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Validators
{
    public class UserModelValidator : AbstractValidator<UserDetailModel>
    {
        IUserService userService;

        public UserModelValidator(IUserService userService)
        {
            this.userService = userService;

            RuleFor(x => x.Email).NotEmpty().WithMessage("Email darf nicht leer sein")
                                 .EmailAddress().WithMessage("Email ist keine gültige Email-Adresse")
                                 .Must(NotBeADuplicate).WithMessage("Email ist bereits vorhanden");
            RuleFor(x => x.LI_SalutationId).NotEmpty().NotEqual(0).WithMessage("Anrede darf nicht leer sein");
            RuleFor(x => x.Firstname).NotEmpty().WithMessage("Vorname darf nicht leer sein");
            RuleFor(x => x.Lastname).NotEmpty().WithMessage("Nachname darf nicht leer sein");
            RuleFor(x => x.RoleKey).NotEmpty().WithMessage("Dem Benutzer muss eine Rolle zugewiesen sein.");
            RuleFor(x => x.Telefon).Must(OneOfThePhonesMustExist).WithMessage("Entweder Telefon oder Mobilnummer muss angegeben werden");
            RuleFor(x => x.MobilNumber).Must(OneOfThePhonesMustExist).WithMessage("Entweder Telefon oder Mobilnummer muss angegeben werden");
            RuleFor(x => x.FIId).NotEmpty().NotEqual(0).WithMessage("Firmenzuordnung darf nicht leer sein");
            RuleFor(x => x.HasAcceptedAGBs).Equal(true).WithMessage("AGBs müssen akzeptiert sein");
        }

        private bool NotBeADuplicate(UserDetailModel model, string newValue)
        {
            var user = userService.GetByEmail(model.Email);

            return (user == null || (user != null && user.Email == model.Email && user.Id == model.Id));
        }
        private bool OneOfThePhonesMustExist(UserDetailModel model, string newValue)
        {
            return (!string.IsNullOrWhiteSpace(model.Telefon) || !string.IsNullOrWhiteSpace(model.MobilNumber));
        }
    }
}