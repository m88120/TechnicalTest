﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using AutoMapper.Mappers;
using Aushub.Shared.Entities;
using Aushub.Shared.Interfaces;
using Aushub.Shared.Services;
using Aushub.Shared.ViewModels;
using Aushub.Mvc.Models;
using Aushub.Mvc.Models.Base;

namespace Aushub.Mvc.AutoMapper
{
    public class AushubProfile : Profile
    {
        public AushubProfile()
        {
            CreateMap<User, UserModel>();
            CreateMap<User, UserDetailModel>()
                .IncludeBase<User, UserModel>();

            CreateMap<Role, RoleModel>();

            CreateMap<InseratsKategorieView, KategorieModel>()
                .IncludeBase<InseratsKategorie, KategorieModel>();

            //    .ForMember(dest => dest.SelectedRoles, opt => opt.MapFrom(src => src.Roles.Select(x => x.Id).ToList()))
            //    .ForMember(dest => dest.InactiveDate, opt => opt.MapFrom(src => src.InactiveDate.HasValue ? src.InactiveDate.Value.ToString("g") : ""))
            //    .ForMember(dest => dest.LastLogin, opt => opt.MapFrom(src => src.LastLogin.HasValue ? src.LastLogin.Value.ToString("g") : "nie"));

        }
    }
}