﻿using System;
using System.Collections.Generic;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.Entities;


namespace Aushub.Mvc.Models
{
    public class LogDetailModel : LogModel, IDetailModel
    {
    }
}