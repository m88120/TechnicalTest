using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Security;
using NPoco;

namespace Aushub.App.Depots
{
    public class InseratsSubkategorieDepot : BaseDepot<InseratsSubkategorie, int>, IInseratsSubkategorieDepot
    {
        public InseratsSubkategorieDepot(INPocoDbContext dbContext, IAuthorizationManager authorizationManager)
            : base(dbContext, authorizationManager)
        {
        }
        public List<InseratsSubkategorie> GetAll()
        {
            Sql select = GetBaseSelectSql();
            return Database.Query<InseratsSubkategorie>(select).ToList();
        }

        public List<InseratsSubkategorie> GetByKategorieId(int kategorieId)
        {
            return Database.Query<InseratsSubkategorie>(GetBaseSelectSql()).Where(x => x.IKId == kategorieId).ToList();
        }
    }
}

