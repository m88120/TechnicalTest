﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Aushub.App.Depots
{
    public interface IRegistrationDepot : IDepot<Registration, int>
    {

    }
}
