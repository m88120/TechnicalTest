﻿using Aushub.Mvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.Web.Mvc;

namespace Aushub.Mvc.Controllers
{
    public class ErrorController : Controller
    {
        public ViewResult PageNotFound(Exception exception)
        {
            Response.StatusCode = 404;
            return View("PageNotFound", null);
        }

        public ViewResult NoAccess(Exception exception)
        {
            Response.StatusCode = 403;
            return View("NoAccess", null);
        }

        public ViewResult Unhandled(Exception exception)
        {
            bool showDetails = (exception != null && MvcApp.Config.ShowUnhandledErrorDetails);
            HttpException httpException = exception as HttpException;

            // Reponse-Status definieren
            if (httpException != null)
            {
                Response.StatusCode = httpException.GetHttpCode();
            }

            // Model befuellen
            UnhandledErrorModel model = new UnhandledErrorModel();

            model.Url = Request.RawUrl;
            model.User = GetUserDisplayName();
            model.DateTime = DateTime.Now;

            model.ShowDetails = showDetails;

            if (showDetails)
            {
                model.ExceptionType = exception.GetType().Name;
                model.ErrorMessage = exception.Message;
                model.StackTrace = exception.StackTrace;
            }

            // View anzeigen
            return View("Unhandled", model);
        }

        private string GetUserDisplayName()
        {
            ClaimsIdentity identity = (ClaimsIdentity)User.Identity;
            return identity.Claims.FirstOrDefault(x => x.Type == ClaimTypes.GivenName)?.Value;
        }
    }
}