﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Aushub.Mvc.Models.Base;
using System.ComponentModel.DataAnnotations;

namespace Aushub.Mvc.Models
{
    public class ListItemModel : BaseEntityModel
    {
        public string Gruppe { get; set; }
        public int Reihenfolge { get; set; }
        public string Bezeichnung { get; set; }
    }
}