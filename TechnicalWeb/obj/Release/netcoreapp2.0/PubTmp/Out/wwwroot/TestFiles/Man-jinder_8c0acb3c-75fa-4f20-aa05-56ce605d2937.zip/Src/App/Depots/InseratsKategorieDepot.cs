using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Collections;
using NPoco;

namespace Aushub.App.Depots
{
    public class InseratsKategorieDepot : PagingDepot<InseratsKategorie, InseratsKategorieView, int>, IInseratsKategorieDepot
    {
        public InseratsKategorieDepot(INPocoDbContext dbContext, IAuthorizationManager authorizationManager)
            : base(dbContext, authorizationManager)
        {
        }

        public List<InseratsKategorie> GetAll(bool bWithTransport)
        {
            Sql select = GetBaseSelectSql();

            if (!bWithTransport)
            {
                select = select.Where("IK_Id >= 0");
            }
            return Database.Query<InseratsKategorie>(select).ToList();
        }

        public PagedList<InseratsKategorieView> GetKategorienPaged(KategorieSearchAndPagingParameters searchAndPaging)
        {
            Sql select = GetViewBaseSelectSql();

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Kategorie))
            {
                select = select.Where("IK_Kategorie LIKE @Like", new { Like = $"%{searchAndPaging.Kategorie}%" });
            }

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Subkategorie))
            {
                select = select.Where("IK_Id IN (select IS_IK_Id FROM InseratsSubkategorien WHERE IS_Subkategorie LIKE @Like)", new { Like = $"%{searchAndPaging.Subkategorie}%" });
            }

            PagedList<InseratsKategorieView> pl = GetPagedAuto(searchAndPaging, select, "IK_Kategorie ASC");
            return pl;
        }

        private Sql GetViewBaseSelectSql()
        {
            string[] columns = new string[]
            {
                "*"
            };

            Sql select = Sql.Builder.Select(columns).From("InseratsKategorien");

            return select;
        }

    }
}

