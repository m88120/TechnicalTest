﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Collections;
using NPoco;

namespace Aushub.App.Depots
{
    public class GeoKoordinateDepot : PagingDepot<GeoKoordinate, GeoKoordinatenView, int>, IGeoKoordinateDepot
    {
        public GeoKoordinateDepot(INPocoDbContext dbContext, IAuthorizationManager authorizationManager)
            : base(dbContext, authorizationManager)
        {
        }

        public List<GeoKoordinate> GetByPlzOrt(string Postleitzahl, string Ort)
        {
            Sql select = Sql.Builder.Select("*").From("Geokoordinaten");

            if (!String.IsNullOrWhiteSpace(Postleitzahl))
            {
                select = select.Where("GE_Postleitzahl = @PLZ", new { PLZ = Postleitzahl });
            }

            if (!String.IsNullOrWhiteSpace(Ort))
            {
                select = select.Where("GE_Ort = @Ort", new { Ort = Ort });
            }

            return Database.Fetch<GeoKoordinate>(select);
        }

        public List<GeoKoordinate> SearchCity(string search, int maxItemsCount)
        {
            Sql sql = Sql.Builder.Select((maxItemsCount > 0 ? $"TOP {maxItemsCount} " : string.Empty) + "*", "'CH' AS CountryCode")
                                 .From("Geokoordinaten")
                                 .Where("GE_Postleitzahl LIKE @Search OR GE_Ort LIKE @Search", new { Search = "%" + search + "%" });

            return Database.Fetch<GeoKoordinate>(sql);
        }

        public PagedList<GeoKoordinatenView> GetGeoKoordinatenPaged(GeoKoordinatenSearchAndPagingParameters searchAndPaging)
        {
            Sql select = GetViewBaseSelectSql();

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Postleitzahl))
            {
                select = select.Where("GE_Postleitzahl LIKE @Like", new { Like = $"%{searchAndPaging.Postleitzahl}%" });
            }

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Ort))
            {
                select = select.Where("GE_Ort LIKE @Like", new { Like = $"%{searchAndPaging.Ort}%" });
            }

            return GetPagedAuto(searchAndPaging, select, "GE_Ort ASC, GE_Postleitzahl ASC");
        }

        private Sql GetViewBaseSelectSql()
        {
            string[] columns = new string[]
            {
                "*"
            };

            Sql select = Sql.Builder.Select(columns).From("Geokoordinaten");

            return select;
        }

    }
}

