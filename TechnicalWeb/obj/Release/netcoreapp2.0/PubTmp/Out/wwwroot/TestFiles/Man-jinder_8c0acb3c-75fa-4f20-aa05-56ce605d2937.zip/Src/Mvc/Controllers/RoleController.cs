﻿using Comitas.CAF.Core.Collections;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aushub.Shared;
using Aushub.Shared.Services;
using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.SearchAndPaging;
using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Comitas.CAF.Core.Logging;
using System.Data;
using System.Globalization;
using System.Web.UI;

namespace Aushub.Mvc.Controllers
{
    [AuthorizeRoles(Role.Sysadmin)]
    public class RoleController : BaseController
    {
        IRoleService roleService;
        ILogService logService;
        IMapper mapper;

        public RoleController(IRoleService roleservice, ILogService logservice, IMapper mapper)
        {
            this.roleService = roleservice;
            this.logService = logservice;
            this.mapper = mapper;
        }

        [AuthorizeRoles(Role.Sysadmin)]
        public virtual ActionResult Index(string id, [Bind(Prefix = "s")] RoleSearchAndPagingParameters parameters)
        {
            return View("Index", GetIndexViewModel(id, null, parameters));
            //return RedirectToAction("Index", "Home");
        }

        protected BaseIndexModel<RoleModel, RoleDetailModel, RoleSearchAndPagingParameters> GetIndexViewModel(string id, RoleDetailModel entityModel, RoleSearchAndPagingParameters parameters)
        {

            if (parameters == null)
                parameters = new RoleSearchAndPagingParameters();

            RoleDetailModel detailModel = GetDetailModel(id);

            // Query String mit GridView Parametern eigentlich nicht mehr notwendig!
            return new BaseIndexModel<RoleModel, RoleDetailModel, RoleSearchAndPagingParameters>()
            {
                PagedList = GetPagedEntites(parameters),
                Search = parameters,
                CurrentEntity = detailModel
            };
        }

        [AuthorizeRoles(Role.Sysadmin)]
        public PartialViewResult Load(string id)
        {
            ModelState.Clear(); // Damit ggf. neue Id übernommen wird

            RoleDetailModel model = GetDetailModel(id);

            return PartialView("RoleDetailPartial", model);
        }

        private RoleDetailModel GetDetailModel(string id)
        {
            if (id == null)
                return null;

            Role view = roleService.GetById(id);

            var model = view == null ? new RoleDetailModel() : mapper.Map<RoleDetailModel>(view);
            return model;
        }

        [AuthorizeRoles(Role.Sysadmin)]
        public ActionResult GetGrid(RoleSearchAndPagingParameters searchAndPaging)
        {
            return PartialView("Grid", GetPagedEntites(searchAndPaging));
        }

        private PagedList<RoleModel> GetPagedEntites(RoleSearchAndPagingParameters searchAndPaging)
        {
            var pagedEntities = roleService.GetRolePaged(searchAndPaging);

            return new PagedList<RoleModel>(mapper.Map<IEnumerable<RoleView>, IEnumerable<RoleModel>>(pagedEntities),
                                                         pagedEntities.PageIndex,
                                                         pagedEntities.PageSize,
                                                         pagedEntities.TotalCount);
        }

        [AuthorizeRoles(Role.Sysadmin)]
        [HttpPost]
        public PartialViewResult Save(RoleDetailModel model)
        {

            var saveResult = TrySave(model);

            if (saveResult.Status)
            {
                SetSuccessMessage("Die Rolle wurden gespeichert.");
                logService.Save($"Rolle '{model.Description}' wurden gespeichert", "Rollenverwaltung", UserId);
                return Load(saveResult.Id);
            }

            return PartialView("RoleDetailPartial", model);
        }

        [AuthorizeRoles(Role.Sysadmin)]
        [HttpPost]
        public PartialViewResult SaveNew(RoleDetailModel model)
        {
            return SaveNew<RoleDetailModel>(Save(model));
        }

        private (bool Status, string Id) TrySave(RoleDetailModel model)
        {
            if (!ModelState.IsValid)
            {
                return (false, null);
            }

            Role role = new Role();

            if (model.Id != null)
                role = roleService.GetById(model.Id);

            mapper.Map(model, role);

            return (ExecuteActionWithValidationErrorHandling(() => roleService.Save(role)), role.Id);
        }

    }
}