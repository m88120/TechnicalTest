﻿using Comitas.CAF.Core.Collections;
using AutoMapper;
using Aushub.Mvc.Code;
using Aushub.Mvc.Models;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Shared.Services;
using Aushub.Shared.SearchAndPaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Aushub.Mvc.Controllers
{
    public class AccountController : BaseController
    {
        IUserService userService;
        IMapper mapper;
        IRoleService roleService;
        IFirmaService firmenService;
        IListItemService listitemService;
        ILogService logService;
        IRegistrationService registrationService;

        public AccountController(IUserService userService, IMapper mapper, IRoleService roleservice, IFirmaService firmenservice,
                                 IListItemService listitemservice, ILogService logservice, IRegistrationService registrationservice)
        {
            this.userService = userService;
            this.mapper = mapper;
            this.roleService = roleservice;
            this.firmenService = firmenservice;
            this.listitemService = listitemservice;
            this.logService = logservice;
            this.registrationService = registrationservice;
        }

        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            LoginModel model = new LoginModel();
            model.ReturnUrl = returnUrl;

            return View("Login", model);
        }

        [AllowAnonymous]
        public ActionResult Logout()
        {
            if (!string.IsNullOrWhiteSpace(UserName))
                logService.Save($"Benutzer {UserName} hat sich abgemeldet", "Anmeldung", UserId);

            MvcApp.CAFSecurityManager.SignOut();
            Session.Abandon();

            return RedirectToRoute("Default", new { action = "Login", controller = "Account" });
        }

        [AllowAnonymous]
        [HttpPost]
        [MultibleButton(Name = "action", Argument = "Login")]
        public ActionResult Login(LoginModel model)
        {
            bool loginStatus = false;

            if (ModelState.IsValid)
            {
                loginStatus = MvcApp.CAFSecurityManager.SignIn(model.Email, model.Password, model.StayLoggedIn);
            }

            if (loginStatus)
            {
                logService.Save($"Benutzer {model.Email} hat sich angemeldet", "Anmeldung", userService.GetByEmail(model.Email).Id);
                if (!string.IsNullOrEmpty(model.ReturnUrl))
                {
                    return Redirect(model.ReturnUrl);
                }

                return RedirectToAction("IndexInit", "Search");

            }

            //TODO: besser lösen, bzw. eine ValidationException im Service werfen
            if (ModelState.IsValid)
            {
                ModelState.AddModelError("Email", "Sie konnten nicht angemeldet werden.");
                logService.Save($"Benutzer {model.Email} konnten nicht angemeldet werden", "Anmeldung", null);
            }

            return View("Login", model);
        }

        [AllowAnonymous]
        [HttpPost]
        [MultibleButton(Name = "action", Argument = "Cancel")]
        public ActionResult Cancel()
        {
            return RedirectToAction("Index", "Home");
        }

        [Authorize]
        [HttpGet]
        public ActionResult ChangePassword()
        {
            ViewBag.PasswordInfo = $"Zu Ihrer Sicherheit beträgt die minimale Passwortlänge { MvcApp.Config.MinimumPasswordLength} Zeichen.";

            return View(new ChangePasswordModel());
        }

        [Authorize]
        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordModel model)
        {
            var user = MvcApp.CAFSecurityManager.GetUser(UserName);
            ViewBag.PasswordInfo = $"Zu Ihrer Sicherheit beträgt die minimale Passwortlänge { MvcApp.Config.MinimumPasswordLength} Zeichen.";

            if (!user.CheckPassword(model.CurrentPassword))
            {
                model.Message = "Das angegebene Passwort ist ungültig.";
            }
            else if (model.NewPassword != model.NewPasswordRepeat)
            {
                model.Message = "Die Passwortwiederholung ist ungleich dem angegebenen Passwort.";
            }
            else if (model.NewPassword.Length < MvcApp.Config.MinimumPasswordLength)
            {
                model.Message = "Das Passwort ist kürzer als die erforderliche Minimallänge.";
            }
            else
            {
                user.HashAndAssignPassword(model.NewPassword);
                userService.Save(user as User);
                model.Message = "Das Passwort wurde erfolgreich geändert.";
                logService.Save($"Benutzer {user.Email} hat Kennwort geändert.", "Anmeldung", UserId);
            }

            return View(model);
        }

        [AllowAnonymous]
        public ActionResult ResetPassword(ResetPasswordModel model)
        {
            if (!String.IsNullOrEmpty(model.Email))
            {
                model.Postback = true;
                var user = MvcApp.CAFSecurityManager.GetUser(model.Email);
                var userDB = userService.GetByEmail(model.Email);

                if (user != null && userDB != null && userDB.IsActive)
                {
                    string url = String.Format("{0}/Account/PasswordResetToken/?token={1}", Request.Url.GetLeftPart(UriPartial.Authority), "{{Token}}");
                    MvcApp.CAFSecurityManager.SendPasswordResetLink(user, url);
                    model.Message = "Eine Mail zum Zurücksetzen des Passworts wurde an die Mailadresse des angegebenen Benutzers gesendet.";
                    logService.Save($"Benutzer {model.Email} hat Kennwort Rücksetzung beantragt", "Anmeldung", userService.GetByEmail(model.Email).Id);
                }
                else
                {
                    model.Message = "Die eingegebene Mailadresse ist nicht für das System freigeschaltet.";
                }
            }
            else
            {
                model.Message = "Bitte geben Sie eine Mailadresse an.";
            }


            return View("ResetPassword", model);
        }

        [AllowAnonymous]
        [HttpGet]
        public ActionResult PasswordResetToken(string token, string type)
        {
            SetupResetText(type);

            var user = MvcApp.CAFSecurityManager.GetUserByPasswordResetToken(token);
            ChangeResetPasswordModel model = new ChangeResetPasswordModel();

            if (user == null || (user != null && user.IsPasswordResetTokenValid(token)))
            {
                model.Message = "Der angegebene Passwort Reset Token ist falsch oder abgelaufen.";
                model.IsValid = false;
            }
            else
            {
                model.Token = token;
                model.IsValid = true;
            }

            return View("PasswordResetToken", model);
        }

        [AllowAnonymous]
        [HttpPost]
        public ActionResult PasswordResetToken(ChangeResetPasswordModel model)
        {
            SetupResetText(model.Type);

            var user = MvcApp.CAFSecurityManager.GetUserByPasswordResetToken(model.Token);

            if (user == null || (user != null && user.IsPasswordResetTokenValid(model.Token)))
            {
                model.Message = "Der angegebene Passwort Reset Token ist falsch oder abgelaufen.";
                model.IsValid = false;
            }
            else if (model.NewPassword == null || model.NewPassword.Length < MvcApp.Config.MinimumPasswordLength)
            {
                model.Message = "Das Passwort ist kürzer als die erforderliche Minimallänge.";
                model.IsValid = false;
            }
            else if (model.NewPassword == model.NewPasswordRepeat)
            {
                MvcApp.CAFSecurityManager.FinishPasswordResetRequest(user, model.NewPassword);

                model.Message = "Das Passwort wurde erfolgreich gesetzt. Sie können es jetzt für die Anmeldung verwenden.";
                model.Success = true;
                logService.Save($"Benutzer {user.Email} hat Kennwort erfolgreich gesetzt.", "Anmeldung", userService.GetByEmail(user.Email).Id);
            }
            else
            {
                model.Message = "Die angegebenen Passwörter sind nicht gleich.";
                model.IsValid = false;
            }

            return View("PasswordResetToken", model);
        }

        private void SetupResetText(string type)
        {
            ViewBag.Title = "Passwort setzen";
            ViewBag.PageTitle = "Passwort setzen";
            ViewBag.SubmitLabel = "Passwort setzen";
            ViewBag.PasswordInfo = $"Zu Ihrer Sicherheit beträgt die minimale Passwortlänge { MvcApp.Config.MinimumPasswordLength} Zeichen.";

            if (type != null && type.Equals("invite", StringComparison.OrdinalIgnoreCase))
            {
                ViewBag.Title = "Passwort wählen";
                ViewBag.PageTitle = "Passwort wählen";
                ViewBag.SubmitLabel = "Passwort wählen";
            }
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public virtual ActionResult Index(int? id, [Bind(Prefix = "s")] UserSearchAndPagingParameters parameters)
        {
            return View("Index", GetIndexViewModel(id, null, parameters));
        }

        protected BaseIndexModel<UserModel, UserDetailModel, UserSearchAndPagingParameters> GetIndexViewModel(int? id, UserDetailModel entityModel, UserSearchAndPagingParameters parameters)
        {

            if (parameters == null)
                parameters = new UserSearchAndPagingParameters();

            InitializeSearchListboxes(parameters);

            UserDetailModel detailModel = GetDetailModel(id);
            AddDataToCombosOnGetIndexModel();

            // Query String mit GridView Parametern eigentlich nicht mehr notwendig!
            return new BaseIndexModel<UserModel, UserDetailModel, UserSearchAndPagingParameters>()
            {
                PagedList = GetPagedEntites(parameters),
                Search = parameters,
                CurrentEntity = detailModel
            };
        }

        [AuthorizeRoles(Role.User, Role.Admin, Role.Sysadmin)]
        public PartialViewResult Load(int id)
        {
            ModelState.Clear(); // Damit ggf. neue Id übernommen wird

            UserDetailModel model = GetDetailModel(id);
            AddDataToCombosOnGetIndexModel();

            return PartialView("UserDetailPartial", model);
        }

        private UserDetailModel GetDetailModel(int? id)
        {
            if (!id.HasValue)
                return null;

            User view = userService.GetById(id.Value);

            var model = view == null ? new UserDetailModel() : mapper.Map<UserDetailModel>(view);
            if (view != null)
            {
                User usr = view.DeactivatedUserId != null ? userService.GetById((int)view.DeactivatedUserId) : null;
                model.DeactivatedUserDisplayName = usr != null ? usr.DisplayName : string.Empty;
                usr = userService.GetById((int)view.CreateUserId);
                model.CreateUserDisplayName = usr != null ? usr.DisplayName : string.Empty;
                usr = view.UpdateUserId != null ? userService.GetById((int)view.UpdateUserId) : null;
                model.UpdateUserDisplayName = usr != null ? usr.DisplayName : string.Empty;
                Firma firma = view.FIId != null ? firmenService.GetById((int)view.FIId) : null;
                model.Firmenname = firma != null ? firma.Firmenname : string.Empty;
                model.Userstatus = listitemService.GetById(view.LI_UserstatusId).Bezeichnung;
            }

            return model;
        }

        private void AddDataToCombosOnGetIndexModel()
        {
            bool selCrit = User.IsInRole(Role.Sysadmin);

            List<Role> rolelist = roleService.GetAllRoles(selCrit);
            rolelist.Insert(0, new Role() { Id = "", Description = string.Empty });
            ViewBag.Rollen = rolelist;

            List<ListItem> salutationlist = listitemService.GetByListGroup(ListItem.Salutation);
            salutationlist.Insert(0, new ListItem() { Id = 0, Bezeichnung = string.Empty });
            ViewBag.SalutationListItems = salutationlist;

            List<Firma> firmenlist = firmenService.GetAll(selCrit);
            firmenlist.Insert(0, new Firma() { Id = 0, Firmenname = string.Empty, IsSystem = false });
            ViewBag.Firmen = firmenlist;
        }

        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public ActionResult GetGrid(UserSearchAndPagingParameters searchAndPaging)
        {
            return PartialView("Grid", GetPagedEntites(searchAndPaging));
        }

        private PagedList<UserModel> GetPagedEntites(UserSearchAndPagingParameters searchAndPaging)
        {
            bool selCrit = User.IsInRole(Role.Sysadmin);

            var pagedEntities = userService.GetUserPaged(searchAndPaging, selCrit);

            return new PagedList<UserModel>(mapper.Map<IEnumerable<UserView>,IEnumerable<UserModel>>(pagedEntities),
                                                         pagedEntities.PageIndex,
                                                         pagedEntities.PageSize,
                                                         pagedEntities.TotalCount);
        }

        private void InitializeSearchListboxes(UserSearchAndPagingParameters parameters)
        {
            bool selCrit = User.IsInRole(Role.Sysadmin);

            List<Role> rolelist = roleService.GetAllRoles(selCrit);
            rolelist.Insert(0, new Role() { Id = "", Description = string.Empty });
            parameters.Rollen = rolelist;

            List<Firma> firmenlist = firmenService.GetAll(selCrit);
            firmenlist.Insert(0, new Firma() { Id = 0, Firmenname = string.Empty, IsSystem = false });
            parameters.Firmen = firmenlist;

            List<ListItem> userstatilist = listitemService.GetByListGroup(ListItem.Userstatus);
            userstatilist.Insert(0, new ListItem() { Id = 0, Bezeichnung = string.Empty });
            parameters.Userstatus = userstatilist;
        }

        [HttpPost]
        [AuthorizeRoles(Role.User, Role.Admin, Role.Sysadmin)]
        public PartialViewResult Save(UserDetailModel model)
        {
            bool MustSendMailToRegistrant = false;

            if (model.IsTransient)
                MustSendMailToRegistrant = true;

            var saveResult = TrySave(model);

            if (saveResult.Status)
            {
                SetSuccessMessage("Ihre Daten wurden erfolgreich gespeichert.");

                if (MustSendMailToRegistrant)
                {
                    Firma firma = firmenService.GetById((int)model.FIId);
                    registrationService.SendMailToRegistrant(new Shared.Entities.User()
                                                             {
                                                                Id = model.Id, Email = model.Email, Firstname = model.Firstname, Lastname = model.Lastname
                                                             },
                                                             new Registration()
                                                             {
                                                                Id = firma.Id, Firmenname = firma.Firmenname, Postleitzahl = firma.Postleitzahl, Ort = firma.Ort, Strasse = firma.Strasse
                                                             },
                                                             string.Format("{0}://{1}{2}", Request.Url.Scheme, Request.Url.Authority, Url.Content("~"))
                                                            );
                    SetSuccessMessage("Der Benutzer wurde gespeichert und per E-Mail über die Benutzeranlage benachrichtigt.");
                    logService.Save($"Benutzer {model.Email} wurde über die Benutzerverwaltung registriert und per E-Mail verständigt", "Benutzerverwaltung", UserId);
                }
                else
                {
                    logService.Save($"Benutzer {model.Email} wurde gespeichert", "Benutzerverwaltung", UserId);
                }

                return Load(saveResult.Id);
            }

            AddDataToCombosOnGetIndexModel();
            model.Userstatus = listitemService.GetById(model.LI_UserstatusId).Bezeichnung;
            User usr = model.DeactivatedUserId != null ? userService.GetById((int)model.DeactivatedUserId) : null;
            model.DeactivatedUserDisplayName = usr != null ? usr.DisplayName : string.Empty;

            return PartialView("UserDetailPartial", model);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult SaveNew(UserDetailModel model)
        {
            return SaveNew<UserDetailModel>(Save(model));
        }

        private (bool Status, int Id) TrySave(UserDetailModel model)
        {
            if (!ModelState.IsValid)
            {
                return (false, 0);
            }

            User user = new User();

            if (model.Id > 0)
                user = userService.GetById(model.Id);

            user.LI_SalutationId = model.LI_SalutationId;
            user.Email = model.Email;
            user.Firstname = model.Firstname;
            user.Lastname = model.Lastname;
            user.FIId = model.FIId;
            user.RoleKey = model.RoleKey;
            user.HasAcceptedAGBs = model.HasAcceptedAGBs;
            user.MobilNumber = model.MobilNumber;
            user.Telefon = model.Telefon;
            user.WillSammelmailErhalten = model.WillSammelmailErhalten;

            return (ExecuteActionWithValidationErrorHandling(() => userService.Save(user)), user.Id);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult Deactivate(UserDetailModel model)
        {
            var saveResult = TrySave(model);
            if (saveResult.Status)
            {
                if (ExecuteActionWithValidationErrorHandling(() => userService.DeactivateUser(model.Id)))
                {
                    SetSuccessMessage("Der Benutzer wurde deaktiviert.");
                    logService.Save($"Benutzer {model.Email} wurde deaktiviert", "Benutzerverwaltung", UserId);

                    return Load(model.Id);
                }
            }

            AddDataToCombosOnGetIndexModel();

            return PartialView("UserDetailPartial", model);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult Activate(UserDetailModel model)
        {
            var saveResult = TrySave(model);
            if (saveResult.Status)
            {
                if (ExecuteActionWithValidationErrorHandling(() => userService.ActivateUser(model.Id)))
                {
                    var user = MvcApp.CAFSecurityManager.GetUser(model.Email);
                    string url = String.Format("{0}/Account/PasswordResetToken/?token={1}", Request.Url.GetLeftPart(UriPartial.Authority), "{{Token}}");
                    userService.SendPasswordSetupLink(user, url);
                    SetSuccessMessage("Der Benutzer wurde aktiviert und eine E-Mail wurde an ihn gesendet.");
                    logService.Save($"Benutzer {model.Email} wurde aktiviert und es wurde eine E-Mail zur Kennwort-Rücksetzung an ihn versendet", "Benutzerverwaltung", UserId);

                    return Load(model.Id);
                }
            }

            AddDataToCombosOnGetIndexModel();

            return PartialView("UserDetailPartial", model);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Admin, Role.Sysadmin)]
        public PartialViewResult Refuse(UserDetailModel model)
        {
            var saveResult = TrySave(model);
            if (saveResult.Status)
            {
                if (ExecuteActionWithValidationErrorHandling(() => userService.RefuseUser(model.Id)))
                {
                    SetSuccessMessage("Der Benutzer wurde abgelehnt.");
                    logService.Save($"Benutzer {model.Email} wurde abgewiesen", "Benutzerverwaltung", UserId);

                    return Load(model.Id);
                }
            }

            AddDataToCombosOnGetIndexModel();

            return PartialView("UserDetailPartial", model);
        }

    }
}