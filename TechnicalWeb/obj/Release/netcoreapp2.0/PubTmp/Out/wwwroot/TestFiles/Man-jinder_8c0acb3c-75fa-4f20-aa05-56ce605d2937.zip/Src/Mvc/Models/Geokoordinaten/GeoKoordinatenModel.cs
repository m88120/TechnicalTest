﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Aushub.Mvc.Models.Base;
using System.ComponentModel.DataAnnotations;

namespace Aushub.Mvc.Models
{
    public class GeoKoordinatenModel : BaseEntityModel
    {
        public string Postleitzahl { get; set; }
        public string Ort { get; set; }
        public float Longitude { get; set; }
        public float Latitude { get; set; }
    }
}