﻿using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Aushub.Shared.Services;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Validators
{
    public class ListItemModelValidator : AbstractValidator<ListItemDetailModel>
    {
        IListItemService listItemService;

        public ListItemModelValidator(IListItemService listitemservice)
        {
            this.listItemService = listitemservice;

            RuleFor(x => x.Gruppe).NotEmpty().WithMessage("Gruppe darf nicht leer sein");
            RuleFor(x => x.Reihenfolge).NotEmpty().WithMessage("Reihenfolge darf nicht leer sein")
                                       .Must(NotBeADuplicate).WithMessage("Reihenfolge ist bereits vorhanden");
            RuleFor(x => x.Bezeichnung).NotEmpty().WithMessage("Bezeichnung darf nicht leer sein");
        }

        private bool NotBeADuplicate(ListItemDetailModel model, int newValue)
        {
            var litem = listItemService.GetByListGroupAndPosition(model.Gruppe, model.Reihenfolge);

            return (litem == null || (litem != null && litem.Gruppe == model.Gruppe && litem.Reihenfolge == model.Reihenfolge && litem.Id == model.Id));
        }
    }
}