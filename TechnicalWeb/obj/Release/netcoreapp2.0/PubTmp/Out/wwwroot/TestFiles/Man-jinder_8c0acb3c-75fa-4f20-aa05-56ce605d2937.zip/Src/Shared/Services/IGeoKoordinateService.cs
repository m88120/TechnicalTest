﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using Aushub.Shared.ViewModels;

namespace Aushub.Shared.Services
{
    public interface IGeoKoordinateService : IEntityIdService<GeoKoordinate, int>
    {
        List<GeoKoordinate> GetByPlzOrt(string Postleitzahl, string Ort);
        List<GeoKoordinate> SearchCity(string search);
        PagedList<GeoKoordinatenView> GetGeoKoordinatenPaged(GeoKoordinatenSearchAndPagingParameters searchAndPaging);
        void Save(GeoKoordinate entity);
        void Delete(int id);
    }
}
