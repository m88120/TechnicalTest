﻿using Aushub.Shared.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Aushub.Mvc.Models
{
    public class UserModel
    {
        public int Id { get; set; }
        public int? FIId { get; set; }

        [Display(Name = "Anrede")]
        public int LI_SalutationId { get; set; }
        public List<ListItem> SalutationListItems { get; set; }
        public IEnumerable<SelectListItem> DropdownSalutation => new SelectList(SalutationListItems, "Id", "Bezeichnung");

        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Email { get; set; }

        public string RoleKey { get; set; }
        public List<Role> Roles { get; set; }
        public IEnumerable<SelectListItem> DropdownRoles => new SelectList(Roles, "Id", "Name");

        public DateTime? LastLogin { get; set; }
        public DateTime? DeactivatedDate { get; set; }
        public string DeactivatedUserDisplayName { get; set; }
        public DateTime? PasswordResetRequestDate { get; set; }
        bool IsSystemUser { get; set; }

        public string Telefon { get; set; }
        public string MobileNumber { get; set; }

        bool HasAcceptedAGBs { get; set; }

        [Display(Name = "Benutzerstatus")]
        public int LI_UserstatusId { get; set; }
        public List<ListItem> UserstatusListItems { get; set; }
        public IEnumerable<SelectListItem> DropdownUserstatus => new SelectList(UserstatusListItems, "Id", "Bezeichnung");

    }
}

