using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Collections;
using NPoco;

namespace Aushub.App.Depots
{
    public class FirmaDepot : PagingDepot<Firma, FirmenView, int>, IFirmaDepot
    {
        public FirmaDepot(INPocoDbContext dbContext, IAuthorizationManager authorizationManager)
            : base(dbContext, authorizationManager)
        {
        }

        public List<Firma> GetAll(bool bwithSystem)
        {
            if(bwithSystem)
                return Database.Query<Firma>(GetBaseSelectSql()).ToList();
            else
                return Database.Query<Firma>(GetBaseSelectSql()).Where(x => x.IsSystem == false).ToList();
        }

        public string GetListOfCompaniesForHome()
        {
            List<Firma> Firmenliste = Database.Query<Firma>(GetBaseSelectSql()).Where(x => x.AufHomeAnzeigen == true).OrderBy(y => y.Firmenname).ToList();
            return string.Join(", ", Firmenliste.Select(x => x.Firmenname).ToArray());
        }

        public Firma GetByUID(string uid)
        {
            Sql select = Sql.Builder.Select("*").From("Firmen");

            if (!string.IsNullOrWhiteSpace(uid))
            {
                select = select.Where("UPPER(LTRIM(RTRIM(REPLACE(ISNULL(FI_UID, ''), ' ', '')))) = @uid", new { uid = uid.Replace(" ", "").Trim().ToUpper() });
                return Database.Fetch<Firma>(select).FirstOrDefault();
            }
            return null;
        }

        public PagedList<FirmenView> GetFirmenPaged(FirmenSearchAndPagingParameters searchAndPaging, bool selCrit)
        {
            Sql select = GetViewBaseSelectSql();

            if (!selCrit)
            {
                select = select.Where("FI_IsSystem = 0");
            }

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Firmenname))
            {
                select = select.Where("FI_Firmenname LIKE @Like", new { Like = $"%{searchAndPaging.Firmenname}%" });
            }

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Postleitzahl))
            {
                select = select.Where("FI_Postleitzahl LIKE @Like", new { Like = $"%{searchAndPaging.Postleitzahl}%" });
            }

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Ort))
            {
                select = select.Where("FI_Ort LIKE @Like", new { Like = $"%{searchAndPaging.Ort}%" });
            }

            if (!String.IsNullOrWhiteSpace(searchAndPaging.UID))
            {
                select = select.Where("FI_UID LIKE @Like", new { Like = $"%{searchAndPaging.UID}%" });
            }

            if (searchAndPaging.AufHomeAngezeigt && !searchAndPaging.NichtAufHomeAngezeigt)
            {
                select = select.Where("FI_AufHomeAnzeigen = 1", new { Like = $"%{searchAndPaging.UID}%" });
            }
            else if (!searchAndPaging.AufHomeAngezeigt && searchAndPaging.NichtAufHomeAngezeigt)
            {
                select = select.Where("FI_AufHomeAnzeigen = 0", new { Like = $"%{searchAndPaging.UID}%" });
            }

            return GetPagedAuto(searchAndPaging, select, "FI_Firmenname ASC, FI_Id ASC");
        }

        private Sql GetViewBaseSelectSql()
        {
            string[] columns = new string[]
            {
                "*"
            };

            Sql select = Sql.Builder.Select(columns).From("Firmen");

            return select;
        }
    }
}

