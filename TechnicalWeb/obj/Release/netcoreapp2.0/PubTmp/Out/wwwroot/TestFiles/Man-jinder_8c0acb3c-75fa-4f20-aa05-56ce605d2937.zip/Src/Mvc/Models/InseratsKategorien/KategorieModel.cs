﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.Entities;

using System.ComponentModel.DataAnnotations;

namespace Aushub.Mvc.Models
{
    public class KategorieModel : BaseEntityModel
    {
        public string Kategorie { get; set; }
        public List<SubkategorieModel> Subkategorien { get; set; }
        public string SubkategorienString => string.Join(", ", Subkategorien.Select(x => x.Subkategorie).ToArray());

        public KategorieModel()
        {
            Subkategorien = new List<SubkategorieModel>();
        }
    }
}