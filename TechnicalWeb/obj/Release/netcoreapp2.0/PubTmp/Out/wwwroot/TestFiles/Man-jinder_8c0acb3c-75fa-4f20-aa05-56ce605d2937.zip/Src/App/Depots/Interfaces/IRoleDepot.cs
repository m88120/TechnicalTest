﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Aushub.App.Depots
{
    public interface IRoleDepot : IDepot<Role, string>
    {
        List<Role> GetAllRoles(bool withSysadmin);
        Role GetRoleById(string id);
        List<Role> GetRolesForUser(int userId);
        PagedList<RoleView> GetRolePaged(RoleSearchAndPagingParameters searchAndPaging);
    }
}
