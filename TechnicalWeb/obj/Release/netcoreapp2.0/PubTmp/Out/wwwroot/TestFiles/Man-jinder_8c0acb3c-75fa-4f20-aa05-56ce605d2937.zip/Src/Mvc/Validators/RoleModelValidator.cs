﻿using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Aushub.Shared.Services;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Validators
{
    public class RoleModelValidator : AbstractValidator<RoleDetailModel>
    {
        IRoleService roleService;

        public RoleModelValidator(IRoleService roleservice)
        {
            this.roleService = roleservice;

            RuleFor(x => x.Id).NotEmpty().WithMessage("Id darf nicht leer sein")
                                       .Must(NotBeADuplicate).WithMessage("Rolle ist bereits vorhanden");
            RuleFor(x => x.Description).NotEmpty().WithMessage("Bezeichnung darf nicht leer sein");
        }

        private bool NotBeADuplicate(RoleDetailModel model, string newValue)
        {
            var role = roleService.GetById(model.Id);

            return (role == null || (role != null && role.Id == model.Id));
        }
    }
}