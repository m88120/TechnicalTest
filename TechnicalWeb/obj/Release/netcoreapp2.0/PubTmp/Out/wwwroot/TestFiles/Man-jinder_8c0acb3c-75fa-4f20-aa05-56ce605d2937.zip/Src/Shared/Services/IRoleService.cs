﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using Aushub.Shared.ViewModels;


namespace Aushub.Shared.Services
{
    public interface IRoleService : IEntityIdService<Role, string>
    {
        List<Role> GetAllRoles(bool withSysadmin);
        Role GetRoleById(string id);
        PagedList<RoleView> GetRolePaged(RoleSearchAndPagingParameters searchAndPaging);
        void Save(Role entity);
    }
}
