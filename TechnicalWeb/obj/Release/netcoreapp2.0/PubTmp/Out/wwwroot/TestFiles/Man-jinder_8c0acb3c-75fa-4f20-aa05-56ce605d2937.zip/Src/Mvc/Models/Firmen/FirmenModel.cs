﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Aushub.Mvc.Models.Base;
using System.ComponentModel.DataAnnotations;

namespace Aushub.Mvc.Models
{
    public class FirmenModel : BaseEntityModel
    {
        public string Firmenname { get; set; }
        public string UID { get; set; }
        public string Strasse { get; set; }
        public string Postleitzahl { get; set; }
        public string Ort { get; set; }
        public bool IsSystem { get; set; }
        public bool AufHomeAnzeigen { get; set; }

        public  FirmenModel()
        {
            IsSystem = false;
            AufHomeAnzeigen = false;
        }
    }
}