using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Collections;
using NPoco;

namespace Aushub.App.Depots
{
    public class ListItemDepot : PagingDepot<ListItem, ListItemView, int>, IListItemDepot
    {
        public ListItemDepot(INPocoDbContext dbContext, IAuthorizationManager authorizationManager)
            : base(dbContext, authorizationManager)
        {
        }

        public List<ListItem> GetByListGroup(string group)
        {
            return Database.Query<ListItem>(GetBaseSelectSql()).Where(x => x.Gruppe == group).OrderBy(y => y.Reihenfolge).ToList();
        }

        public ListItem GetByListGroupAndPosition(string group, int position)
        {
            return Database.Query<ListItem>(GetBaseSelectSql()).Where(x => x.Gruppe == group && x.Reihenfolge == position).FirstOrDefault();
        }

        public List<ListItem> GetAll()
        {
            return Database.Query<ListItem>().ToList();
        }

        public PagedList<ListItemView> GetListItemPaged(ListItemSearchAndPagingParameters searchAndPaging)
        {
            Sql select = GetViewBaseSelectSql();

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Gruppe))
            {
                select = select.Where("LI_Gruppe LIKE @Like", new { Like = $"%{searchAndPaging.Gruppe}%" });
            }

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Bezeichnung))
            {
                select = select.Where("LI_Bezeichnung LIKE @Like", new { Like = $"%{searchAndPaging.Bezeichnung}%" });
            }

            return GetPagedAuto(searchAndPaging, select, "LI_Gruppe ASC, LI_Reihenfolge ASC");
        }

        private Sql GetViewBaseSelectSql()
        {
            string[] columns = new string[]
            {
                "*"
            };

            Sql select = Sql.Builder.Select(columns).From("ListItems");

            return select;
        }

        public List<string> GetAllGroups()
        {
            Sql select = Sql.Builder.Select("DISTINCT LI_Gruppe").From("ListItems");
            List<ListItem> litems = Database.Fetch<ListItem>(select).ToList();
            string[] gruppen = litems.Select(x => x.Gruppe).ToArray();
            return gruppen.OfType<string>().ToList();
        }

    }
}

