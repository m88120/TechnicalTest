﻿using Aushub.App.Depots;
using Aushub.Shared.Entities;
using Aushub.Shared.Services;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Collections;
using FluentValidation;

namespace Aushub.App.Services
{
    public class RoleService : NPocoBaseService<IRoleDepot, Role, string>, IRoleService
    {
        public RoleService(IRoleDepot baseDepot, IValidatorFactory validatorFactory, IMailService mailService, IAuthorizationManager authorizationManager)
            : base(baseDepot, validatorFactory, mailService, authorizationManager)
        {
        }

        public List<Role> GetAllRoles(bool withSysadmin)
        {
            return Depot.GetAllRoles(withSysadmin);
        }

        public Role GetRoleById(string id)
        {
            return Depot.GetRoleById(id);
        }

        public PagedList<RoleView> GetRolePaged(RoleSearchAndPagingParameters searchAndPaging)
        {
            return Depot.GetRolePaged(searchAndPaging);
        }

        public void Save(Role entity)
        {
            Depot.Save(entity);
        }

    }
}
