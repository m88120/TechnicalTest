﻿using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.SearchAndPaging
{
    public class MyAccountPagingParameters : SearchAndPagingParameters
    {

        public int FiId { get; set; }
        public bool ShowMyAdsOnly { get; set; }

        public MyAccountPagingParameters() : base()
        {
            PageSize = 5;
        }

    }
}
