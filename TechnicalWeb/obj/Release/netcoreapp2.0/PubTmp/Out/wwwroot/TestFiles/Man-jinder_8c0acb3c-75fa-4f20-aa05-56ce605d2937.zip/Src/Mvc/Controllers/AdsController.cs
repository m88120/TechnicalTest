﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aushub.Shared;
using Aushub.Shared.Services;
using Aushub.Shared.Entities;
using Aushub.Shared.Enums;
using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Comitas.CAF.Core.Logging;
using System.Data;
using System.Globalization;
using FluentValidation;
using System.Threading.Tasks;
using System.IO;

namespace Aushub.Mvc.Controllers
{
    [Authorize]
    public class AdsController : BaseController
    {
        IFirmaService firmenService;
        IInseratService inserateService;
        IInseratsKategorieService inseratskategorienService;
        IInseratsSubkategorieService inseratssubkategorienService;
        IListItemService listitemService;
        IUserService userService;
        IRoleService roleService;
        IGeoKoordinateService geoKoordService;
        ILogService logService;
        IMapper mapper;
        Config config;

        public AdsController(IFirmaService firmenservice, IInseratService inserateservice, IInseratsKategorieService inseratskategorienservice,
                             IInseratsSubkategorieService inseratssubkategorienservice, IListItemService listitemservice, IUserService userservice,
                             IRoleService roleservice, IMapper mapper, IGeoKoordinateService geoservice, ILogService logservice, Config config)
        {
            this.firmenService = firmenservice;
            this.inserateService = inserateservice;
            this.inseratskategorienService = inseratskategorienservice;
            this.inseratssubkategorienService = inseratssubkategorienservice;
            this.listitemService = listitemservice;
            this.userService = userservice;
            this.roleService = roleservice;
            this.geoKoordService = geoservice;
            this.logService = logservice;
            this.mapper = mapper;
            this.config = config;
        }

        // GET: Ads
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult CreateAd()
        {
            if (UserId == null)
            {
                Logger.Error("Keine UserId vorhanden!");
                return View();
            }
            User user = userService.GetById((int)UserId);
            AdModel model = new AdModel();
            InitializeModel(model, user);

            return View(model);
        }


        private void InitializeModel(AdModel model, User user)
        {
            //Initialize User dependent fields
            model.FIId = user.FIId;
            model.US_KontaktId = user.Id;

            model.Mailadresse = user.Email;
            model.Telefon = user.Telefon;
            model.Mobilnummer = user.MobilNumber;
            if (!string.IsNullOrWhiteSpace(model.Mobilnummer))
                model.MobilnummerAnzeigen = true;
            else if (!string.IsNullOrWhiteSpace(model.Telefon))
                model.TelefonAnzeigen = true;
            else if (!string.IsNullOrWhiteSpace(model.Telefon))
                model.MailadresseAnzeigen = true;

            model.CreateUserId = user.Id;
            model.CreateUserDisplayName = user.DisplayName;
            model.VerkaufId = listitemService.GetByListGroupAndPosition("Inseratstyp", (int)Inseratstyp.Verkauf).Id;
            model.AnkaufId = listitemService.GetByListGroupAndPosition("Inseratstyp", (int)Inseratstyp.Ankauf).Id;
            model.BieteTransportId = listitemService.GetByListGroupAndPosition("Inseratstyp", (int)Inseratstyp.BieteTransport).Id;
            model.BenoetigeTransportId = listitemService.GetByListGroupAndPosition("Inseratstyp", (int)Inseratstyp.BenoetigeTransport).Id;
            model.LI_InseratstypId = model.VerkaufId;
            model.IstVerfuegbarAb = Verfuegbarkeit.Sofort;
            model.IstVerfuegbarBis = Verfuegbarkeit.Offen;
            model.Zahlungsbedingung = Zahlungsart.Verhandelbar;

            //Initialize all comboboxes
            PrepareListFields(model);
        }

        private void PrepareListFields(AdModel model)
        {
            model.Kategorien = inseratskategorienService.GetAll(false);
            model.Kategorien.Insert(0, new InseratsKategorie() { Id = 0, Kategorie = "Kategorie ..." });
            model.Subkategorien = new List<InseratsSubkategorie>();
            model.Subkategorien.Clear();
            model.Subkategorien.Insert(0, new InseratsSubkategorie() { IKId=0, Subkategorie = "Subkategorie ..." });
            model.InseratstypListItems = listitemService.GetByListGroup(ListItem.Inseratstyp);
            model.ContactsInCompany = userService.GetByFirmenId(model.FIId, true);
            model.InseratstatusListItems = listitemService.GetByListGroup(ListItem.Inseratstatus);
            model.InseratTeilenAufListItems = listitemService.GetByListGroup(ListItem.InseratTeilenAuf);
            model.MengeneinheitListItems = listitemService.GetByListGroup(ListItem.Mengeneinheit);
            model.VerkaufId = listitemService.GetByListGroupAndPosition("Inseratstyp", (int)Inseratstyp.Verkauf).Id;
            model.AnkaufId = listitemService.GetByListGroupAndPosition("Inseratstyp", (int)Inseratstyp.Ankauf).Id;
            model.BieteTransportId = listitemService.GetByListGroupAndPosition("Inseratstyp", (int)Inseratstyp.BieteTransport).Id;
            model.BenoetigeTransportId = listitemService.GetByListGroupAndPosition("Inseratstyp", (int)Inseratstyp.BenoetigeTransport).Id;
        }


        [HttpPost]
        [MultibleButton(Name = "action", Argument = "Save")]
        public ActionResult Save(AdModel model)
        {
            Inserat isrt = model.Id != 0 ? inserateService.GetById(model.Id) : new Inserat();
            string uploadfilepath = config.UploadDirectory;

            if (ModelState.IsValid)
            {
                try
                {
                    mapper.Map(model, isrt);

                    List<GeoKoordinate> geolist = geoKoordService.GetByPlzOrt(model.Postleitzahl, model.Ort);
                    if (geolist != null && geolist.Count > 0)
                    {
                        isrt.Latitude = geolist[0].Latitude;
                        isrt.Longitude = geolist[0].Longitude;
                    }

                    if (model.Id == 0)
                    {
                        isrt.LI_InseratstatusId = listitemService.GetByListGroupAndPosition("Inseratstatus", 1).Id;
                        isrt.LI_InseratTeilenAufId = listitemService.GetByListGroupAndPosition("InseratTeilenAuf", 1).Id;
                    }

                    inserateService.Save(isrt);
                    mapper.Map(isrt, model);
                    logService.Save($"Inserat Nr. {isrt.Id} wurde vom User {userService.GetById(isrt.CreateUserId).DisplayName} neu angelegt.", "Inserat erstellen", isrt.CreateUserId);

                    SendMailToCreator(model);
                }
                catch (Exception ex)
                {
                    Logger.Error(ex);
                    PrepareListFields(model);
                    return View("CreateAd", model);
                }
            }
            else
            {
                PrepareListFields(model);
                return View("CreateAd", model);
            }

            return RedirectToAction("IndexInit", "Search");
        }

        [HttpPost]
        [MultibleButton(Name = "action", Argument = "Cancel")]
        public ActionResult Cancel()
        {
            return RedirectToAction("Index", "Home");
        }

        public ActionResult Detail(int id)
        {
            AdModel model = new AdModel();

            User user = userService.GetById(UserId.Value);
            InitializeModel(model, user);

            Inserat isrt = inserateService.GetById(id);
            mapper.Map(isrt, model);
            model.Kategorie = inseratskategorienService.GetById(model.IKId).Kategorie;
            model.Subkategorie = inseratssubkategorienService.GetById(model.ISId).Subkategorie;

            User kontaktUser = userService.GetById(model.US_KontaktId);
            model.Kontakt = kontaktUser.DisplayName;
            if (model.TelefonAnzeigen)
            {
                model.Telefon = $"Telefon: {kontaktUser.Telefon}";
            }
            if (model.MobilnummerAnzeigen)
            {
                model.Mobilnummer = $"Mobil: {kontaktUser.MobilNumber}";
            }
            if (model.MailadresseAnzeigen)
            {
                model.Mailadresse = $"EMail: {kontaktUser.Email}";
            }

            return View(model);
        }

        [HttpGet]
        public ActionResult ToSearch()
        {
            return RedirectToAction("Index", "Search");
        }

        public JsonResult GetKategorien()
        {
            var kategorienList = inseratskategorienService.GetAll(false);
            kategorienList.Insert(0, new InseratsKategorie() { Id = 0, Kategorie = "Kategorie ..." });
            return Json(kategorienList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetSubkategorien(int IKId)
        {
            var subkategorienList = inseratssubkategorienService.GetByKategorieId(IKId);
            subkategorienList.Insert(0, new InseratsSubkategorie() { IKId = 0, Id = 0, Subkategorie = "Subkategorie ..." });
            return Json(subkategorienList, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetKontaktinfos(int KontaktId)
        {
            var user = userService.GetById(KontaktId);
            Kontaktinfos ki = new Kontaktinfos { Telefon = user.Telefon, Mobilnummer = user.MobilNumber, Mailadresse = user.Email };
            return Json(ki, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Upload(HttpPostedFileBase file, int id)
        {
            bool status = false;
            List<string> errors = new List<string>();
            string uploadfilepath = config.UploadDirectory;
            string subdir;
            string filename = string.Empty;

            try
            {
                subdir = id == 0 ? "Documents/" : "Images/";
                if (file != null && file.ContentLength != 0)
                {
                    filename = $"{UserName}_{DateTime.Now.Ticks.ToString("x").ToUpper()}{Path.GetExtension(file.FileName)}";
                    file.SaveAs(Server.MapPath($"{uploadfilepath}{subdir}{filename}"));
                    status = true;
                }
            }
            catch (ValidationException ex)
            {
                errors.Add(ex.Message);
            }
            catch (Exception ex)
            {
                errors.Add($"Systemfehler: {ex.Message}");
                Logger.Error(ex);
            }

            return Json(new
            {
                Status = status,
                FileNameNeu = filename,
                TypeId = id,
                Message = errors.Count > 0 ? string.Join("\n", errors) : ""
            });
        }

        public JsonResult DeleteAdsFile(string filename, int typeid)
        {
            bool status = false;
            string uploadfilepath = config.UploadDirectory;
            string subdir;

            try
            {
                subdir = typeid == 0 ? "Documents/" : "Images/";
                if (System.IO.File.Exists(Server.MapPath($"{uploadfilepath}{subdir}{filename}")))
                {
                    System.IO.File.Delete(Server.MapPath($"{uploadfilepath}{subdir}{filename}"));
                    status = true;
                }
            }
            catch (Exception)
            {
            }

            var result = new
            {
                Status = status,
                TypeId = typeid
            };

            return Json(result, JsonRequestBehavior.AllowGet);
        }


        private void SendMailToCreator(AdModel model)
        {

            //userService.SendMail
        }
    }
}