﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.Entities;

using System.ComponentModel.DataAnnotations;

namespace Aushub.Mvc.Models
{
    public class SubkategorieModel : BaseEntityModel
    {
        public int IKId { get; set; }
        public string Subkategorie { get; set; }
        public string Standardbild { get; set; }
    }
}