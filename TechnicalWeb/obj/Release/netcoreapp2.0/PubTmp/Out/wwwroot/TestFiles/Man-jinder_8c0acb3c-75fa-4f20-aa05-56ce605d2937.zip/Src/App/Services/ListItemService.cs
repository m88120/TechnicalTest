using Aushub.App.Depots;
using Aushub.Shared.Entities;
using Aushub.Shared.Services;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Collections;
using FluentValidation;

namespace Aushub.App.Services
{
    public class ListItemService : NPocoBaseService<IListItemDepot, ListItem, int>, IListItemService
    {
        private IInseratService inseratService;
        private IUserService userService;

        public ListItemService(IListItemDepot baseDepot, IValidatorFactory validatorFactory, IMailService mailService, IAuthorizationManager authorizationManager,
                               IInseratService inseratservice, IUserService userservice)
        : base(baseDepot, validatorFactory, mailService, authorizationManager)
        {
            this.inseratService = inseratservice;
            this.userService = userservice;
        }

        public List<ListItem> GetByListGroup(string group)
        {
            return Depot.GetByListGroup(group);
        }

        public ListItem GetByListGroupAndPosition(string group, int position)
        {
            return Depot.GetByListGroupAndPosition(group, position);
        }

        public List<ListItem> GetAll()
        {
            return Depot.GetAll();
        }

        public PagedList<ListItemView> GetListItemPaged(ListItemSearchAndPagingParameters searchAndPaging)
        {
            return Depot.GetListItemPaged(searchAndPaging);
        }

        public void Save(ListItem entity)
        {
            Depot.Save(entity);
        }

        public bool Delete(int id)
        {
            //Not used until now

            bool status = true;

            if (inseratService.GetAllListItemRecords(id).Count() == 0 && userService.GetAllListItemRecords(id).Count() == 0)
            {
                Depot.Delete(id);
                status = true;
            }

            return status;
        }
        public List<string> GetAllGroups()
        {
            return Depot.GetAllGroups();
        }

    }
}

