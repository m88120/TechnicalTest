﻿using System.Reflection;
using Aushub.Shared;
using Comitas.CAF.Core.Entities;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Data.NPoco.Mapping;

namespace Aushub.App
{
    public class AushubBootstrapper
    {
        public IAuthorizationManager AuthorizationManager { get; private set; }

        public AushubBootstrapper(IAuthorizationManager authManager)
        {
            AuthorizationManager = authManager;
        }

        public void BootstrapApplication()
        {

            // neue Regel fuer NPoco-Mappings
            CustomInflector.AddPluralRule("kategorie", "kategorien");
            CustomInflector.AddPluralRule("koordinate", "koordinaten");
            CustomInflector.AddPluralRule("firma", "firmen");
        }
    }
}
