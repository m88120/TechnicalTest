﻿using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aushub.Shared.Entities;

namespace Aushub.Shared.SearchAndPaging
{
    public class UserSearchAndPagingParameters : SearchAndPagingParameters
    {
        public string Like { get; set; }
        public string RoleId { get; set; }
        public List<Role> Rollen { get; set; }
        public int FIId { get; set; }
        public List<Firma> Firmen { get; set; }
        public int LI_UserstatusId { get; set; }
        public List<ListItem> Userstatus { get; set; }
        public bool OnlyActive { get; set; }
        public int WithoutMyId { get; set; }


        public UserSearchAndPagingParameters() : base()
        {
            PageSize = 15;
            Rollen = new List<Role>();
            Firmen = new List<Firma>();
            Userstatus = new List<ListItem>();
        }
    }
}
