﻿using Comitas.CAF.Core.Data;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.Web.Mvc;
using Aushub.Mvc.Controllers;
using Aushub.Mvc.Models.Base;
using Comitas.CAF.Web.MVC.Extensions;
using Comitas.CAF.Core.Logging;

namespace Aushub.Mvc.Code
{
    public class BaseController : Controller
    {
        public virtual int? UserId { get; private set; }
        public string UserName { get; private set; }
        public string UserDisplayName { get; private set; }
        public string[] UserRoles { get; private set; }

        protected string SessionSort
        {
            get
            {
                return Session["SessionSort"] as string;
            }
            set
            {
                Session["SessionSort"] = value;
            }
        }

        protected SortDirection SessionSortOrder
        {
            get
            {
                return (Session["SessionSortOrder"] != null ? (SortDirection)Session["SessionSortOrder"] : SortDirection.Asc);
            }
            set
            {
                Session["SessionSort"] = value;
            }
        }

        protected int SessionPage
        {
            get
            {
                return (Session["SessionPage"] != null ? (int)Session["SessionPage"] : 0);
            }
            set
            {
                Session["SessionPage"] = value;
            }
        }

        public const string DefaultTempMessageKey = "DefaultActionMessage";

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);

            GetClaimsInfo();
        }

        private void GetClaimsInfo()
        {
            var identity = (ClaimsIdentity)User.Identity;

            if (int.TryParse(GetClaimTypeValue(identity.Claims, SecurityManager.CAFIdClaimType), out int userId))
            {
                UserId = userId;
            }
            UserName = GetClaimTypeValue(identity.Claims, ClaimTypes.NameIdentifier);
            UserDisplayName = GetClaimTypeValue(identity.Claims, ClaimTypes.GivenName);
            UserRoles = GetClaimTypeValueList(identity.Claims, ClaimTypes.Role);
        }

        private string GetClaimTypeValue(IEnumerable<Claim> claims, string claimType)
        {
            return claims.FirstOrDefault(x => x.Type == claimType)?.Value;
        }

        private string[] GetClaimTypeValueList(IEnumerable<Claim> claims, string claimType)
        {
            return claims.Where(x => x.Type == claimType)?.Select(x => x.Value).ToArray();
        }

        protected FileResult FileInline(byte[] file, string contentType, string fileName)
        {
            Response.Headers.Remove("Content-Disposition");
            Response.Headers.Add("Content-Disposition", $"inline; filename={fileName}");

            return File(file, contentType);
        }

        protected List<T> GetSortedPagedList<T>(List<T> source, int page, int pageSize, string sortBy, string sortDir)
        {
            List<T> result = null;

            if (!String.IsNullOrEmpty(sortBy))
            {
                var sortProperty = ReflectionHelper.CreateGetFuncFor<T>(sortBy);
                if (sortProperty != null)
                {
                    if (sortDir.Equals("ASC", StringComparison.InvariantCultureIgnoreCase))
                    {
                        result = source.OrderBy(sortProperty).Skip((page - 1) * pageSize).Take(pageSize).ToList();
                    }
                    else
                    {
                        result = source.OrderByDescending(sortProperty).Skip((page - 1) * pageSize).Take(pageSize).ToList();
                    }
                }
            }

            if (result == null)
            {
                result = source.Skip((page - 1) * pageSize).Take(pageSize).ToList();
            }

            return result;
        }

        protected bool ExecuteActionWithValidationErrorHandling(Action actionToExecute)
        {
            bool result = false;

            try
            {
                result = this.ExecuteActionWithValidationErrorHandling(actionToExecute,
                    "Ein unbehandelter Fehler ist aufgetreten.",
                    "UnhandledError",
                    null,
                    true,
                    true);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }

            return result;
        }

        protected void SetSuccessMessage(string message)
        {
            TempData[MasterController.DefaultTempMessageKey] = $"<p class=\"alert alert-success\">{message}</p>";
        }

        protected virtual PartialViewResult SaveNew<TViewModel>(PartialViewResult saveResult) where TViewModel : new()
        {
            if (ModelState.IsValid)
            {
                // Dieselbe View laden mit einem leeren Model
                return PartialView(saveResult.ViewName, new TViewModel());
            }

            return saveResult;
        }

    }
}