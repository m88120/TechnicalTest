﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.Entities
{
    public class Umkreise
    {
        public int Id { get; set; }
        public string Umkreis { get; set; }
    }
}
