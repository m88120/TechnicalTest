﻿using Comitas.CAF.Core.Collections;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aushub.Shared;
using Aushub.Shared.Services;
using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.SearchAndPaging;
using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Comitas.CAF.Core.Logging;
using System.Data;
using System.Globalization;


namespace Aushub.Mvc.Controllers
{
    [AuthorizeRoles(Role.Sysadmin)]
    public class ListItemController : BaseController
    {
        IListItemService listItemService;
        IUserService userService;
        ILogService logService;
        IMapper mapper;

        public ListItemController(IListItemService listitemservice, IUserService userservice, ILogService logservice, IMapper mapper)
        {
            this.listItemService = listitemservice;
            this.userService = userservice;
            this.logService = logservice;
            this.mapper = mapper;
        }

        public virtual ActionResult Index(int? id, [Bind(Prefix = "s")] ListItemSearchAndPagingParameters parameters)
        {
            return View("Index", GetIndexViewModel(id, null, parameters));
        }

        protected BaseIndexModel<ListItemModel, ListItemDetailModel, ListItemSearchAndPagingParameters> GetIndexViewModel(int? id, ListItemDetailModel entityModel, ListItemSearchAndPagingParameters parameters)
        {

            if (parameters == null)
                parameters = new ListItemSearchAndPagingParameters();

            InitializeSearchListboxes(parameters);

            ListItemDetailModel detailModel = GetDetailModel(id);
            AddDataToCombosOnGetIndexModel();

            // Query String mit GridView Parametern eigentlich nicht mehr notwendig!
            return new BaseIndexModel<ListItemModel, ListItemDetailModel, ListItemSearchAndPagingParameters>()
            {
                PagedList = GetPagedEntites(parameters),
                Search = parameters,
                CurrentEntity = detailModel
            };
        }

        [AuthorizeRoles(Role.Sysadmin)]
        public PartialViewResult Load(int id)
        {
            ModelState.Clear(); // Damit ggf. neue Id übernommen wird

            ListItemDetailModel model = GetDetailModel(id);
            AddDataToCombosOnGetIndexModel();

            return PartialView("ListItemDetailPartial", model);
        }

        private ListItemDetailModel GetDetailModel(int? id)
        {
            if (!id.HasValue)
                return null;

            ListItem view = listItemService.GetById(id.Value);

            var model = view == null ? new ListItemDetailModel() : mapper.Map<ListItemDetailModel>(view);
            return model;
        }

        private void AddDataToCombosOnGetIndexModel()
        {
            List<string> gruppenlist = listItemService.GetAllGroups();
            gruppenlist.Insert(0, "");
            ViewBag.Gruppen = gruppenlist;
        }

        private void InitializeSearchListboxes(ListItemSearchAndPagingParameters parameters)
        {
            List<string> gruppenlist = listItemService.GetAllGroups();
            gruppenlist.Insert(0, "");
            parameters.Gruppen = gruppenlist;
        }

        [AuthorizeRoles(Role.Sysadmin)]
        public ActionResult GetGrid(ListItemSearchAndPagingParameters searchAndPaging)
        {
            return PartialView("Grid", GetPagedEntites(searchAndPaging));
        }

        private PagedList<ListItemModel> GetPagedEntites(ListItemSearchAndPagingParameters searchAndPaging)
        {
            bool selCrit = User.IsInRole(Role.Sysadmin);

            var pagedEntities = listItemService.GetListItemPaged(searchAndPaging);

            return new PagedList<ListItemModel>(mapper.Map<IEnumerable<ListItemView>, IEnumerable<ListItemModel>>(pagedEntities),
                                                         pagedEntities.PageIndex,
                                                         pagedEntities.PageSize,
                                                         pagedEntities.TotalCount);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Sysadmin)]
        public PartialViewResult Save(ListItemDetailModel model)
        {

            var saveResult = TrySave(model);

            if (saveResult.Status)
            {
                SetSuccessMessage("Ihre Daten wurden erfolgreich gespeichert");
                logService.Save($"ListItem {model.Gruppe} - {model.Bezeichnung} wurde gespeichert", "ListItem Verwaltung", UserId);
                return Load(saveResult.Id);
            }

            AddDataToCombosOnGetIndexModel();
            return PartialView("ListItemDetailPartial", model);
        }

        [HttpPost]
        [AuthorizeRoles(Role.Sysadmin)]
        public PartialViewResult SaveNew(ListItemDetailModel model)
        {
            return SaveNew<ListItemDetailModel>(Save(model));
        }

        private (bool Status, int Id) TrySave(ListItemDetailModel model)
        {
            if (!ModelState.IsValid)
            {
                return (false, 0);
            }

            ListItem litem = new ListItem();

            if (model.Id > 0)
                litem = listItemService.GetById(model.Id);

            mapper.Map(model, litem);

            return (ExecuteActionWithValidationErrorHandling(() => listItemService.Save(litem)), litem.Id);
        }

        [AuthorizeRoles(Role.Sysadmin)]
        public JsonResult Delete(int id)
        {
            bool status = false;

            try
            {
                if (listItemService.Delete(id))
                    status = true;
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }

            var result = new
            {
                Status = status
            };

            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
}