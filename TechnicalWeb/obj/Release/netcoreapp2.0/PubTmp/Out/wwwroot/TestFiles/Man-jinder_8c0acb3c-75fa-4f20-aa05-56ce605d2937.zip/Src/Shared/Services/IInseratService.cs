﻿using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.Shared.SearchAndPaging;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Aushub.Shared.Services
{
    public interface IInseratService : IEntityIdService<Inserat, int>
    {
        void Save(Inserat entity);
        List<Inserat> GetByFirmenId(int firmenId);
        List<Inserat> GetAllListItemRecords(int id);
        List<Inserat> GetByKategorieId(int kategorieId);
        List<Inserat> GetBySubkategorieId(int subkategorieId);
        PagedList<InseratView> GetInseratPaged(InseratSearchAndPagingParameters searchAndPaging);
        void Delete(int id);
        InseratView GetViewById(int id);
    }
}
