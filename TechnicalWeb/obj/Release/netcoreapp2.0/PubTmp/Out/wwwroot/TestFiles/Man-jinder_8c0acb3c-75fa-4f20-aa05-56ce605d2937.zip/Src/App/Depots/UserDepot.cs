using System;
using System.Collections.Generic;
using System.Linq;
using Aushub.Shared.Entities;
using Aushub.Shared.ViewModels;
using Aushub.App.Depots;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Entities;
using Comitas.CAF.Core.Security;
using NPoco;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Data;
using Aushub.Shared.SearchAndPaging;

namespace Aushub.App.Depots
{
	public class UserDepot : PagingDepot<User, UserView, int>, IUserDepot
    {
        private IRoleDepot roleDepot;
        private static Dictionary<string, string> additionalEntityToColumnMap = new Dictionary<string, string>()
        {
            { "IsActive", "US_InactiveDate" }
        };

        public UserDepot(INPocoDbContext dbContext, IRoleDepot roleDepot, IAuthorizationManager authorizationManager)
            : base(dbContext, authorizationManager, additionalEntityToColumnMap)
        {
            this.roleDepot = roleDepot;
            CreateUpdateUserNotFound += CreateUpdateUserNotFound_Event;
        }

        public User GetByEmail(string email)
        {
            return Database.Fetch<User>(GetBaseSelectSql().Where("US_Email = @Email", new { Email = email })).SingleOrDefault();
        }

        public User GetUserByPasswordResetToken(string token)
        {
            return Database.Fetch<User>(GetBaseSelectSql().Where("US_PasswordResetToken = @Token", new { Token = token })).SingleOrDefault();
        }

        public PagedList<UserView> GetUserPaged(UserSearchAndPagingParameters searchAndPaging, bool selCrit)
        {
            Sql select = GetViewBaseSelectSql();

            if (!selCrit)
            {
                select = select.Where("US_RoleKey <> @sysadmin", new {sysadmin = Role.Sysadmin });
            }

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Like))
            {
                select = select.Where("US_Email LIKE @Like OR US_Firstname LIKE @Like OR US_Lastname LIKE @Like", new { Like = $"%{searchAndPaging.Like}%" });
            }

            if (searchAndPaging.FIId > 0)
            {
                select = select.Where("US_FI_Id = @FirmenId", new { FirmenId = searchAndPaging.FIId });
            }

            if (!String.IsNullOrWhiteSpace(searchAndPaging.RoleId))
            {
                select = select.Where("US_RoleKey = @RoleKey", new { RoleKey = searchAndPaging.RoleId });
            }

            if (searchAndPaging.LI_UserstatusId > 0)
            {
                select = select.Where("US_LI_Userstatus_Id = @StatusId", new { StatusId = searchAndPaging.LI_UserstatusId });
            }

            if (searchAndPaging.OnlyActive)
            {
                select = select.Where("US_DeactivatedDate Is Null");
            }

            if (searchAndPaging.WithoutMyId > 0)
            {
                select = select.Where("US_Id <> @MyId", new { MyId = searchAndPaging.WithoutMyId });
            }

            return GetPagedAuto(searchAndPaging, select, "US_Firstname ASC, US_Lastname ASC, US_Id ASC");
        }

        public User GetSystemUser()
        {
            return Database.Query<User>().Single(x => x.IsSystemUser);
        }

        public List<User> GetAllByRole(string roleKey)
        {
            return Database.Fetch<User>(GetBaseSelectSql().Where("US_RoleKey = @RoleKey", new { RoleKey = roleKey }));
        }

        public List<User> GetByFirmenId(int? firmenId, bool withSystemUsers)
        {
            if (withSystemUsers)
                return Database.Fetch<User>(GetBaseSelectSql().Where("US_FI_Id = @FirmenId", new { FirmenId = firmenId }));
            else
                return Database.Fetch<User>(GetBaseSelectSql().Where("US_FI_Id = @FirmenId And US_IsSystemUser = 0", new { FirmenId = firmenId }));
        }

        private Sql GetViewBaseSelectSql()
        {
            string[] columns = new string[]
            {
                "US.*",
                "FI.FI_Firmenname AS US_Firmenname"
            };

            Sql select = Sql.Builder.Select(columns).From("Users AS US")
                                                    .LeftJoin("Firmen AS FI").On("US.US_FI_Id = FI.FI_Id");

            return select;
        }


        private void CreateUpdateUserNotFound_Event(object sender, CreateUpdateUserEventArgs e)
        {
            e.UserToUse = GetSystemUser().Id;
        }

        public List<User> GetAllListItemRecords(int id)
        {
            Sql select = Sql.Builder.Select("*").From("Users");

            select = select.Where("US_LI_Salutation_Id = @Id OR US_LI_Userstatus_Id = @Id", new { Id = id });

            return Database.Fetch<User>(select).ToList();
        }

    }
}

