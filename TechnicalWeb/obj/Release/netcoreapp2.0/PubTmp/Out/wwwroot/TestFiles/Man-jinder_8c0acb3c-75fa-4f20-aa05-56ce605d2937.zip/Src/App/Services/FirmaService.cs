using Aushub.App.Depots;
using Aushub.Shared.Entities;
using Aushub.Shared.Services;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.App.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Collections;
using FluentValidation;

namespace Aushub.App.Services
{
    public class FirmaService : NPocoBaseService<IFirmaDepot, Firma, int>, IFirmaService
    {
        private IInseratService inseratService;
        private IUserService userService;

        public FirmaService(IFirmaDepot baseDepot, IValidatorFactory validatorFactory, IMailService mailService, IAuthorizationManager authorizationManager,
                            IInseratService inseratservice, IUserService userservice)
        : base(baseDepot, validatorFactory, mailService, authorizationManager)
        {
            this.inseratService = inseratservice;
            this.userService = userservice;
        }

        public List<Firma> GetAll(bool bwithSystem)
        {
            return Depot.GetAll(bwithSystem);
        }

        public void Save(Firma entity)
        {
            Depot.Save(entity);
        }

        public PagedList<FirmenView> GetFirmenPaged(FirmenSearchAndPagingParameters searchAndPaging, bool selCrit)
        {
            return Depot.GetFirmenPaged(searchAndPaging, selCrit);
        }

        public string GetListOfCompaniesForHome()
        {
            return Depot.GetListOfCompaniesForHome();
        }

        public Firma GetByUID(string uid)
        {
            return Depot.GetByUID(uid);
        }

        public bool Delete(int id)
        {
            bool status = false;

            if (inseratService.GetByFirmenId(id).Count() == 0 && userService.GetByFirmenId(id, true).Count() == 0)
            {
                Depot.Delete(id);
                status = true;
            }

            return status;
        }

    }
}

