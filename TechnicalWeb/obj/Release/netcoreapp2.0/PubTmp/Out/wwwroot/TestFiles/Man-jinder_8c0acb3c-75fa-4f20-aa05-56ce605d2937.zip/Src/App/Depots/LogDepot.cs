﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using Comitas.CAF.Data.NPoco;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Core.Collections;
using NPoco;
namespace Aushub.App.Depots
{
    public class LogDepot : PagingDepot<Log, LogView, int>, ILogDepot
    {
        public LogDepot(INPocoDbContext dbContext, IAuthorizationManager authorizationManager)
            : base(dbContext, authorizationManager)
        {
        }

        public List<Log> GetAllLogs()
        {
            return Database.Query<Log>(GetBaseSelectSql()).ToList();
        }

        public void Save(string message, string module, int? actUser)
        {
            base.Save(new Log() { Message = message, Module = module, Timestamp = DateTime.Now, USId = actUser });
        }

        public PagedList<LogView> GetLogsPaged(LogSearchAndPagingParameters searchAndPaging)
        {
            Sql select = GetViewBaseSelectSql();

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Module))
            {
                select = select.Where("LO_Module LIKE @Like", new { Like = $"%{searchAndPaging.Module}%" });
            }

            if (!String.IsNullOrWhiteSpace(searchAndPaging.Message))
            {
                select = select.Where("LO_Message LIKE @Like", new { Like = $"%{searchAndPaging.Message}%" });
            }

            if (searchAndPaging.Von != null)
            {
                DateTime dvon;
                if (DateTime.TryParse(searchAndPaging.Von, out dvon))
                {
                    string svon = $"{dvon.Year.ToString("0000")}-{dvon.Month.ToString("00")}-{dvon.Day.ToString("00")} 00:00:00"; 
                    select = select.Where("CONVERT(varchar(19), LO_Timestamp, 120) >= @DatumVon", new { DatumVon = svon });
                }
            }

            if (searchAndPaging.Bis != null)
            {
                DateTime dbis;
                if (DateTime.TryParse(searchAndPaging.Bis, out dbis))
                {
                    string sbis = $"{dbis.Year.ToString("0000")}-{dbis.Month.ToString("00")}-{dbis.Day.ToString("00")} 23:59:59";
                    select = select.Where("CONVERT(varchar(19), LO_Timestamp, 120) <= @DatumBis", new { DatumBis = sbis });
                }
            }

            return GetPagedAuto(searchAndPaging, select, "LO_Timestamp DESC");
        }
private Sql GetViewBaseSelectSql()
        {
            string[] columns = new string[]
            {
                "LO.*",
                "LTRIM(RTRIM(ISNULL(US.US_Firstname, '') + ' ' + ISNULL(US.US_Lastname, ''))) AS LO_Displayname"
            };

            Sql select = Sql.Builder.Select(columns).From("Logs AS LO")
                                                    .LeftJoin("Users AS US").On("US.US_Id = LO.LO_US_Id");

            return select;
        }

        public List<string> GetAllModules()
        {
            Sql select = Sql.Builder.Select("DISTINCT LO_Module").From("Logs");
            List<Log> logs = Database.Fetch<Log>(select).ToList();
            string[] modules = logs.Select(x => x.Module).ToArray();
            return modules.OfType<string>().ToList();
        }
    }
}

