﻿using Aushub.Mvc.Models.Base;
using System;

namespace Aushub.Mvc.Models
{
    public class SearchDetailModel : SearchModel, IDetailModel
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string Title { get; set; }
        public int ZIndex { get; set; }
        public string Content { get; set; }
        public string Postleitzahl { get; set; }
        public string Ort { get; set; }
        public int US_KontaktId { get; set; }
        public string Kontakt { get; set; }
        public bool MailadresseAnzeigen { get; set; }
        public bool TelefonAnzeigen { get; set; }
        public bool MobilnummerAnzeigen { get; set; }
        public string Telefon { get; set; }
        public string Mobil { get; set; }
        public string EMail { get; set; }
        public string Beschreibung { get; set; }
        public DateTime CreateDate { get; set; }
        public int CreateUserId { get; set; }
        public string CreateUserDisplayName { get; set; }

        public DateTime? UpdateDate { get; set; }
        public int? UpdateUserId { get; set; }
        public string UpdateUserDisplayName { get; set; }

        public DateTime LastEditDate => UpdateDate.HasValue ? (DateTime)UpdateDate : CreateDate;

    }
}