﻿using Comitas.CAF.Core.Collections;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aushub.Shared;
using Aushub.Shared.Services;
using Aushub.Shared.Entities;
using Aushub.Shared.Enums;
using Aushub.Shared.ViewModels;
using Aushub.Mvc.Models.Base;
using Aushub.Shared.SearchAndPaging;
using Aushub.Mvc.Models;
using Aushub.Mvc.Code;
using Comitas.CAF.Core.Logging;
using System.Data;
using System.Globalization;

namespace Aushub.Mvc.Controllers
{
    [Authorize]
    public class MyAccountController : BaseController
    {
        IFirmaService firmenService;
        IUserService userService;
        ILogService logService;
        IInseratService inseratService;
        IListItemService listitemService;
        IInseratsKategorieService inseratskategorienService;
        IGeoKoordinateService geoKoordService;
        IMapper mapper;

        private static int FirmenID;

        public MyAccountController(IFirmaService firmenservice, IUserService userservice, IInseratService inseratservice, 
                                   IListItemService listitemservice, ILogService logservice, IMapper mapper,
                                   IGeoKoordinateService geokoordservice, IInseratsKategorieService inseratskategorienservice)
        {
            this.firmenService = firmenservice;
            this.userService = userservice;
            this.logService = logservice;
            this.inseratService = inseratservice;
            this.listitemService = listitemservice;
            this.inseratskategorienService = inseratskategorienservice;
            this.geoKoordService = geokoordservice;
            this.mapper = mapper;
        }
        // GET: MyAccount
        public virtual ActionResult Index(int? id, [Bind(Prefix = "s")] MyAccountPagingParameters parameters)
        {
            int? fId;
            
            if (!UserId.HasValue)
                return RedirectToAction("Index", "Home");

            fId = userService.GetFirmenIdForUser((int)UserId);
            if (!fId.HasValue)
                return RedirectToAction("Index", "Home");
            else
                FirmenID = (int)fId;

            return View("Index", GetIndexViewModel(id, parameters));
        }

        protected BaseMyAccountModel<UserDetailModel, FirmenDetailModel, AdModel, MyAccountPagingParameters> GetIndexViewModel(int? id, MyAccountPagingParameters parameters)
        {

            if (parameters == null)
                parameters = new MyAccountPagingParameters();

            parameters.FiId = FirmenID;

            User myUser = userService.GetById((int)UserId);
            UserDetailModel myUserDetailModel = new UserDetailModel();
            mapper.Map(myUser, myUserDetailModel);
            myUserDetailModel.Userstatus = listitemService.GetById(myUser.LI_UserstatusId).Bezeichnung;
            myUserDetailModel.Firmenname = myUser.FIId.HasValue ? firmenService.GetById((int)myUser.FIId).Firmenname : string.Empty;

            Firma myFirma = firmenService.GetById(FirmenID);
            FirmenDetailModel myFirmenDetailModel = new FirmenDetailModel();
            mapper.Map(myFirma, myFirmenDetailModel);

            UserDetailModel detailModelFellow = GetFellowDetailModel(id);
            AdModel detailModelAd = GetAdDetailModel(id);

            AddDataToMyUserCombosOnGetIndexModel();

            // Query String mit GridView Parametern eigentlich nicht mehr notwendig!
            return new BaseMyAccountModel<UserDetailModel, FirmenDetailModel, AdModel, MyAccountPagingParameters>()
            {
                MeinUser = myUserDetailModel,
                MeineFirma = myFirmenDetailModel,
                MeineKollegen = GetPagedFellowEntites(parameters),
                MeineKollegenCurrentEntry= detailModelFellow,
                UnsereInserate = GetPagedAdEntites(parameters),
                UnsereInserateCurrentEntry = detailModelAd,
                Search = parameters
            };
        }

        private void AddDataToMyUserCombosOnGetIndexModel()
        {
            List<ListItem> salutationlist = listitemService.GetByListGroup(ListItem.Salutation);
            salutationlist.Insert(0, new ListItem() { Id = 0, Bezeichnung = string.Empty });
            ViewBag.SalutationListItems = salutationlist;
        }

        public PartialViewResult LoadMyUser()
        {
            ModelState.Clear();

            User myUser = userService.GetById((int)UserId);
            UserDetailModel model = new UserDetailModel();
            mapper.Map(myUser, model);
            model.Userstatus = listitemService.GetById(myUser.LI_UserstatusId).Bezeichnung;
            model.Firmenname = myUser.FIId.HasValue ? firmenService.GetById((int)myUser.FIId).Firmenname : string.Empty;

            AddDataToMyUserCombosOnGetIndexModel();

            return PartialView("MyUserData", model);
        }

        [HttpPost]
        public PartialViewResult SaveMyUser(UserDetailModel model)
        {

            var saveResult = TrySaveMyUser(model);
            if (saveResult.Status)
            {
                SetSuccessMessage("Ihre Daten wurden erfolgreich gespeichert");
                logService.Save($"Benutzer {model.Email} wurde gespeichert", "Mein Konto", UserId);
                return LoadMyUser();
            }

            AddDataToMyUserCombosOnGetIndexModel();
            model.Userstatus = listitemService.GetById(model.LI_UserstatusId).Bezeichnung;
            model.Firmenname = model.FIId.HasValue ? firmenService.GetById((int)model.FIId).Firmenname : string.Empty;

            return PartialView("UserDetailPartial", model);
        }

        private (bool Status, int Id) TrySaveMyUser(UserDetailModel model)
        {
            if (!ModelState.IsValid)
            {
                return (false, 0);
            }

            User user = userService.GetById(model.Id);

            user.LI_SalutationId = model.LI_SalutationId;
            user.Firstname = model.Firstname;
            user.Lastname = model.Lastname;
            user.MobilNumber = model.MobilNumber;
            user.Telefon = model.Telefon;
            user.WillSammelmailErhalten = model.WillSammelmailErhalten;

            return (ExecuteActionWithValidationErrorHandling(() => userService.Save(user)), user.Id);
        }

        public PartialViewResult LoadFellow(int id)
        {
            ModelState.Clear(); // Damit ggf. neue Id übernommen wird

            UserDetailModel model = GetFellowDetailModel(id);

            return PartialView("MyFellowsDetailPartial", model);
        }

        private UserDetailModel GetFellowDetailModel(int? id)
        {
            if (!id.HasValue)
                return null;

            User view = userService.GetById(id.Value);

            var model = view == null ? new UserDetailModel() : mapper.Map<UserDetailModel>(view);
            return model;
        }

        public ActionResult GetGridFellows(MyAccountPagingParameters searchAndPaging)
        {
            return PartialView("GridFellows", GetPagedFellowEntites(searchAndPaging));
        }

        private PagedList<UserDetailModel> GetPagedFellowEntites(MyAccountPagingParameters searchAndPaging)
        {
            searchAndPaging.FiId = FirmenID;
            bool selCrit = User.IsInRole(Role.Sysadmin);
            UserSearchAndPagingParameters usundp = new UserSearchAndPagingParameters();
            mapper.Map(searchAndPaging, usundp);
            usundp.OnlyActive = true;
            usundp.WithoutMyId = UserId.HasValue ? (int)UserId : 0;

            var pagedEntities = userService.GetUserPaged(usundp, selCrit);

            return new PagedList<UserDetailModel>(mapper.Map<IEnumerable<UserView>, IEnumerable<UserDetailModel>>(pagedEntities),
                                                         pagedEntities.PageIndex,
                                                         pagedEntities.PageSize,
                                                         pagedEntities.TotalCount);
        }

        public PartialViewResult LoadAd(int id)
        {
            ModelState.Clear(); // Damit ggf. neue Id übernommen wird

            AdModel model = GetAdDetailModel(id);

            return PartialView("OurAdsDetailPartial", model);
        }

        private AdModel GetAdDetailModel(int? id)
        {
            if (!id.HasValue)
                return null;

            InseratView view = inseratService.GetViewById(id.Value);

            AdModel model = view == null ? new AdModel() : mapper.Map<AdModel>(view);
            InitializeModel(model);

            return model;
        }

        public ActionResult GetGridAds(MyAccountPagingParameters searchAndPaging)
        {
            searchAndPaging.FiId = FirmenID;
            return PartialView("GridAds", GetPagedAdEntites(searchAndPaging));
        }

        private PagedList<AdModel> GetPagedAdEntites(MyAccountPagingParameters searchAndPaging)
        {
            searchAndPaging.FiId = FirmenID;
            InseratSearchAndPagingParameters isundp = new InseratSearchAndPagingParameters();
            mapper.Map(searchAndPaging, isundp);
            isundp.UserId = null;

            if (searchAndPaging.ShowMyAdsOnly)
                isundp.UserId = UserId;

            var pagedEntities = inseratService.GetInseratPaged(isundp);

            return new PagedList<AdModel>(mapper.Map<IEnumerable<InseratView>, IEnumerable<AdModel>>(pagedEntities),
                                                         pagedEntities.PageIndex,
                                                         pagedEntities.PageSize,
                                                         pagedEntities.TotalCount);
        }

        private void InitializeModel(AdModel model)
        {
            //Initialize User dependent fields

            model.VerkaufId = listitemService.GetByListGroupAndPosition("Inseratstyp", (int)Inseratstyp.Verkauf).Id;
            model.AnkaufId = listitemService.GetByListGroupAndPosition("Inseratstyp", (int)Inseratstyp.Ankauf).Id;
            model.BieteTransportId = listitemService.GetByListGroupAndPosition("Inseratstyp", (int)Inseratstyp.BieteTransport).Id;
            model.BenoetigeTransportId = listitemService.GetByListGroupAndPosition("Inseratstyp", (int)Inseratstyp.BenoetigeTransport).Id;
            model.CreateUserDisplayName = userService.GetById(model.CreateUserId).DisplayName;
            model.Telefon = userService.GetById(model.US_KontaktId).Telefon;
            model.Mobilnummer = userService.GetById(model.US_KontaktId).MobilNumber;
            model.Mailadresse = userService.GetById(model.US_KontaktId).Email;

            //Initialize all comboboxes
            PrepareListFields(model);
        }

        private void PrepareListFields(AdModel model)
        {
            model.Kategorien = inseratskategorienService.GetAll(false);
            model.Kategorien.Insert(0, new InseratsKategorie() { Id = 0, Kategorie = "Kategorie ..." });
            model.Subkategorien = new List<InseratsSubkategorie>();
            model.Subkategorien.Clear();
            model.Subkategorien.Insert(0, new InseratsSubkategorie() { IKId = 0, Subkategorie = "Subkategorie ..." });
            model.InseratstypListItems = listitemService.GetByListGroup(ListItem.Inseratstyp);
            model.ContactsInCompany = userService.GetByFirmenId(model.FIId, true);
            model.InseratstatusListItems = listitemService.GetByListGroup(ListItem.Inseratstatus);
            model.InseratTeilenAufListItems = listitemService.GetByListGroup(ListItem.InseratTeilenAuf);
            model.MengeneinheitListItems = listitemService.GetByListGroup(ListItem.Mengeneinheit);
        }

        public JsonResult DeleteAd(int id)
        {
            bool status = false;

            try
            {
                inseratService.Delete(id);
                status = true;
                logService.Save($"Inserat {id} wurde gelöscht", "Mein Konto", UserId);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
            }

            var result = new
            {
                Status = status
            };

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public PartialViewResult UpdateAd(AdModel model)
        {

            var saveResult = TrySaveMyAd(model);
            if (saveResult.Status)
            {
                SetSuccessMessage("Ihre Daten wurden erfolgreich gespeichert");
                logService.Save($"Inserat {saveResult.Id} wurde geändert und gespeichert", "Mein Konto", UserId);
                return LoadAd(saveResult.Id);
            }

            InitializeModel(model);

            return PartialView("OurAdsDetailPartial", model);
        }

        private (bool Status, int Id) TrySaveMyAd(AdModel model)
        {
            if (!ModelState.IsValid)
            {
                return (false, 0);
            }

            Inserat inserat = inseratService.GetById(model.Id);
            mapper.Map(model, inserat);

            List<GeoKoordinate> geolist = geoKoordService.GetByPlzOrt(model.Postleitzahl, model.Ort);
            if (geolist != null && geolist.Count > 0)
            {
                inserat.Latitude = geolist[0].Latitude;
                inserat.Longitude = geolist[0].Longitude;
            }

            return (ExecuteActionWithValidationErrorHandling(() => inseratService.Save(inserat)), inserat.Id);
        }

    }
}