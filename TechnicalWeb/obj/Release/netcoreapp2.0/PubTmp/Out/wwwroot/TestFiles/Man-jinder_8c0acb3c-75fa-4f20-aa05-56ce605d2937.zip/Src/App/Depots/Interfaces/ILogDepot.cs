﻿using Aushub.Shared.Entities;
using Aushub.Shared.SearchAndPaging;
using Aushub.Shared.ViewModels;
using Comitas.CAF.Core.Collections;
using Comitas.CAF.Core.Services;
using Comitas.CAF.Core.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Aushub.App.Depots
{
    public interface ILogDepot : IDepot<Log, int>
    {
        List<Log> GetAllLogs();
        void Save(string message, string module, int? actUser);
        PagedList<LogView> GetLogsPaged(LogSearchAndPagingParameters searchAndPaging);
        List<string> GetAllModules();

    }
}
