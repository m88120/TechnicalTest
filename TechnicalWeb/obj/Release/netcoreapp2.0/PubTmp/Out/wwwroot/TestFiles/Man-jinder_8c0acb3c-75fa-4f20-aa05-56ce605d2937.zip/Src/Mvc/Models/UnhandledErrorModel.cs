﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aushub.Mvc.Models
{
    public class UnhandledErrorModel
    {
        public string Url { get; set; }
        public string User { get; set; }
        public DateTime DateTime { get; set; }

        public bool ShowDetails { get; set; }
        public string ExceptionType { get; set; }
        public string ErrorMessage { get; set; }
        public string StackTrace { get; set; }
    }
}