﻿using Comitas.CAF.Core.Entities;
using Comitas.CAF.Core.Security;
using Comitas.CAF.Utilities;
using Aushub.Shared.Templating;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aushub.Shared.Entities
{
    [AutoGen]
    public class User : CreateUpdateDateWithUserBaseEntity<int>, ISecurityUser
    {
        public int? FIId { get; set; }
        public int? LI_SalutationId { get; set; }
        public string Email { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string Password { get; private set; }
        public int Salt { get; set; }
        public bool IsSystemUser { get; set; }
        public DateTime? LastLogin { get; set; }
        public DateTime? DeactivatedDate { get; set; }
        public int? DeactivatedUserId { get; set; }
        public bool IsActive => (DeactivatedDate == null);
        public string PasswordResetToken { get; set; }
        public DateTime? PasswordResetRequestDate { get; set; }
        public string RoleKey { get; set; }
        public string Telefon { get; set; }
        public string MobilNumber { get; set; }
        public bool HasAcceptedAGBs { get; set; }
        public int LI_UserstatusId { get; set; }
        public bool WillSammelmailErhalten { get; set; }

        public void Activate(User byUser)
        {
            DeactivatedDate = null;
            DeactivatedUserId = byUser.Id;
        }

        public void Deactivate(User byUser)
        {
            DeactivatedDate = DateTime.UtcNow;
            DeactivatedUserId = byUser.Id;
        }

        #region "ISecurityUser Properties"

        public string Identifier
        {
            get
            {
                return Email;
            }
        }

        public string UniqueId
        {
            get
            {
                return Id.ToString();
            }
        }

        public string DisplayName
        {
            get
            {
                return $"{Firstname} {Lastname}";
            }
        }

        #endregion

        #region "ISecurityUser Functions"

        public void HashAndAssignPassword(string password)
        {
            Salt = CryptoHelper.GenerateSalt();
            Password = HashPassword(password, Salt);
        }

        public static string HashPassword(string password, int salt)
        {
            return CryptoHelper.GetSHA256Hash(password + salt);
        }

        public IEnumerable<ISecurityRole> GetRoles()
        {
            return new List<Role>() { { new Role() { Id = RoleKey } } };
        }

        public bool IsPasswordResetTokenValid(string token)
        {
            return (PasswordResetToken == token
                        && (
                            (LastLogin.HasValue && PasswordResetRequestDate < DateTime.UtcNow.AddDays(-1))
                            || (!LastLogin.HasValue && PasswordResetRequestDate < DateTime.UtcNow.AddDays(-7))
                        )
                    );
        }

        public virtual string GenerateNewPassword()
        {
            string newPassword = Guid.NewGuid().ToString().Substring(0, 8);

            this.Password = CryptoHelper.GetSHA256Hash(newPassword + Salt);

            return newPassword;
        }

        public virtual bool CheckPassword(string pw)
        {
            if (Password == CryptoHelper.GetSHA256Hash(pw + Salt))
                return true;

            return false;
        }

        public virtual bool ChangePassword(string pwOld, string pwNew)
        {
            if (CheckPassword(pwOld))
            {
                HashAndAssignPassword(pwNew);
                return true;
            }

            return false;
        }

        public virtual string StartPasswordResetRequest()
        {
            PasswordResetToken = Guid.NewGuid().ToString();
            PasswordResetRequestDate = DateTime.UtcNow;

            return PasswordResetToken;
        }

        public virtual void FinishPasswordResetRequest()
        {
            PasswordResetToken = null;
            PasswordResetRequestDate = null;
        }

        #endregion

        public User()
        {
            IsSystemUser = false;
            WillSammelmailErhalten = true;
            RoleKey = Role.User;
            HasAcceptedAGBs = false;
            LI_UserstatusId = (int)ListItem.UserstatusPositionEnum.Registriert;
        }
    }
}
